import React, { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { type Lang, getTranslation, isRTL } from '../i18n';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  oldPrice: number;
  balance: string;
  image: string;
  quantity: number;
  category: string;
}

interface AppContextType {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: string) => string;
  rtl: boolean;
  cart: CartItem[];
  addToCart: (item: Omit<CartItem, 'quantity'>) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, qty: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  currentPage: string;
  setCurrentPage: (page: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  paymentModalOpen: boolean;
  setPaymentModalOpen: (open: boolean) => void;
  productDetail: string | null;
  setProductDetail: (id: string | null) => void;
  sessionTime: number;
  onlineUsers: number;
}

const AppContext = createContext<AppContextType | null>(null);

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Lang>(() => {
    return (localStorage.getItem('bm_lang') as Lang) || 'ar';
  });
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bm_cart');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [currentPage, setCurrentPage] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [productDetail, setProductDetail] = useState<string | null>(null);
  const [sessionTime, setSessionTime] = useState(0);
  const [onlineUsers, setOnlineUsers] = useState(Math.floor(Math.random() * 200) + 150);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    localStorage.setItem('bm_lang', l);
  }, []);

  const t = useCallback((key: string) => getTranslation(lang, key), [lang]);
  const rtl = isRTL(lang);

  useEffect(() => {
    localStorage.setItem('bm_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    const timer = setInterval(() => setSessionTime(s => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setOnlineUsers(prev => prev + Math.floor(Math.random() * 11) - 5);
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const addToCart = useCallback((item: Omit<CartItem, 'quantity'>) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  }, []);

  const updateQuantity = useCallback((id: string, qty: number) => {
    if (qty <= 0) {
      setCart(prev => prev.filter(i => i.id !== id));
    } else {
      setCart(prev => prev.map(i => i.id === id ? { ...i, quantity: qty } : i));
    }
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <AppContext.Provider value={{
      lang, setLang, t, rtl,
      cart, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount,
      currentPage, setCurrentPage,
      sidebarOpen, setSidebarOpen,
      cartOpen, setCartOpen,
      paymentModalOpen, setPaymentModalOpen,
      productDetail, setProductDetail,
      sessionTime, onlineUsers,
    }}>
      {children}
    </AppContext.Provider>
  );
};
