import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import IntroOverlay from './components/IntroOverlay';
import LoadingScreen from './components/LoadingScreen';
import Header from './components/Header';
import TabBar from './components/TabBar';
import BottomBar from './components/BottomBar';
import Sidebar from './components/Sidebar';
import Cart from './components/Cart';
import PaymentModal from './components/PaymentModal';
import ProductDetail from './components/ProductDetail';
import FakePurchase from './components/FakePurchase';
import Reviews from './components/Reviews';
import HomePage from './pages/HomePage';
import StorePage from './pages/StorePage';
import ToolsPage from './pages/ToolsPage';
import ChannelsPage from './pages/ChannelsPage';
import GuidesPage from './pages/GuidesPage';
import PromoPage from './pages/PromoPage';
import PaymentPage from './pages/PaymentPage';
import AdminReportsPage from './pages/AdminReportsPage';
import DocServicesPage from './pages/DocServicesPage';
import EliteOpsPage from './pages/EliteOpsPage';
import type { Lang } from './i18n';

const AppContent: React.FC = () => {
  const { currentPage, rtl, setLang } = useApp();
  const [phase, setPhase] = useState<'intro' | 'loading' | 'app'>('intro');

  // Click sound effect
  useEffect(() => {
    const playClick = () => {
      try {
        const AC = window.AudioContext || (window as any).webkitAudioContext;
        if (!AC) return;
        const ctx = new AC();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 1800;
        osc.type = 'sine';
        gain.gain.value = 0.06;
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.06);
        setTimeout(function() { try { ctx.close(); } catch(e) {} }, 100);
      } catch(e) {}
    };
    const handler = (e: Event) => {
      const t = e.target as HTMLElement;
      if (t.tagName === 'BUTTON' || t.tagName === 'A' || t.closest('button') || t.closest('a')) playClick();
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  useEffect(() => {
    const preventContext = (e: Event) => e.preventDefault();
    const preventSelect = (e: Event) => e.preventDefault();
    const preventKeys = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        const target = e.target as HTMLElement;
        if (!target.classList.contains('wallet-address')) e.preventDefault();
      }
    };
    document.addEventListener('contextmenu', preventContext);
    document.addEventListener('selectstart', preventSelect);
    document.addEventListener('keydown', preventKeys);
    return () => { document.removeEventListener('contextmenu', preventContext); document.removeEventListener('selectstart', preventSelect); document.removeEventListener('keydown', preventKeys); };
  }, []);

  const handleSelectLang = (lang: Lang) => { setLang(lang); setPhase('loading'); };

  if (phase === 'intro') return <IntroOverlay onSelectLang={handleSelectLang} />;
  if (phase === 'loading') return <LoadingScreen onComplete={() => setPhase('app')} />;

  const renderPage = () => {
    switch (currentPage) {
      case 'store': return <StorePage />;
      case 'tools': return <ToolsPage />;
      case 'channels': return <ChannelsPage />;
      case 'guides': return <GuidesPage />;
      case 'promo': return <PromoPage />;
      case 'payment-page': return <PaymentPage />;
      case 'admin-reports': return <AdminReportsPage />;
      case 'doc-services': return <DocServicesPage />;
      case 'elite-ops': return <EliteOpsPage />;
      default: return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-black" dir={rtl ? 'rtl' : 'ltr'}>
      <Header />
      <TabBar />
      <main key={currentPage} className="fade-in">{renderPage()}{currentPage==='home'&&<Reviews />}</main>
      <FakePurchase />
      <BottomBar />
      <Sidebar />
      <Cart />
      <PaymentModal />
      <ProductDetail />
    </div>
  );
};

const App: React.FC = () => <AppProvider><AppContent /></AppProvider>;
export default App;
