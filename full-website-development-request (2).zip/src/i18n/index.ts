import ar from './ar.json';
import en from './en.json';
import ru from './ru.json';

export type Lang = 'ar' | 'en' | 'ru';

const translations: Record<Lang, Record<string, string>> = { ar, en, ru };

export const getTranslation = (lang: Lang, key: string): string => {
  return translations[lang]?.[key] || translations['en']?.[key] || key;
};

export const isRTL = (lang: Lang): boolean => lang === 'ar';

export const langNames: Record<Lang, string> = {
  ar: 'العربية 🇸🇦',
  en: 'English 🇺🇸',
  ru: 'Русский 🇷🇺',
};

export const allLangs: { code: Lang; name: string; flag: string }[] = [
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
];
