export interface Product {
  id: string;
  nameKey: string;
  name: { ar: string; en: string; ru: string };
  descKey: string;
  desc: { ar: string; en: string; ru: string };
  price: number;
  oldPrice: number;
  balance: string;
  image: string;
  category: string;
  subCategory: string;
  type: 'injected' | 'pulled' | 'single' | 'package';
}

export interface StoreCategory {
  id: string;
  nameKey: string;
  icon: string;
  color: string;
  image?: string;
  subCategories: SubCategory[];
}

export interface SubCategory {
  id: string;
  name: { ar: string; en: string; ru: string };
  type?: 'injected' | 'pulled';
  products: Product[];
}

const generateProducts = (catId: string, subId: string, subName: { ar: string; en: string; ru: string }, type: 'injected' | 'pulled' | 'single', count: number): Product[] => {
  const products: Product[] = [];
  for (let i = 1; i <= count; i++) {
    products.push({
      id: `${catId}-${subId}-${i}`,
      nameKey: `${subId}_${i}`,
      name: {
        ar: `${subName.ar} #${i}`,
        en: `${subName.en} #${i}`,
        ru: `${subName.ru} #${i}`,
      },
      descKey: `${subId}_desc_${i}`,
      desc: {
        ar: `منتج ${subName.ar} عالي الجودة - ضمان كامل`,
        en: `High quality ${subName.en} - Full guarantee`,
        ru: `Высококачественный ${subName.ru} - Полная гарантия`,
      },
      price: Math.floor(Math.random() * 200) + 20,
      oldPrice: Math.floor(Math.random() * 300) + 100,
      balance: `$${Math.floor(Math.random() * 5000) + 500}`,
      image: `https://images.unsplash.com/photo-${1550000000000 + Math.floor(Math.random() * 100000000)}-placeholder?w=300&h=200&fit=crop`,
      category: catId,
      subCategory: subId,
      type,
    });
  }
  return products;
};

export const storeCategories: StoreCategory[] = [
  {
    id: 'cards',
    nameKey: 'cat_cards',
    icon: '🃏',
    color: '#ff4444',
    image: 'https://i.postimg.cc/HLZ81Qdn/Screenshot-20260624-041026-Telegram.jpg',
    subCategories: [
      {
        id: 'novbv',
        name: { ar: 'NOVBV CC محقونة', en: 'NOVBV CC Injected', ru: 'NOVBV CC Инъекция' },
        type: 'injected',
        products: generateProducts('cards', 'novbv', { ar: 'NOVBV CC', en: 'NOVBV CC', ru: 'NOVBV CC' }, 'injected', 6),
      },
      {
        id: 'amex-inj',
        name: { ar: 'American Express محقونة', en: 'AMEX Injected', ru: 'AMEX Инъекция' },
        type: 'injected',
        products: generateProducts('cards', 'amex-inj', { ar: 'AMEX محقونة', en: 'AMEX Injected', ru: 'AMEX Инъекция' }, 'injected', 4),
      },
      {
        id: 'paypal-inj',
        name: { ar: 'PayPal محقونة', en: 'PayPal Injected', ru: 'PayPal Инъекция' },
        type: 'injected',
        products: generateProducts('cards', 'paypal-inj', { ar: 'PayPal محقونة', en: 'PayPal Injected', ru: 'PayPal Инъекция' }, 'injected', 4),
      },
      {
        id: 'credit',
        name: { ar: 'Credit Cards', en: 'Credit Cards', ru: 'Кредитные карты' },
        type: 'pulled',
        products: generateProducts('cards', 'credit', { ar: 'Credit Card', en: 'Credit Card', ru: 'Кредитная карта' }, 'pulled', 6),
      },
      {
        id: 'debit',
        name: { ar: 'Debit Cards', en: 'Debit Cards', ru: 'Дебетовые карты' },
        type: 'pulled',
        products: generateProducts('cards', 'debit', { ar: 'Debit Card', en: 'Debit Card', ru: 'Дебетовая карта' }, 'pulled', 6),
      },
      {
        id: 'amex-pulled',
        name: { ar: 'AMEX Cards', en: 'AMEX Cards', ru: 'Карты AMEX' },
        type: 'pulled',
        products: generateProducts('cards', 'amex-pulled', { ar: 'AMEX Card', en: 'AMEX Card', ru: 'Карта AMEX' }, 'pulled', 4),
      },
      {
        id: 'classic',
        name: { ar: 'Classic Cards', en: 'Classic Cards', ru: 'Классические карты' },
        type: 'pulled',
        products: generateProducts('cards', 'classic', { ar: 'Classic Card', en: 'Classic Card', ru: 'Классическая карта' }, 'pulled', 4),
      },
      {
        id: 'platinum',
        name: { ar: 'Platinum Cards', en: 'Platinum Cards', ru: 'Платиновые карты' },
        type: 'pulled',
        products: generateProducts('cards', 'platinum', { ar: 'Platinum Card', en: 'Platinum Card', ru: 'Платиновая карта' }, 'pulled', 4),
      },
    ],
  },
  {
    id: 'accounts',
    nameKey: 'cat_accounts',
    icon: '👤',
    color: '#4488ff',
    image: 'https://i.postimg.cc/gjv0jRFp/Screenshot-20260624-145416-Chrome.jpg',
    subCategories: [
      {
        id: 'amex-acc',
        name: { ar: 'حسابات American Express', en: 'AMEX Accounts', ru: 'Аккаунты AMEX' },
        products: generateProducts('accounts', 'amex-acc', { ar: 'حساب AMEX', en: 'AMEX Account', ru: 'Аккаунт AMEX' }, 'single', 4),
      },
      {
        id: 'bank-iban',
        name: { ar: 'الحسابات البنكية (IBAN)', en: 'Bank Accounts (IBAN)', ru: 'Банковские счета (IBAN)' },
        products: generateProducts('accounts', 'bank-iban', { ar: 'حساب بنكي', en: 'Bank Account', ru: 'Банковский счёт' }, 'single', 6),
      },
      {
        id: 'e-wallets',
        name: { ar: 'المحافظ الإلكترونية', en: 'E-Wallets', ru: 'Электронные кошельки' },
        products: generateProducts('accounts', 'e-wallets', { ar: 'محفظة إلكترونية', en: 'E-Wallet', ru: 'Электронный кошелёк' }, 'single', 4),
      },
      {
        id: 'digital-platforms',
        name: { ar: 'المنصات الرقمية', en: 'Digital Platforms', ru: 'Цифровые платформы' },
        products: generateProducts('accounts', 'digital-platforms', { ar: 'منصة رقمية', en: 'Digital Platform', ru: 'Цифровая платформа' }, 'single', 4),
      },
      {
        id: 'social-media',
        name: { ar: 'التواصل الاجتماعي', en: 'Social Media', ru: 'Соцсети' },
        products: generateProducts('accounts', 'social-media', { ar: 'حساب تواصل', en: 'Social Account', ru: 'Аккаунт соцсети' }, 'single', 4),
      },
      {
        id: 'emails-numbers',
        name: { ar: 'الإيميلات والأرقام', en: 'Emails & Numbers', ru: 'Почта и номера' },
        products: generateProducts('accounts', 'emails-numbers', { ar: 'إيميل/رقم', en: 'Email/Number', ru: 'Почта/Номер' }, 'single', 4),
      },
      {
        id: 'payment-gateways',
        name: { ar: 'بوابات الدفع الموثقة', en: 'Verified Payment Gateways', ru: 'Верифицированные платёжные шлюзы' },
        products: generateProducts('accounts', 'payment-gateways', { ar: 'بوابة دفع', en: 'Payment Gateway', ru: 'Платёжный шлюз' }, 'single', 3),
      },
    ],
  },
  {
    id: 'transfer',
    nameKey: 'cat_transfer',
    icon: '💸',
    color: '#44cc44',
    image: 'https://i.postimg.cc/1RcPgyV6/Screenshot-20260624-145343-Chrome.jpg',
    subCategories: [
      {
        id: 'amex-inject',
        name: { ar: 'حقن American Express', en: 'AMEX Injection', ru: 'Инъекция AMEX' },
        products: generateProducts('transfer', 'amex-inject', { ar: 'حقن AMEX', en: 'AMEX Injection', ru: 'Инъекция AMEX' }, 'single', 3),
      },
      {
        id: 'paypal-inject',
        name: { ar: 'حقن PayPal E-wallet', en: 'PayPal E-wallet Injection', ru: 'Инъекция PayPal' },
        products: generateProducts('transfer', 'paypal-inject', { ar: 'حقن PayPal', en: 'PayPal Injection', ru: 'Инъекция PayPal' }, 'single', 3),
      },
      {
        id: 'swift-sepa',
        name: { ar: 'التحويلات البنكية (SWIFT/SEPA)', en: 'Bank Transfers (SWIFT/SEPA)', ru: 'Банковские переводы (SWIFT/SEPA)' },
        products: generateProducts('transfer', 'swift-sepa', { ar: 'تحويل بنكي', en: 'Bank Transfer', ru: 'Банковский перевод' }, 'single', 4),
      },
      {
        id: 'flash-usdt',
        name: { ar: 'تحويلات Flash USDT', en: 'Flash USDT Transfers', ru: 'Flash USDT переводы' },
        products: generateProducts('transfer', 'flash-usdt', { ar: 'Flash USDT', en: 'Flash USDT', ru: 'Flash USDT' }, 'single', 3),
      },
      {
        id: 'flash-btc',
        name: { ar: 'تحويلات Flash Bitcoin', en: 'Flash Bitcoin Transfers', ru: 'Flash Bitcoin переводы' },
        products: generateProducts('transfer', 'flash-btc', { ar: 'Flash BTC', en: 'Flash BTC', ru: 'Flash BTC' }, 'single', 3),
      },
    ],
  },
  {
    id: 'gifts',
    nameKey: 'cat_gifts',
    icon: '🎁',
    color: '#ff8844',
    image: 'https://i.postimg.cc/MZtN2Hjm/Screenshot-20260624-145304-Chrome.jpg',
    subCategories: [
      {
        id: 'binance',
        name: { ar: 'بطاقات Binance', en: 'Binance Cards', ru: 'Карты Binance' },
        products: generateProducts('gifts', 'binance', { ar: 'Binance Card', en: 'Binance Card', ru: 'Карта Binance' }, 'single', 3),
      },
      {
        id: 'apple-itunes',
        name: { ar: 'بطاقات Apple / iTunes', en: 'Apple / iTunes Cards', ru: 'Карты Apple / iTunes' },
        products: generateProducts('gifts', 'apple-itunes', { ar: 'Apple Card', en: 'Apple Card', ru: 'Карта Apple' }, 'single', 4),
      },
      {
        id: 'gaming',
        name: { ar: 'بطاقات الألعاب', en: 'Gaming Cards', ru: 'Игровые карты' },
        products: generateProducts('gifts', 'gaming', { ar: 'بطاقة ألعاب', en: 'Gaming Card', ru: 'Игровая карта' }, 'single', 4),
      },
      {
        id: 'amazon',
        name: { ar: 'بطاقات Amazon', en: 'Amazon Cards', ru: 'Карты Amazon' },
        products: generateProducts('gifts', 'amazon', { ar: 'Amazon Card', en: 'Amazon Card', ru: 'Карта Amazon' }, 'single', 3),
      },
      {
        id: 'topup-services',
        name: { ar: 'خدمات الربط والشحن', en: 'Linking & Top-up Services', ru: 'Услуги привязки и пополнения' },
        products: generateProducts('gifts', 'topup-services', { ar: 'خدمة شحن', en: 'Top-up Service', ru: 'Услуга пополнения' }, 'single', 3),
      },
      {
        id: 'digital-subs',
        name: { ar: 'الاشتراكات الرقمية', en: 'Digital Subscriptions', ru: 'Цифровые подписки' },
        products: generateProducts('gifts', 'digital-subs', { ar: 'اشتراك رقمي', en: 'Digital Subscription', ru: 'Цифровая подписка' }, 'single', 4),
      },
    ],
  },
  {
    id: 'topup',
    nameKey: 'cat_topup',
    icon: '📱',
    color: '#aa44ff',
    image: 'https://i.postimg.cc/SxcG41vs/Screenshot-20260624-151141-Gallery.jpg',
    subCategories: [
      {
        id: 'audio-apps',
        name: { ar: 'شحن التطبيقات الصوتية', en: 'Audio App Top-up', ru: 'Пополнение аудио-приложений' },
        products: generateProducts('topup', 'audio-apps', { ar: 'شحن صوتي', en: 'Audio Top-up', ru: 'Аудио пополнение' }, 'single', 4),
      },
      {
        id: 'video-apps',
        name: { ar: 'شحن التطبيقات المرئية', en: 'Video App Top-up', ru: 'Пополнение видео-приложений' },
        products: generateProducts('topup', 'video-apps', { ar: 'شحن مرئي', en: 'Video Top-up', ru: 'Видео пополнение' }, 'single', 4),
      },
    ],
  },
  {
    id: 'proxy',
    nameKey: 'cat_proxy',
    icon: '🔒',
    color: '#44cccc',
    image: 'https://i.postimg.cc/Hsrg6XP8/Screenshot-20260624-013031-Google.jpg',
    subCategories: [
      {
        id: 'proxy-encryption',
        name: { ar: 'بروكسيات الحماية والتشفير', en: 'Protection & Encryption Proxies', ru: 'Прокси защиты и шифрования' },
        products: generateProducts('proxy', 'proxy-encryption', { ar: 'بروكسي تشفير', en: 'Encryption Proxy', ru: 'Прокси шифрования' }, 'single', 4),
      },
      {
        id: 'ai-unlimited',
        name: { ar: 'ذكاء اصطناعي (AI) بلا قيود', en: 'AI Without Limits', ru: 'ИИ без ограничений' },
        products: generateProducts('proxy', 'ai-unlimited', { ar: 'AI بلا قيود', en: 'Unlimited AI', ru: 'Безлимитный ИИ' }, 'single', 3),
      },
      {
        id: 'd2-links',
        name: { ar: 'مواقع وروابط D2', en: 'D2 Sites & Links', ru: 'D2 сайты и ссылки' },
        products: generateProducts('proxy', 'd2-links', { ar: 'رابط D2', en: 'D2 Link', ru: 'D2 ссылка' }, 'single', 3),
      },
      {
        id: 'academy',
        name: { ar: 'أكاديمية النخبة للتفريغ', en: 'Elite Academy', ru: 'Элитная академия' },
        products: generateProducts('proxy', 'academy', { ar: 'كورس تدريبي', en: 'Training Course', ru: 'Обучающий курс' }, 'single', 3),
      },
      {
        id: 'elite-services',
        name: { ar: 'خدمات النخبة التقنية', en: 'Elite Tech Services', ru: 'Элитные тех. услуги' },
        products: generateProducts('proxy', 'elite-services', { ar: 'خدمة تقنية', en: 'Tech Service', ru: 'Тех. услуга' }, 'single', 3),
      },
    ],
  },
];

export const toolCategories = [
  { id: 'tool-1', nameKey: 'tool_1', descKey: 'tool_1_desc', icon: '🔍', color: '#ff4444' },
  { id: 'tool-2', nameKey: 'tool_2', descKey: 'tool_2_desc', icon: '💳', color: '#4488ff' },
  { id: 'tool-3', nameKey: 'tool_3', descKey: 'tool_3_desc', icon: '🔧', color: '#44cc44' },
  { id: 'tool-4', nameKey: 'tool_4', descKey: 'tool_4_desc', icon: '📋', color: '#ff8844' },
  { id: 'tool-5', nameKey: 'tool_5', descKey: 'tool_5_desc', icon: '🛡️', color: '#aa44ff' },
  { id: 'tool-6', nameKey: 'tool_6', descKey: 'tool_6_desc', icon: '⚡', color: '#44cccc' },
  { id: 'tool-7', nameKey: 'tool_7', descKey: 'tool_7_desc', icon: '🧹', color: '#cccc44' },
  { id: 'tool-8', nameKey: 'tool_8', descKey: 'tool_8_desc', icon: '🤖', color: '#cc44cc' },
  { id: 'tool-9', nameKey: 'tool_9', descKey: 'tool_9_desc', icon: '💀', color: '#ff4488' },
  { id: 'tool-10', nameKey: 'tool_10', descKey: 'tool_10_desc', icon: '🎯', color: '#44ff88' },
];

export const getAllProducts = (): Product[] => {
  const products: Product[] = [];
  storeCategories.forEach(cat => {
    cat.subCategories.forEach(sub => {
      products.push(...sub.products);
    });
  });
  return products;
};

export const getProductById = (id: string): Product | undefined => {
  return getAllProducts().find(p => p.id === id);
};
