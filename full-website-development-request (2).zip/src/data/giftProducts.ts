import type { StoreProduct } from './storeProducts';

export const giftSubCategories = [
  { id: 'binance', name: 'Binance Cards', shortName: 'BNC', icon: '🟡', image: 'https://i.postimg.cc/d0G4gZmk/images.png', color: '#f0b90b' },
  { id: 'apple', name: 'Apple / iTunes', shortName: 'APL', icon: '🍎', image: 'https://i.postimg.cc/Wz59XR6R/e9cdd1eb980a9c3a090a94008f4bdf360cf988a86158c35fae8b2d505c09e82c.jpg', color: '#a2aaad' },
  { id: 'amazon', name: 'Amazon Cards', shortName: 'AMZ', icon: '📦', image: 'https://i.postimg.cc/FH76CKBq/images-(1).png', color: '#ff9900' },
  { id: 'gaming', name: 'Gaming Cards', shortName: 'GAM', icon: '🎮', image: 'https://i.postimg.cc/YCnX1w2x/1782251397122.png', color: '#00d4ff' },
  { id: 'subs', name: 'Subscriptions', shortName: 'SUB', icon: '📺', image: 'https://i.postimg.cc/yN3wxNhh/1782251253760.png', color: '#e50914' },
  { id: 'services', name: 'Linking Services', shortName: 'SRV', icon: '🔗', image: 'https://i.postimg.cc/hPSWscgW/Screenshot-20260624-004536-Google.jpg', color: '#44cc44' },
];

const binanceImg = 'https://i.postimg.cc/d0G4gZmk/images.png';
const appleImg = 'https://i.postimg.cc/Wz59XR6R/e9cdd1eb980a9c3a090a94008f4bdf360cf988a86158c35fae8b2d505c09e82c.jpg';
const amazonImg = 'https://i.postimg.cc/FH76CKBq/images-(1).png';

const binanceDetail = {
  ar: '🔒 بروتوكول الأمان - بطاقات Binance\n\nلضمان سلامة الأصول وتجنب أي ملاحقة أو حظر، يجب اتباع مسار العمليات التالي بدقة:\n\n• سحب الكود: البدء بسحب القيمة الأصلية من بطاقة الهدايا\n• التحويل البيني: تبديل العملة من USDT إلى BTC داخل منصة "باينانس"\n• النقل الآمن: إرسال رصيد البيتكوين إلى محفظة "تراست وليت" (Trust Wallet)\n• إعادة التبديل: تحويل البيتكوين مجدداً إلى USDT داخل المحفظة\n• التصفية النهائية: إرسال USDT إلى أي منصة تدعم بيع P2P\n\n[ ⚠️ تنبيه أمني - آلية الخلاط ]\nتعتبر هذه الدورة بمثابة "خلاط رقمي" تهدف إلى تشتيت مصدر الأموال وكسر تتبعها. الهدف: حماية حسابك من البلاغات والحظر.',
  en: '🔒 Security Protocol - Binance Cards\n\nTo ensure asset safety and avoid tracking:\n\n• Redeem Code: Extract the original value from the gift card\n• Inter-exchange: Swap USDT to BTC inside Binance\n• Safe Transfer: Send BTC to Trust Wallet\n• Re-swap: Convert BTC back to USDT in wallet\n• Final Clearance: Send USDT to any P2P platform\n\n[ ⚠️ Security Notice - Mixer Protocol ]\nThis cycle acts as a "digital mixer" to scatter fund sources and break tracking.',
};

const appleDetail = {
  ar: '🍎 بطاقات Apple / iTunes\n\n• أكواد "مصيدة" - اشحن فوراً\n• لا تترك الكود أكثر من 24 ساعة\n• صالح للمتجر الأمريكي/الدولي\n\n[ ⚠️ تحذير ]\nأكواد مصيدة: يجب الشحن خلال 24 ساعة من الاستلام وإلا ستفقد صلاحيتها.',
  en: '🍎 Apple / iTunes Cards\n\n• Trap codes - Redeem immediately\n• Don\'t leave code more than 24 hours\n• Valid for US/International store\n\n[ ⚠️ Warning ]\nTrap codes: Must redeem within 24 hours of receipt or they will expire.',
};

const amazonDetail = {
  ar: '📦 بطاقات Amazon\n\n• أكواد "مصيدة" للاستخدام المباشر فقط\n• يُمنع شراء بطاقات أخرى بها\n• اشحن خلال 24 ساعة\n\n[ ⚠️ تحذير ]\nأكواد مصيدة: يجب الشحن خلال 24 ساعة وإلا ستفقد صلاحيتها.',
  en: '📦 Amazon Cards\n\n• Trap codes for direct use only\n• Do NOT buy other cards with them\n• Redeem within 24 hours\n\n[ ⚠️ Warning ]\nTrap codes: Must redeem within 24 hours.',
};

const gamingDetail = {
  ar: '🎮 بطاقات الألعاب\n\n• أكواد "مصيدة" - اشحن فوراً (24 ساعة)\n• تأكد من تطابق الريجون (Region) قبل التفعيل\n\n[ ⚠️ تحذير ]\nأكواد مصيدة: يجب الشحن خلال 24 ساعة من الاستلام.',
  en: '🎮 Gaming Cards\n\n• Trap codes - Redeem immediately (24 hours)\n• Verify region match before activation\n\n[ ⚠️ Warning ]\nTrap codes: Must redeem within 24 hours.',
};

const subsDetail = {
  ar: '📺 الاشتراكات الرقمية\n\n• حسابات "مصيدة" - يمنع تغيير الإيميل أو الباسورد لضمان الضمان\n• اشحنها فوراً\n• الاشتراك لمدة سنة كاملة\n\n[ ⚠️ تحذير ]\nيمنع تغيير بيانات الدخول. أي تعديل يلغي الضمان فوراً.',
  en: '📺 Digital Subscriptions\n\n• Trap accounts - Do NOT change email or password to maintain warranty\n• Activate immediately\n• Full year subscription\n\n[ ⚠️ Warning ]\nDo not change login credentials. Any modification voids the warranty.',
};

const serviceDetail = {
  ar: '🔗 خدمات الربط والشحن\n\n• خدمة توثيق تتطلب تنفيذاً فورياً\n• لضمان قبول وسيلة الدفع قبل التبليغ\n\n[ ⚠️ تحذير ]\nيجب التنفيذ فوراً لضمان نجاح العملية.',
  en: '🔗 Linking & Binding Services\n\n• Verification service requiring immediate execution\n• To ensure payment method acceptance before reporting\n\n[ ⚠️ Warning ]\nMust execute immediately to ensure success.',
};

export const giftProducts: StoreProduct[] = [
  // Binance
  ...[
    { id: 'bnc-200', name: 'Binance Gift $200', balance: '$200', price: 50, oldPrice: 100 },
    { id: 'bnc-400', name: 'Binance Gift $400', balance: '$400', price: 99, oldPrice: 200 },
    { id: 'bnc-600', name: 'Binance Gift $600', balance: '$600', price: 199, oldPrice: 300 },
    { id: 'bnc-800', name: 'Binance Gift $800', balance: '$800', price: 399, oldPrice: 500 },
    { id: 'bnc-1000', name: 'Binance Gift $1,000', balance: '$1,000', price: 499, oldPrice: 650 },
  ].map(p => ({ ...p, image: binanceImg, category: 'gifts', subCategory: 'binance', type: 'injected' as const, desc: { ar: 'أكواد "مصيدة" - Gift Card Binance', en: '"Trap" codes - Binance Gift Card' }, details: binanceDetail })),

  // Apple
  ...[
    { id: 'apl-50', name: 'Apple/iTunes $50', balance: '$50', price: 30, oldPrice: 50 },
    { id: 'apl-100', name: 'Apple/iTunes $100', balance: '$100', price: 65, oldPrice: 100 },
    { id: 'apl-200', name: 'Apple/iTunes $200', balance: '$200', price: 120, oldPrice: 200 },
    { id: 'apl-500', name: 'Apple/iTunes $500', balance: '$500', price: 280, oldPrice: 500 },
  ].map(p => ({ ...p, image: appleImg, category: 'gifts', subCategory: 'apple', type: 'injected' as const, desc: { ar: 'أكواد "مصيدة" - Gift Card Apple/iTunes', en: '"Trap" codes - Apple/iTunes Gift Card' }, details: appleDetail })),

  // Amazon
  ...[
    { id: 'amz-100', name: 'Amazon Gift $100', balance: '$100', price: 60, oldPrice: 100 },
    { id: 'amz-300', name: 'Amazon Gift $300', balance: '$300', price: 170, oldPrice: 300 },
    { id: 'amz-500', name: 'Amazon Gift $500', balance: '$500', price: 260, oldPrice: 500 },
    { id: 'amz-1000', name: 'Amazon Gift $1,000', balance: '$1,000', price: 500, oldPrice: 1000 },
  ].map(p => ({ ...p, image: amazonImg, category: 'gifts', subCategory: 'amazon', type: 'injected' as const, desc: { ar: 'أكواد "مصيدة" لمتجر أمازون - Gift Card Amazon', en: '"Trap" codes - Amazon Gift Card' }, details: amazonDetail })),

  // Gaming
  { id: 'gm-ps', name: 'PlayStation $100', balance: '$100', price: 35, oldPrice: 100, image: 'https://i.postimg.cc/GpDkH04H/images-(20).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة PlayStation Store $100', en: 'PlayStation Store $100 Card' }, details: gamingDetail },
  { id: 'gm-xbox', name: 'Xbox $100', balance: '$100', price: 35, oldPrice: 100, image: 'https://i.postimg.cc/6pkZsHYP/51T1yq-Um-A1L-SL1000-(1).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Xbox Store $100', en: 'Xbox Store $100 Card' }, details: gamingDetail },
  { id: 'gm-steam', name: 'Steam $100', balance: '$100', price: 35, oldPrice: 100, image: 'https://i.postimg.cc/9Q74BdCb/635496122.png', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Steam $100', en: 'Steam $100 Card' }, details: gamingDetail },
  { id: 'gm-gplay', name: 'Google Play $100', balance: '$100', price: 45, oldPrice: 100, image: 'https://i.postimg.cc/nVSCbRLY/images-(2).png', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Google Play $100', en: 'Google Play $100 Card' }, details: gamingDetail },
  { id: 'gm-razer', name: 'Razer Gold $100', balance: '$100', price: 45, oldPrice: 100, image: 'https://i.postimg.cc/MTKKgVJ2/images-(21).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Razer Gold $100', en: 'Razer Gold $100 Card' }, details: gamingDetail },
  { id: 'gm-roblox', name: 'Roblox $100', balance: '$100', price: 35, oldPrice: 100, image: 'https://i.postimg.cc/7Z3H6mqd/images-(22).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Roblox $100', en: 'Roblox $100 Card' }, details: gamingDetail },
  { id: 'gm-ebay', name: 'eBay $100', balance: '$100', price: 30, oldPrice: 100, image: 'https://i.postimg.cc/mrVT3k1f/images-(23).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة eBay $100', en: 'eBay $100 Card' }, details: gamingDetail },
  { id: 'gm-ms', name: 'Microsoft $100', balance: '$100', price: 30, oldPrice: 100, image: 'https://i.postimg.cc/HLLkhbgm/images-(24).jpg', category: 'gifts', subCategory: 'gaming', type: 'injected', desc: { ar: 'بطاقة Microsoft $100', en: 'Microsoft $100 Card' }, details: gamingDetail },

  // Subscriptions
  { id: 'sub-netflix', name: 'Netflix Premium (1 Year)', balance: '1 Year', price: 50, oldPrice: 180, image: 'https://i.postimg.cc/HxcspHn9/images-(3).png', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك Netflix Premium لمدة سنة كاملة', en: 'Netflix Premium 1 Year Subscription' }, details: subsDetail },
  { id: 'sub-spotify', name: 'Spotify Family (1 Year)', balance: '1 Year', price: 30, oldPrice: 120, image: 'https://i.postimg.cc/Jzp1ZtBp/images-(4).png', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك Spotify Family لمدة سنة', en: 'Spotify Family 1 Year Subscription' }, details: subsDetail },
  { id: 'sub-youtube', name: 'YouTube Premium (1 Year)', balance: '1 Year', price: 30, oldPrice: 140, image: 'https://i.postimg.cc/L4j2vx1S/images-(26).jpg', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك YouTube Premium لمدة سنة', en: 'YouTube Premium 1 Year Subscription' }, details: subsDetail },
  { id: 'sub-disney', name: 'Disney+ / Crunchyroll (1 Year)', balance: '1 Year', price: 25, oldPrice: 100, image: 'https://i.postimg.cc/Nf4YvLb0/crunchyrolldisney.png', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك Disney+ / Crunchyroll لمدة سنة', en: 'Disney+ / Crunchyroll 1 Year' }, details: subsDetail },
  { id: 'sub-canva', name: 'Canva Pro (1 Year)', balance: '1 Year', price: 20, oldPrice: 120, image: 'https://i.postimg.cc/VNSctgwL/642cf193d2c9f.png', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك Canva Pro لمدة سنة', en: 'Canva Pro 1 Year Subscription' }, details: subsDetail },
  { id: 'sub-vpn', name: 'NordVPN / ExpressVPN (1 Year)', balance: '1 Year', price: 25, oldPrice: 100, image: 'https://i.postimg.cc/vTvRySrV/images-(27).jpg', category: 'gifts', subCategory: 'subs', type: 'injected', desc: { ar: 'اشتراك NordVPN / ExpressVPN لمدة سنة', en: 'NordVPN / ExpressVPN 1 Year' }, details: subsDetail },

  // Services
  { id: 'srv-applepay', name: 'Apple/Google Pay Binding', balance: 'Service', price: 40, oldPrice: 100, image: 'https://i.postimg.cc/hPSWscgW/Screenshot-20260624-004536-Google.jpg', category: 'gifts', subCategory: 'services', type: 'injected', desc: { ar: 'خدمة توثيق وربط Apple Pay / Google Pay', en: 'Apple Pay / Google Pay Binding Service' }, details: serviceDetail },
];

export const getGiftProducts = (subId: string) => giftProducts.filter(p => p.subCategory === subId);
