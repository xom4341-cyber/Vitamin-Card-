export interface TopupPackage {
  id: string;
  app: string;
  amount: string;
  price: number;
  image: string;
  baseQty: number; // for custom order calculation
}

export interface TopupApp {
  id: string;
  name: string;
  icon: string;
  image: string;
  currency: string;
  baseQty: number;
  basePrice: number;
}

export const topupSections = [
  { id: 'visual', name: { ar: 'شحن التطبيقات المرئية', en: 'Visual Apps Top-up' }, icon: '🎬', image: 'https://i.postimg.cc/pTjKhf76/1782248179435.png' },
  { id: 'audio', name: { ar: 'شحن التطبيقات الصوتية', en: 'Audio/Live Apps Top-up' }, icon: '🎧', image: 'https://i.postimg.cc/sDH1zBHQ/Screenshot-20260623-234908-Google.jpg' },
];

export const visualPackages: TopupPackage[] = [
  // TikTok
  { id: 'tt-50k', app: 'TikTok', amount: '50K', price: 85, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 50000 },
  { id: 'tt-80k', app: 'TikTok', amount: '80K', price: 120, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 80000 },
  { id: 'tt-100k', app: 'TikTok', amount: '100K', price: 160, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 100000 },
  { id: 'tt-200k', app: 'TikTok', amount: '200K', price: 249, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 200000 },
  { id: 'tt-500k', app: 'TikTok', amount: '500K', price: 499, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 500000 },
  { id: 'tt-700k', app: 'TikTok', amount: '700K', price: 699, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 700000 },
  { id: 'tt-1m', app: 'TikTok', amount: '1M', price: 999, image: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', baseQty: 1000000 },
  // Jaco
  { id: 'jc-25k', app: 'Jaco', amount: '25K', price: 85, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 25000 },
  { id: 'jc-50k', app: 'Jaco', amount: '50K', price: 149, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 50000 },
  { id: 'jc-100k', app: 'Jaco', amount: '100K', price: 249, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 100000 },
  { id: 'jc-200k', app: 'Jaco', amount: '200K', price: 399, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 200000 },
  { id: 'jc-500k', app: 'Jaco', amount: '500K', price: 699, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 500000 },
  { id: 'jc-700k', app: 'Jaco', amount: '700K', price: 999, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 700000 },
  { id: 'jc-1m', app: 'Jaco', amount: '1M', price: 1199, image: 'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', baseQty: 1000000 },
];

export const audioApps: TopupApp[] = [
  { id: 'bigo', name: 'Bigo Live', icon: '🔴', image: 'https://i.postimg.cc/ncXpv3T9/Screenshot-20260614-172944.jpg', currency: 'ماسة', baseQty: 25000, basePrice: 99 },
  { id: 'likee', name: 'Likee', icon: '💜', image: 'https://i.postimg.cc/NGVWwB7k/Screenshot-20260614-173012.jpg', currency: 'ماسة', baseQty: 20000, basePrice: 85 },
  { id: 'mico', name: 'Mico', icon: '🟡', image: 'https://i.postimg.cc/rpQPZkws/Screenshot-20260614-173049.jpg', currency: 'كوينز', baseQty: 250000, basePrice: 99 },
  { id: 'yoyo', name: 'YoYo', icon: '🟢', image: 'https://i.postimg.cc/4nkLH4B8/Screenshot-20260614-173107.jpg', currency: 'كوينز', baseQty: 300000, basePrice: 75 },
  { id: 'yoho', name: 'YoHo', icon: '🔵', image: 'https://i.postimg.cc/cLsqFTB7/Screenshot-20260614-173214.jpg', currency: 'كوينز', baseQty: 2000000, basePrice: 75 },
  { id: 'hiyoo', name: 'Hiyoo', icon: '🟣', image: 'https://i.postimg.cc/0y53Yj8s/Screenshot-20260614-173521.jpg', currency: 'كوينز', baseQty: 300000, basePrice: 85 },
  { id: 'hiya', name: 'Hiya', icon: '🩵', image: 'https://i.postimg.cc/CLhJt29f/Screenshot-20260614-173539.jpg', currency: 'كوينز', baseQty: 300000, basePrice: 119 },
  { id: 'waho', name: 'Waho', icon: '🩷', image: 'https://i.postimg.cc/pTQYcQZ5/Screenshot-20260614-173554.jpg', currency: 'كوينز', baseQty: 1500000, basePrice: 99 },
  { id: 'xena', name: 'Xena Live', icon: '🧡', image: 'https://i.postimg.cc/wT45rjXg/Screenshot-20260614-172901.jpg', currency: 'كوينز', baseQty: 1000000, basePrice: 99 },
];

export const topupWarning = {
  ar: '⚠️ تنبيه أمني هام (قاعدة الـ 3 ساعات):\n• يُفضل استخدام حساب جديد للشحن\n• لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات\n• أي بلاغ على البطاقة يؤدي لاسترداد الشحن وحظر الحساب نهائياً',
  en: '⚠️ Important Security Notice (3-Hour Rule):\n• Use a new account for top-up\n• Don\'t leave balance in account for more than 3 hours\n• Any card report leads to chargeback and permanent account ban',
};
