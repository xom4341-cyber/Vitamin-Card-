export interface ToolProduct {
  id: string;
  name: string;
  desc: { ar: string; en: string };
  details: { ar: string; en: string };
  price: number;
  icon: string;
  image: string;
}

export interface ToolSection {
  id: string;
  name: string;
  desc: { ar: string; en: string };
  icon: string;
  color: string;
  image: string;
  products: ToolProduct[];
}

const IMG = {
  radar: 'https://images.pexels.com/photos/5380589/pexels-photo-5380589.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  code: 'https://images.pexels.com/photos/207580/pexels-photo-207580.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  chip: 'https://images.pexels.com/photos/37657435/pexels-photo-37657435.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  hardware: 'https://images.pexels.com/photos/37878823/pexels-photo-37878823.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  identity: 'https://images.pexels.com/photos/37694202/pexels-photo-37694202.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  privacy: 'https://images.pexels.com/photos/37787963/pexels-photo-37787963.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  bypass: 'https://images.pexels.com/photos/5952651/pexels-photo-5952651.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  cleanup: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  ai: 'https://images.pexels.com/photos/5380603/pexels-photo-5380603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  advanced: 'https://images.pexels.com/photos/14000470/pexels-photo-14000470.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
  opsCmd: 'https://images.pexels.com/photos/5380618/pexels-photo-5380618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400',
};

export const toolSections: ToolSection[] = [
  {
    id: 'validator', name: 'Validator Suite', icon: '🔍', color: '#ff4444',
    desc: { ar: 'وحدة فحص البيانات والتدقيق الأمني الشامل', en: 'Data verification and comprehensive security auditing unit' },
    image: IMG.radar,
    products: [
      { id: 'v1', name: 'Global BIN & Balance Intel', icon: '📡', image: IMG.radar, price: 180, desc: { ar: 'فحص شامل للبطاقة، البنك، الدولة، مستوى الحماية، وتقدير الرصيد', en: 'Comprehensive card, bank, country, protection level scan & balance estimate' }, details: { ar: 'أداة ذكية لتحليل BIN البطاقة. توفر بيانات دقيقة حول البنك المصدر، الدولة، نوع البطاقة (Gold/Platinum)، ومستوى حماية 3D، مع تقدير للرصيد المتاح لحظياً قبل الاستخدام.', en: 'Smart BIN analysis tool providing accurate issuing bank data, country, card type (Gold/Platinum), 3D protection level, with real-time available balance estimation.' } },
      { id: 'v2', name: 'CC/BIN Validator', icon: '✅', image: IMG.radar, price: 45, desc: { ar: 'فرز البطاقات الصالحة (Live) واستبعاد التالفة فوراً', en: 'Sort live cards and instantly exclude dead ones' }, details: { ar: 'تدقيق لحظي للبطاقات ومطابقتها مع بوابات الدفع للتأكد من حالة (Live). الفائدة: توفير الوقت والجهد وتجنب الحظر من البنوك.', en: 'Real-time card validation against payment gateways to confirm Live status. Saves time and avoids bank blocks.' } },
      { id: 'v3', name: 'Site/Domain Scanner', icon: '🛡️', image: IMG.radar, price: 60, desc: { ar: 'كشف المصائد الأمنية (Honey Pots) قبل الاستهداف', en: 'Detect security Honey Pots before targeting' }, details: { ar: 'تحليل الروابط بحثاً عن برمجيات خبيثة أو "أواني عسل" أمنية. الفائدة: حماية خصوصيتك وجهازك من التتبع أثناء العمليات.', en: 'Link analysis for malware or security honey pots. Protects your privacy and device from tracking.' } },
      { id: 'v4', name: 'Phone/Carrier Lookup', icon: '📶', image: IMG.radar, price: 35, desc: { ar: 'التحقق من نشاط الأرقام لضمان وصول الـ OTP', en: 'Verify number activity to ensure OTP delivery' }, details: { ar: 'فحص حالة الأرقام (Active/Inactive) وتحديد الشركة المزودة للخدمة. الفائدة: ضمان نجاح عملية سحب كود التحقق (OTP) من الضحية.', en: 'Check number status (Active/Inactive) and identify carrier. Ensures successful OTP extraction.' } },
      { id: 'v5', name: 'Credential Auditor', icon: '🔎', image: IMG.radar, price: 55, desc: { ar: 'تنقية الحسابات والإيميلات الصالحة من قوائم الجملة', en: 'Filter valid accounts from bulk lists' }, details: { ar: 'أداة مسح جماعي للحسابات البنكية ومواقع التجارة. الفائدة: التركيز على الصيد الثمين وتجنب الحسابات المعطلة.', en: 'Bulk scanning tool for bank accounts and e-commerce sites. Focus on valuable targets.' } },
      { id: 'v6', name: 'Gateway Auditor', icon: '🔓', image: IMG.radar, price: 95, desc: { ar: 'اختبار بوابات الدفع لاكتشاف ثغرات الـ 3D', en: 'Test payment gateways for 3D vulnerabilities' }, details: { ar: 'محاكاة عمليات شراء لاكتشاف ما إذا كانت البوابة تطلب تحققاً إضافياً (3D Secure). الفائدة: تحديد البوابات "الضعيفة" التي تسهل عملية التفريغ.', en: 'Simulate purchases to discover if gateway requires 3D Secure. Identify weak gateways.' } },
      { id: 'v7', name: 'E-Commerce Crawler', icon: '🕷️', image: IMG.code, price: 85, desc: { ar: 'فحص المتاجر لاستخراج ثغرات XSS/SQLi', en: 'Scan stores for XSS/SQLi vulnerabilities' }, details: { ar: 'مسح كود الموقع للبحث عن ثغرات حقن البيانات التي تسمح بالوصول لقواعد بيانات العملاء. الفائدة: الحصول على البيانات الخام مباشرة.', en: 'Scan site code for injection vulnerabilities to access customer databases directly.' } },
      { id: 'v8', name: 'App Security Auditor', icon: '📱', image: IMG.code, price: 110, desc: { ar: 'تحليل ثغرات تطبيقات الجوال (iOS/Android)', en: 'Analyze mobile app vulnerabilities (iOS/Android)' }, details: { ar: 'تفكيك حزمة التطبيق وفحص بروتوكولات التشفير. الفائدة: اكتشاف ثغرات لسحب بيانات البطاقات المخزنة في التطبيقات.', en: 'Decompile app packages and inspect encryption protocols to discover stored card data vulnerabilities.' } },
      { id: 'v9', name: 'Deep Vulnerability Scanner', icon: '🔬', image: IMG.code, price: 200, desc: { ar: 'فحص البنية التحتية لثغرات Zero-Day', en: 'Infrastructure scan for Zero-Day vulnerabilities' }, details: { ar: 'فحص السيرفرات والشبكات للبحث عن ثغرات غير مكتشفة (Zero-Day) لا توجد لها تحديثات أمنية. الفائدة: اختراق الأنظمة الحصينة.', en: 'Scan servers and networks for undiscovered Zero-Day vulnerabilities with no security patches available.' } },
    ],
  },
  {
    id: 'emv', name: 'EMV & Logic', icon: '💳', color: '#4488ff',
    desc: { ar: 'البرمجيات التشغيلية لعمليات الحقن والبرمجة', en: 'Operational software for injection and programming' },
    image: IMG.chip,
    products: [
      { id: 'e1', name: 'X2 Global Software', icon: '💿', image: IMG.chip, price: 150, desc: { ar: 'الأداة الأساسية لحقن بيانات المسارات (Track 1 & 2) على الشريحة', en: 'Core tool for injecting Track 1 & 2 data onto chips' }, details: { ar: 'البرنامج الأقوى عالمياً لنقل البيانات إلى الشريحة الذكية (IC Chip) لضمان قبولها في أجهزة الصراف الآلي (ATM). يتطلب بطاقة JCOP خام للعمل.', en: 'World\'s most powerful program for transferring data to IC Chips for ATM acceptance. Requires blank JCOP card.' } },
      { id: 'e2', name: 'JCOP Manager', icon: '⚙️', image: IMG.chip, price: 80, desc: { ar: 'تهيئة وتنسيق البطاقات الخام (J2A040) قبل الحقن', en: 'Format and prepare blank cards (J2A040) for injection' }, details: { ar: 'أداة متخصصة لتهيئة البطاقات الفارغة وتجهيزها برمجياً لاستقبال بيانات المسارات. ضرورية لضمان التوافق التام مع أجهزة القراءة.', en: 'Specialized tool for preparing blank cards to receive track data. Essential for reader compatibility.' } },
      { id: 'e3', name: 'ARQC Generator', icon: '🔑', image: IMG.chip, price: 100, desc: { ar: 'توليد أكواد المصادقة (ARQC) لإتمام عمليات السحب', en: 'Generate ARQC authentication codes for ATM withdrawals' }, details: { ar: 'تولد الأداة كود المصادقة المطلوب من قبل الصرافة الآلية لإتمام عملية السحب. لا تكتمل العملية بدون هذا الكود في أنظمة EMV.', en: 'Generates authentication codes required by ATMs to complete withdrawal. Operations cannot complete without this code in EMV systems.' } },
      { id: 'e4', name: 'POS Emulator', icon: '🖥️', image: IMG.chip, price: 90, desc: { ar: 'محاكاة نقاط البيع (POS) للاختبار البرمجي', en: 'POS simulation for software testing' }, details: { ar: 'بيئة وهمية لاختبار البطاقة برمجياً قبل الاستخدام الفعلي. الفائدة: اكتشاف أي أخطاء في البيانات قبل التوجه للمواقع الحقيقية.', en: 'Virtual environment for testing cards before real use. Discover data errors before going to real sites.' } },
      { id: 'e5', name: 'ISO8583 Analyzer', icon: '📊', image: IMG.code, price: 70, desc: { ar: 'تحليل رسائل البنك وفك رموز الرفض التقني', en: 'Analyze bank messages and decode technical rejections' }, details: { ar: 'أداة تشخيصية تقرأ رسائل الـ ISO8583 المتبادلة بين البطاقة والبنك لتحديد سبب الرفض بدقة متناهية.', en: 'Diagnostic tool reading ISO8583 messages between card and bank to precisely identify rejection reasons.' } },
      { id: 'e6', name: 'Gateway Bypass Script', icon: '🛡️', image: IMG.code, price: 90, desc: { ar: 'سكربت لتجاوز حماية الـ 3D في بوابات الشراء', en: 'Script to bypass 3D protection in payment gateways' }, details: { ar: 'يلتف حول أنظمة التحقق الثنائي (3D Secure) في بوابات الشراء، مما يقلل بشكل كبير من نسبة الرفض.', en: 'Circumvents 3D Secure verification systems, significantly reducing rejection rates.' } },
      { id: 'e7', name: 'Mass-Linker v3', icon: '🔗', image: IMG.code, price: 120, desc: { ar: 'نظام أوتوماتيكي لربط الحسابات بالجملة', en: 'Automated system for bulk account linking' }, details: { ar: 'أداة مصممة للعمل بنظام (Massive Operations)؛ تقوم بربط كميات ضخمة من الحسابات بالمحافظ في وقت واحد.', en: 'Designed for massive operations; links huge quantities of accounts to wallets simultaneously.' } },
    ],
  },
  {
    id: 'hardware', name: 'Hardware & Skimmers', icon: '🔧', color: '#44cc44',
    desc: { ar: 'التجهيزات الفيزيائية وأجهزة الالتقاط المادية', en: 'Physical equipment and capture devices' },
    image: IMG.hardware,
    products: [
      { id: 'h1', name: 'MSR605 / MSR X6', icon: '💽', image: IMG.hardware, price: 180, desc: { ar: 'كاتب الشريط المغناطيسي (Magnetic Stripe Writer)', en: 'Magnetic Stripe Writer' }, details: { ar: 'أداة احترافية للقراءة والكتابة على الشريط المغناطيسي الأسود خلف البطاقات. تدعم كافة المسارات (Track 1, 2, 3) وتتوافق مع كافة أنظمة التشغيل.', en: 'Professional tool for reading/writing magnetic stripes behind cards. Supports all tracks (1, 2, 3) and all operating systems.' } },
      { id: 'h2', name: 'Omnikey Writer', icon: '✨', image: IMG.hardware, price: 150, desc: { ar: 'كاتب الشريحة الذهبية (Smart Chip Writer)', en: 'Smart Chip Writer' }, details: { ar: 'جهاز عالي الدقة متخصص للكتابة على الشريحة الذكية (IC Chip). يتميز باستقرار عالٍ في نقل البيانات لمنع تلف الشريحة أثناء البرمجة.', en: 'High-precision device for writing to IC Chips. Features high stability to prevent chip damage during programming.' } },
      { id: 'h3', name: 'RFID/NFC Readers', icon: '📡', image: IMG.hardware, price: 130, desc: { ar: 'أجهزة الدفع اللاتلامسي (Tap-to-Pay)', en: 'Contactless payment devices (Tap-to-Pay)' }, details: { ar: 'أجهزة لالتقاط بيانات البطاقات عن بُعد عبر تقنية NFC. ضرورية للعمليات السريعة التي تعتمد على خاصية الدفع اللاتلامسي.', en: 'Devices for remotely capturing card data via NFC technology. Essential for contactless payment operations.' } },
      { id: 'h4', name: 'JCOP Cards (Blank)', icon: '💳', image: IMG.hardware, price: 30, desc: { ar: 'بطاقات خام (J2A040) للبرمجة', en: 'Blank cards (J2A040) for programming' }, details: { ar: 'بطاقات ذكية بيضاء فارغة، جاهزة للاستقبال والبرمجة. هي "المادة الخام" التي تُحقن فيها البيانات لتصبح بطاقة حقيقية.', en: 'Blank white smart cards, ready for programming. The "raw material" injected with data to become real cards.' } },
      { id: 'h5', name: 'Bluetooth Skimmers', icon: '📻', image: IMG.hardware, price: 190, desc: { ar: 'أجهزة الالتقاط اللاسلكي (Bluetooth Skimming)', en: 'Wireless capture devices (Bluetooth Skimming)' }, details: { ar: 'قطع مخفية صغيرة تُستخدم للالتقاط اللاسلكي لبيانات البطاقات وإرسالها لهاتفك مباشرة عبر البلوتوث.', en: 'Small hidden pieces for wireless card data capture, sent directly to your phone via Bluetooth.' } },
      { id: 'h6', name: 'Magnetic Head Cleaners', icon: '🧹', image: IMG.hardware, price: 35, desc: { ar: 'أدوات تنظيف الرؤوس المغناطيسية', en: 'Magnetic head cleaning tools' }, details: { ar: 'بطاقة تنظيف خاصة تُستخدم لصيانة رؤوس أجهزة الكتابة (MSR)، تضمن دقة نقل البيانات وتمنع أخطاء القراءة.', en: 'Special cleaning card for MSR write heads maintenance. Ensures data transfer accuracy and prevents read errors.' } },
    ],
  },
  {
    id: 'fullz', name: 'Fullz & Identity', icon: '📋', color: '#ff8844',
    desc: { ar: 'البيانات الكاملة وقوالب الهويات الموثقة', en: 'Complete data and verified identity templates' },
    image: IMG.identity,
    products: [
      { id: 'f1', name: 'Fullz Info (Premium)', icon: '📁', image: IMG.identity, price: 40, desc: { ar: 'بيانات كاملة وموثقة (Fullz) لتجاوز أنظمة التحقق', en: 'Complete verified data (Fullz) for verification bypass' }, details: { ar: 'ملفات محدثة (Live) تحتوي على كامل بيانات الضحية (الاسم، العنوان، الهاتف، البريد، الرقم الضريبي، وتاريخ الميلاد) لضمان عبور آمن عبر بوابات الدفع.', en: 'Updated live files with complete victim data (name, address, phone, email, SSN, DOB) for safe passage through payment gateways.' } },
      { id: 'f2', name: 'SSN & DOB Searchers', icon: '🔍', image: IMG.identity, price: 50, desc: { ar: 'استخراج الرقم الضريبي (SSN) وتاريخ الميلاد', en: 'Extract SSN and Date of Birth' }, details: { ar: 'قواعد بيانات متقدمة لاستخراج البيانات الحساسة المرتبطة بهوية صاحب البطاقة، تستخدم لتفعيل الحسابات وتغيير الرموز السرية.', en: 'Advanced databases for extracting sensitive identity data, used for account activation and PIN changes.' } },
      { id: 'f3', name: 'ID Templates (PSD)', icon: '🎨', image: IMG.identity, price: 30, desc: { ar: 'قوالب فوتوشوب احترافية لهويات ورخص قيادة', en: 'Professional Photoshop templates for IDs and licenses' }, details: { ar: 'ملفات (PSD) مفتوحة المصدر بجودة عالية، قابلة للتعديل لإنشاء هويات مطابقة لبيانات صاحب البطاقة عند الحاجة لتوثيق الحسابات.', en: 'High-quality open-source PSD files, editable to create matching IDs for account verification needs.' } },
      { id: 'f4', name: 'CC History', icon: '📈', image: IMG.identity, price: 25, desc: { ar: 'سجل عمليات البطاقة السابق', en: 'Previous card transaction history' }, details: { ar: 'سجل تاريخي يوضح نمط إنفاق البطاقة؛ يستخدم لتقدير الرصيد المتاح وتجنب الرفض التقني في بوابات الشراء.', en: 'Historical record showing card spending patterns; used for balance estimation and avoiding technical rejections.' } },
      { id: 'f5', name: 'Background Check Tools', icon: '📍', image: IMG.identity, price: 40, desc: { ar: 'أدوات التحقق من عنوان السكن (Billing Address)', en: 'Billing address verification tools' }, details: { ar: 'أدوات متخصصة لربط البطاقة بالعنوان الحقيقي (Billing Address) لضمان مطابقة البيانات عند إتمام عمليات الشراء.', en: 'Specialized tools for linking card to real billing address, ensuring data match during purchases.' } },
    ],
  },
  {
    id: 'security', name: 'Security & Privacy', icon: '🛡️', color: '#aa44ff',
    desc: { ar: 'أدوات التخفي، البروكسي، وحماية الهوية الرقمية', en: 'Stealth tools, proxy, and digital identity protection' },
    image: IMG.privacy,
    products: [
      { id: 's1', name: 'Elite SOCKS5 Proxies', icon: '🌐', image: IMG.privacy, price: 40, desc: { ar: 'بروكسيات سكنية فائقة السرعة والتخفي', en: 'Ultra-fast residential stealth proxies' }, details: { ar: 'توفر عناوين IP مطابقة لموقع الضحية الجغرافي، مما يقلل من احتمالية اكتشاف العمليات عبر أنظمة كشف الاحتيال.', en: 'Provides IP addresses matching victim\'s geographic location, reducing fraud detection probability.' } },
      { id: 's2', name: 'Anti-Detect Browser', icon: '🔒', image: IMG.privacy, price: 95, desc: { ar: 'متصفح متقدم لتغيير بصمة الجهاز', en: 'Advanced browser for device fingerprint spoofing' }, details: { ar: 'يغير إعدادات المتصفح، الـ WebGL، والـ Canvas لمنع المواقع من تتبع هويتك الحقيقية وربط العمليات بجهازك.', en: 'Changes browser settings, WebGL, and Canvas to prevent sites from tracking your real identity.' } },
      { id: 's3', name: 'VPN Multi-Hop Protocol', icon: '🔄', image: IMG.privacy, price: 65, desc: { ar: 'بروتوكول اتصال متعدد القفزات لتغيير المسار', en: 'Multi-hop connection protocol for route changes' }, details: { ar: 'يقوم بتوجيه بياناتك عبر عدة دول بشكل عشوائي ومستمر، مما يجعل تتبع مصدرك الأصلي مستحيلاً تقنياً.', en: 'Routes your data through multiple countries randomly and continuously, making source tracking technically impossible.' } },
      { id: 's4', name: 'MAC Address Spoofer', icon: '🔧', image: IMG.privacy, price: 25, desc: { ar: 'أداة تغيير عنوان الماك (MAC) للجهاز', en: 'Device MAC address spoofing tool' }, details: { ar: 'يغير المعرف الفيزيائي لكارت الشبكة، مما يمنع البنوك والمواقع من "بصم" جهازك.', en: 'Changes the physical network card identifier, preventing banks and sites from fingerprinting your device.' } },
      { id: 's5', name: 'Encrypted Mail Service', icon: '✉️', image: IMG.privacy, price: 30, desc: { ar: 'بريد إلكتروني مشفر ومجهول', en: 'Encrypted anonymous email service' }, details: { ar: 'خدمة بريد لا تحتفظ بسجلات وتستخدم تشفيراً من طرف إلى طرف لضمان سرية المراسلات.', en: 'Email service with no logs and end-to-end encryption for correspondence confidentiality.' } },
    ],
  },
  {
    id: 'bypass', name: 'Bypass & Social Eng.', icon: '⚡', color: '#44cccc',
    desc: { ar: 'تجاوز الحماية وفنون الهندسة الاجتماعية', en: 'Protection bypass and social engineering arts' },
    image: IMG.bypass,
    products: [
      { id: 'b1', name: '3D-Secure Bypass Script', icon: '🔓', image: IMG.bypass, price: 150, desc: { ar: 'سكربت متقدم لتجاوز حماية الـ 3D-Secure', en: 'Advanced script to bypass 3D-Secure protection' }, details: { ar: 'أداة برمجية تتدخل في بروتوكول التحقق للالتفاف على طلب كود OTP، مما يسمح بإتمام عمليات الدفع دون تحقق إضافي.', en: 'Software tool that intervenes in the verification protocol to bypass OTP code requests, allowing payments without additional verification.' } },
      { id: 'b2', name: 'Phishing Kit Generator', icon: '🎣', image: IMG.bypass, price: 120, desc: { ar: 'مولد صفحات مزورة للمواقع البنكية', en: 'Fake bank website page generator' }, details: { ar: 'أداة لتصميم صفحات هبوط مطابقة تماماً للمواقع الرسمية لسرقة بيانات الدخول والبطاقات عبر الهندسة الاجتماعية.', en: 'Tool for designing landing pages perfectly matching official websites for credential and card theft via social engineering.' } },
      { id: 'b3', name: 'OTP Bot (Voice/SMS)', icon: '🤖', image: IMG.bypass, price: 200, desc: { ar: 'بوت ذكاء اصطناعي لاستخراج أكواد الـ OTP عبر الاتصال', en: 'AI bot for extracting OTP codes via calls' }, details: { ar: 'يقوم البوت بالاتصال بالضحية بصوت بشري مقنع لإقناعها بالإفصاح عن كود التحقق الذي وصل لهاتفها.', en: 'Bot calls victims with convincing human voice to extract verification codes received on their phones.' } },
      { id: 'b4', name: 'Social Engineering Guide', icon: '🎭', image: IMG.bypass, price: 75, desc: { ar: 'دليل متقدم لفنون الإقناع والتلاعب النفسي', en: 'Advanced guide for persuasion and psychological manipulation' }, details: { ar: 'استراتيجيات مكتوبة ومسجلة لتقنيات الهندسة الاجتماعية المستخدمة في استخراج المعلومات الحساسة من خدمة العملاء.', en: 'Written and recorded strategies for social engineering techniques used in extracting sensitive information from customer service.' } },
      { id: 'b5', name: 'Email Spoofing Tool', icon: '📧', image: IMG.bypass, price: 50, desc: { ar: 'أداة تزوير عناوين البريد الإلكتروني', en: 'Email address spoofing tool' }, details: { ar: 'إرسال إيميلات تبدو أنها قادمة من بنك أو جهة رسمية لتضليل الضحية وجمع البيانات.', en: 'Send emails appearing to come from banks or official entities to deceive victims and collect data.' } },
    ],
  },
  {
    id: 'extraction', name: 'Extraction & Cleanup', icon: '🧹', color: '#cccc44',
    desc: { ar: 'أدوات الربط، التسييل، ومسح الأثر التقني', en: 'Linking, monetization, and technical trace removal tools' },
    image: IMG.cleanup,
    products: [
      { id: 'x1', name: 'Data Exfiltration Script', icon: '💾', image: IMG.cleanup, price: 140, desc: { ar: 'سكربت لسحب البيانات من قواعد البيانات', en: 'Script for extracting data from databases' }, details: { ar: 'أداة لأتمتة استخراج البيانات الخام من المواقع المصابة، مما يوفر الوقت في تصفية المعلومات يدوياً.', en: 'Tool for automating raw data extraction from compromised sites, saving time on manual filtering.' } },
      { id: 'x2', name: 'Cashout Gateway Linker', icon: '💸', image: IMG.cleanup, price: 130, desc: { ar: 'أداة ربط الحسابات ببوابات التسييل', en: 'Account linking tool for cashout gateways' }, details: { ar: 'برمجية تقوم بربط الحسابات المخترقة أو المحافظ ببوابات دفع خارجية لتسهيل عملية سحب الأموال وتحويلها.', en: 'Software linking compromised accounts to external payment gateways for easy fund withdrawal.' } },
      { id: 'x3', name: 'Digital Footprint Eraser', icon: '🗑️', image: IMG.cleanup, price: 95, desc: { ar: 'أداة مسح الأثر الرقمي (Log Cleaner)', en: 'Digital footprint eraser (Log Cleaner)' }, details: { ar: 'تقوم بحذف سجلات الدخول والملفات المؤقتة من السيرفرات والأجهزة بعد انتهاء العملية لتفادي الملاحقة.', en: 'Deletes login logs and temporary files from servers and devices after operations to avoid prosecution.' } },
      { id: 'x4', name: 'Account Mass-Migrator', icon: '📦', image: IMG.cleanup, price: 110, desc: { ar: 'نظام نقل الحسابات بالجملة', en: 'Bulk account migration system' }, details: { ar: 'أداة لنقل بيانات الحسابات من بيئة إلى أخرى بسرعة فائقة، مع الحفاظ على هيكلية البيانات.', en: 'Tool for migrating account data between environments at ultra-high speed while maintaining data structure.' } },
      { id: 'x5', name: 'Stealth Transaction Wrapper', icon: '🎭', image: IMG.cleanup, price: 85, desc: { ar: 'غلاف عمليات لتضليل أنظمة المراقبة', en: 'Transaction wrapper to deceive monitoring systems' }, details: { ar: 'أداة تقوم بتمويه طبيعة التحويلات المالية لجعلها تبدو كمعاملات طبيعية أمام أنظمة كشف الاحتيال.', en: 'Tool that disguises financial transfers to appear as normal transactions to fraud detection systems.' } },
    ],
  },
  {
    id: 'ai-edu', name: 'AI & Education', icon: '🤖', color: '#cc44cc',
    desc: { ar: 'نماذج الذكاء الاصطناعي والدورات التعليمية', en: 'AI models and educational courses' },
    image: IMG.ai,
    products: [
      { id: 'a1', name: 'Deepfake Voice Generator', icon: '🎙️', image: IMG.ai, price: 180, desc: { ar: 'مولد أصوات ذكاء اصطناعي لاستهداف الضحايا', en: 'AI voice generator for targeting victims' }, details: { ar: 'أداة تدريبية تقوم باستنساخ نبرة صوت أي شخص (من عينة صوتية قصيرة) لاستخدامها في الهندسة الاجتماعية والمكالمات الخادعة.', en: 'Training tool that clones anyone\'s voice tone (from a short sample) for social engineering and deceptive calls.' } },
      { id: 'a2', name: 'Automated Phishing AI', icon: '🧠', image: IMG.ai, price: 160, desc: { ar: 'نموذج ذكاء اصطناعي لكتابة رسائل الخداع', en: 'AI model for writing phishing messages' }, details: { ar: 'نموذج لغوي مدرب يقوم بكتابة رسائل إيميل أو SMS احترافية ومقنعة لا تثير الشكوك، وتتجاوز فلاتر البريد.', en: 'Fine-tuned language model that writes professional, convincing email/SMS messages that bypass email filters.' } },
      { id: 'a3', name: 'EMV Protocol Masterclass', icon: '🎓', image: IMG.ai, price: 250, desc: { ar: 'دورة تعليمية شاملة حول بروتوكولات EMV', en: 'Comprehensive EMV protocol course' }, details: { ar: 'سلسلة فيديوهات تعليمية تشرح بعمق كيفية عمل بروتوكولات الرقائق الذكية، كيفية الحقن، والتعامل مع أجهزة الصراف الآلي.', en: 'Video tutorial series deeply explaining smart chip protocols, injection methods, and ATM handling.' } },
      { id: 'a4', name: 'Carding Manual (Elite)', icon: '📕', image: IMG.ai, price: 100, desc: { ar: 'الدليل الشامل لعمليات التفريغ الحديثة', en: 'Comprehensive guide for modern carding operations' }, details: { ar: 'دليل مكتوب بأسلوب تقني يغطي تحديثات الأنظمة البنكية لعام 2026، وطرق تجاوز الأنظمة الأمنية الحديثة.', en: 'Technical guide covering 2026 banking system updates and modern security bypass methods.' } },
      { id: 'a5', name: 'Scripting & Automation Course', icon: '💻', image: IMG.ai, price: 130, desc: { ar: 'دورة احترافية في برمجة سكربتات الأتمتة', en: 'Professional automation scripting course' }, details: { ar: 'تعلم كيفية كتابة سكربتات (Python/Bash) لأتمتة عمليات الفحص، سحب البيانات، وتجاوز العقبات التقنية.', en: 'Learn to write Python/Bash scripts for automating scanning, data extraction, and bypassing technical obstacles.' } },
    ],
  },
  {
    id: 'advanced', name: 'Advanced Ops Suite', icon: '💀', color: '#ff4488',
    desc: { ar: 'ترسانة العمليات المتقدمة وثغرات Zero-Day', en: 'Advanced operations arsenal and Zero-Day exploits' },
    image: IMG.advanced,
    products: [
      { id: 'ad1', name: 'Zero-Day Vulnerability Scanner', icon: '☠️', image: IMG.advanced, price: 400, desc: { ar: 'فحص البنية التحتية لثغرات Zero-Day', en: 'Infrastructure scan for Zero-Day vulnerabilities' }, details: { ar: 'أداة متطورة تقوم بمسح السيرفرات والشبكات لاكتشاف ثغرات أمنية حرجة لم يتم إطلاق تصحيحات لها بعد.', en: 'Advanced tool scanning servers and networks for critical security vulnerabilities with no patches available yet.' } },
      { id: 'ad2', name: 'Distributed DDoS Stresser', icon: '🌊', image: IMG.advanced, price: 300, desc: { ar: 'أداة اختبار ضغط البنية التحتية (DDoS)', en: 'Infrastructure stress testing tool (DDoS)' }, details: { ar: 'تستخدم لإضعاف أنظمة حماية المواقع (WAF) عبر إغراقها بحركة مرور وهمية، مما يسهل اختراق بوابات الدفع المحصنة.', en: 'Weakens website protection systems (WAF) by flooding with fake traffic, facilitating fortified payment gateway breaches.' } },
      { id: 'ad3', name: 'RAT Builder', icon: '🕹️', image: IMG.advanced, price: 350, desc: { ar: 'بناء أدوات التحكم عن بعد في الأنظمة', en: 'Remote Access Trojan builder for systems' }, details: { ar: 'أداة متخصصة لإنشاء ملفات (Payloads) تمنح تحكماً كاملاً في جهاز الضحية، لاستخراج كلمات المرور والبيانات البنكية.', en: 'Specialized tool for creating payloads granting full control over victim devices for password and banking data extraction.' } },
      { id: 'ad4', name: 'SQLi Exploitation Suite', icon: '💉', image: IMG.advanced, price: 280, desc: { ar: 'حزمة أتمتة استغلال ثغرات حقن SQL', en: 'SQL injection exploitation automation suite' }, details: { ar: 'تقوم هذه الحزمة بمسح المواقع، تحديد نقاط الحقن، واستخراج محتويات قواعد بيانات المستخدمين بشكل أوتوماتيكي.', en: 'Scans sites, identifies injection points, and automatically extracts user database contents.' } },
      { id: 'ad5', name: 'Encrypted C2 Server', icon: '🌐', image: IMG.advanced, price: 500, desc: { ar: 'سيرفر تحكم مشفر لإدارة العمليات المتقدمة', en: 'Encrypted C2 server for advanced operations' }, details: { ar: 'مركز قيادة مخفي يعمل عبر بروتوكولات مشفرة (Tor/VPN) لإدارة آلاف الأجهزة المصابة في وقت واحد.', en: 'Hidden command center operating via encrypted protocols (Tor/VPN) managing thousands of infected devices simultaneously.' } },
    ],
  },
  {
    id: 'ops-command', name: 'Operations Command', icon: '🎯', color: '#44ff88',
    desc: { ar: 'مركز قيادة العمليات وإدارة الحسابات بالجملة', en: 'Operations command center and bulk account management' },
    image: IMG.opsCmd,
    products: [
      { id: 'o1', name: 'Enterprise Dashboard', icon: '📊', image: IMG.opsCmd, price: 220, desc: { ar: 'لوحة تحكم مركزية لإدارة العمليات المتعددة', en: 'Central dashboard for managing multiple operations' }, details: { ar: 'واجهة إدارية تمكنك من متابعة نشاط آلاف الأجهزة والحسابات في وقت واحد، مع إحصائيات لحظية للأرباح.', en: 'Administrative interface tracking thousands of devices and accounts simultaneously with real-time profit statistics.' } },
      { id: 'o2', name: 'Auto-Replenishment System', icon: '🔄', image: IMG.opsCmd, price: 180, desc: { ar: 'نظام تعبئة تلقائي للمخزون', en: 'Automatic inventory replenishment system' }, details: { ar: 'يقوم بدمج حساباتك مع مصادر البيانات لتحديث قائمة المنتجات المتاحة فورياً وبشكل أوتوماتيكي.', en: 'Integrates your accounts with data sources to automatically and instantly update available product listings.' } },
      { id: 'o3', name: 'Global Ops Proxy Network', icon: '🌍', image: IMG.opsCmd, price: 250, desc: { ar: 'شبكة بروكسي احترافية لإدارة العمليات العالمية', en: 'Professional proxy network for global operations' }, details: { ar: 'بنية تحتية من السيرفرات الموزعة عالمياً، تضمن استقرار الاتصال وسرعة تنفيذ المهام العابرة للحدود.', en: 'Globally distributed server infrastructure ensuring connection stability and cross-border task execution speed.' } },
      { id: 'o4', name: 'Batch Processing Engine', icon: '⚙️', image: IMG.opsCmd, price: 190, desc: { ar: 'محرك معالجة البيانات الجماعي', en: 'Bulk data processing engine' }, details: { ar: 'أداة قوية لمعالجة ملايين المدخلات (بطاقات، حسابات، إيميلات) في دقائق، مع ميزة التصفية الذكية.', en: 'Powerful tool processing millions of inputs (cards, accounts, emails) in minutes with smart filtering.' } },
      { id: 'o5', name: 'Encrypted Vault', icon: '🔐', image: IMG.opsCmd, price: 150, desc: { ar: 'خزانة مشفرة لحفظ البيانات الحساسة', en: 'Encrypted vault for sensitive data storage' }, details: { ar: 'مساحة تخزين آمنة ومشفرة بمعايير عسكرية، تستخدم لحفظ أصول البيانات والنتائج المسحوبة.', en: 'Military-grade encrypted secure storage space for data assets and extraction results.' } },
    ],
  },
];
