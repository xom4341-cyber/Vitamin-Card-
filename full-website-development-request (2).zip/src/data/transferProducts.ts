import type { StoreProduct } from './storeProducts';

const IMG = {
  amexInj: 'https://i.postimg.cc/Kv1gsSmx/1770287724-amex-gold-credit.png',
  bank: 'https://i.postimg.cc/7YgMNJDW/Screenshot-20260624-040807-Chrome.jpg',
  ewalletSection: 'https://i.postimg.cc/Y9Zfd1hN/1782266069309.png',
  usdt: 'https://i.postimg.cc/W3kJbx18/231013-Blog-What-Is-Tether-USDT.webp',
  btc: 'https://i.postimg.cc/mgpc3TcC/images-(45).jpg',
};

const WALLET_IMG: Record<string, string> = {
  PayPal: 'https://i.postimg.cc/ZKwywYkm/dx-DDsqfo-P43IAsnrv-Oi8hu6p-C8Bm-Hg-Tn-W2DF95Lv-XN4.jpg',
  Payoneer: 'https://i.postimg.cc/6Qv26d8s/images.png',
  Payer: 'https://i.postimg.cc/2SB8nCr4/unnamed.png',
  Neteller: 'https://i.postimg.cc/x1kqgKyY/images-(21).jpg',
  Skrill: 'https://i.postimg.cc/7h0jxPzt/images-(44).jpg',
  CashApp: 'https://i.postimg.cc/PfzD8z2x/images-(20).jpg',
  Wise: 'https://i.postimg.cc/xjWZcQpD/images-(26).jpg',
  Revolut: 'https://i.postimg.cc/FH9w44HR/images-(43).jpg',
  'Perfect Money': 'https://i.postimg.cc/fy2TfLV7/images-(2).png',
};

const amexInjDetail = { ar: 'تعتمد هذه الخدمة على بروتوكول "الحقن المباشر" في بوابات الدفع لتجاوز أنظمة التحقق.\n\n🔹 آلية العمل:\n• سيرفر الوسيط (Residential Proxies) يطابق جغرافية صاحب البطاقة\n• الحقن عبر الجلسة (Session Injection) داخل موقع الهدف\n• إخفاء الأثر: تعديل التوقيع الرقمي لتجاوز أنظمة AVS/CVV\n\n🔹 الضمان:\nنتكفل بتجاوز كافة أنظمة Security الخاصة بـ AMEX مع سياسة الاستبدال الفوري.', en: 'This service uses "Direct Injection" protocol in payment gateways to bypass verification.\n\n🔹 How it works:\n• Residential Proxy server matches cardholder geography\n• Session Injection into target site\n• Trace hiding: Digital fingerprint modification to bypass AVS/CVV\n\n🔹 Guarantee:\nWe handle all AMEX security systems with instant replacement policy.' };

const bankDetail = { ar: 'نظام تحويلات بنكية دولية عبر بروتوكولات (SWIFT/SEPA). يتم إرسال المبالغ من حسابات تجارية موثقة كـ "حوالة نظيفة".\n\n🛡️ سياسة الصفقات:\n• العمليات أقل من 2,000$ تنفذ رقمياً بالكامل\n• مقابلات شخصية للصفقات 2,000$+ (السعودية/أمريكا/روسيا/ألمانيا)\n\n📜 البروتوكول:\n• التغطية: كافة البنوك (خليجية/أوروبية/أمريكية)\n• السرية: نظام طبقات متعددة لإخفاء مصدر التحويل\n• الضمان: حوالة بديلة فورية في حال الرفض', en: 'International bank transfers via SWIFT/SEPA protocols. Amounts sent from verified commercial accounts as "clean transfers".\n\n🛡️ Transaction Policy:\n• Operations under $2,000 executed fully digitally\n• Personal meetings for $2,000+ deals\n\n📜 Protocol:\n• Coverage: All banks (Gulf/European/American)\n• Secrecy: Multi-layer system to hide transfer source\n• Guarantee: Instant alternative transfer if rejected' };

const walletDetail = (name: string) => ({ ar: `حقن ${name} - بدون حجز (No Hold)\n\nنرسل الأموال من حسابات موثوقة جداً لدى ${name}، المبلغ يظهر في رصيدك "المتاح" فوراً.\n\n🛡️ حماية كاملة:\n• طرق تقنية تمنع استرداد الأموال (Dispute)\n• بروتوكولات تشفير لإخفاء العلاقة بين حساباتنا وحسابك\n\n📥 طريقة الاستلام:\nأرسل بيانات حسابك وسيتولى فريقنا التنفيذ.`, en: `${name} Injection - No Hold\n\nFunds sent from highly trusted ${name} accounts, appearing in your "available" balance immediately.\n\n🛡️ Full Protection:\n• Technical methods preventing disputes\n• Encryption protocols hiding account relationship\n\n📥 How to receive:\nSend your account details and our team handles execution.` });

const flashUsdtDetail = { ar: 'مواصفات خدمة فلاش USDT:\n• شبكات النقل: TRC20 و BEP20\n• الاستخدام: مواقع الرهان والتداول المباشر\n• الصلاحية: 70 يوماً\n\n⚠️ قيود:\n• غير قابلة للتداول في منصات CEX أو P2P\n• أي محاولة إدراج في منصات البيع ستُرفض فوراً', en: 'Flash USDT Specifications:\n• Networks: TRC20 and BEP20\n• Use: Betting sites and direct trading\n• Validity: 70 days\n\n⚠️ Limitations:\n• Not tradable on CEX or P2P platforms\n• Any listing attempt will be instantly rejected' };

const flashBtcDetail = { ar: 'مواصفات فلاش Bitcoin:\n• شبكة النقل: Bitcoin Mainnet\n• الصلاحية: 50 يوماً\n• الاستخدام: مواقع الرهان والتداول المباشر\n\n⚠️ قيود:\n• غير قابل للتداول عبر P2P\n• الإيداع في منصات مركزية يؤدي لتجميد المعاملة فوراً', en: 'Flash Bitcoin Specs:\n• Network: Bitcoin Mainnet\n• Validity: 50 days\n• Use: Betting and direct trading\n\n⚠️ Limitations:\n• Not tradable via P2P\n• CEX deposits will freeze instantly' };

export const transferSubCategories = [
  { id: 'amex-inject', name: { ar: 'حقن American Express', en: 'AMEX Injection' }, shortName: 'AMEX', icon: '💎', image: IMG.amexInj, color: '#ffd700' },
  { id: 'paypal-inject', name: { ar: 'حقن E-wallet', en: 'E-wallet Injection' }, shortName: 'E-Wal', icon: '💳', image: IMG.ewalletSection, color: '#00d4ff' },
  { id: 'bank-wire', name: { ar: 'التحويلات البنكية', en: 'Bank Wire (SWIFT/SEPA)' }, shortName: 'SWIFT', icon: '🏦', image: IMG.bank, color: '#44cc44' },
  { id: 'flash-usdt', name: { ar: 'Flash USDT', en: 'Flash USDT' }, shortName: 'USDT', icon: '⚡', image: IMG.usdt, color: '#26a17b' },
  { id: 'flash-btc', name: { ar: 'Flash Bitcoin', en: 'Flash Bitcoin' }, shortName: 'BTC', icon: '₿', image: IMG.btc, color: '#f7931a' },
];

export const transferProducts: StoreProduct[] = [
  // AMEX Injection
  ...[
    { id: 'amex-inj-t1', name: 'AMEX Inject $1,000', balance: '$1,000', price: 130, oldPrice: 300 },
    { id: 'amex-inj-t2', name: 'AMEX Inject $2,000', balance: '$2,000', price: 260, oldPrice: 500 },
    { id: 'amex-inj-t3', name: 'AMEX Inject $3,000', balance: '$3,000', price: 390, oldPrice: 700 },
    { id: 'amex-inj-t4', name: 'AMEX Inject $7,000', balance: '$7,000', price: 910, oldPrice: 1200 },
    { id: 'amex-inj-t5', name: 'AMEX Inject $10,000', balance: '$10,000', price: 1300, oldPrice: 1500 },
    { id: 'amex-inj-t6', name: 'AMEX Inject $13,000', balance: '$13,000', price: 1690, oldPrice: 2000 },
    { id: 'amex-inj-t7', name: 'AMEX Inject $15,000', balance: '$15,000', price: 1950, oldPrice: 2500 },
    { id: 'amex-inj-t8', name: 'AMEX Inject $20,000', balance: '$20,000', price: 2600, oldPrice: 3500 },
    { id: 'amex-inj-t9', name: 'AMEX Inject $30,000', balance: '$30,000', price: 3900, oldPrice: 5000 },
  ].map(p => ({ ...p, image: IMG.amexInj, category: 'transfer', subCategory: 'amex-inject', type: 'injected' as const, desc: { ar: 'حقن American Express بروتوكول 10.1 المتقدم - حقن مشفر', en: 'American Express Protocol 10.1 Advanced Injection - Encrypted' }, details: amexInjDetail })),

  // E-wallet Injection
  ...(['PayPal','Payoneer','Payer','Neteller','Skrill','CashApp','Wise','Revolut','Perfect Money'].map((w) => ({
    id: `ewallet-${w.toLowerCase().replace(/\s/g,'')}`, name: `${w} Inject $1,000`, balance: '$1,000', price: 150, oldPrice: 300,
    image: WALLET_IMG[w] || IMG.ewalletSection, category: 'transfer', subCategory: 'paypal-inject', type: 'injected' as const,
    desc: { ar: `حقن ${w} برصيد $1,000 - بدون حجز (No Hold)`, en: `${w} $1,000 injection - No Hold` },
    details: walletDetail(w),
  }))),

  // Bank Wire
  ...[
    { id: 'bw-5k', name: 'Bank Wire $5,000', balance: '$5,000', price: 1000, oldPrice: 1200 },
    { id: 'bw-10k', name: 'Bank Wire $10,000', balance: '$10,000', price: 2000, oldPrice: 2300 },
    { id: 'bw-15k', name: 'Bank Wire $15,000', balance: '$15,000', price: 3000, oldPrice: 3500 },
    { id: 'bw-20k', name: 'Bank Wire $20,000', balance: '$20,000', price: 4000, oldPrice: 4800 },
    { id: 'bw-30k', name: 'Bank Wire $30,000', balance: '$30,000', price: 5500, oldPrice: 6500 },
    { id: 'bw-40k', name: 'Bank Wire $40,000', balance: '$40,000', price: 7500, oldPrice: 8800 },
    { id: 'bw-50k', name: 'Bank Wire $50,000', balance: '$50,000', price: 10000, oldPrice: 12000 },
  ].map(p => ({ ...p, image: IMG.bank, category: 'transfer', subCategory: 'bank-wire', type: 'injected' as const, desc: { ar: 'تحويل بنكي دولي SWIFT/SEPA - حوالة نظيفة مع تخطي أنظمة الرقابة', en: 'International SWIFT/SEPA bank wire - Clean transfer bypassing monitoring' }, details: bankDetail })),

  // Flash USDT
  ...[
    { id: 'fusdt-1k', name: 'Flash 1,000 USDT', balance: '1,000 USDT', price: 50, oldPrice: 100 },
    { id: 'fusdt-2k', name: 'Flash 2,000 USDT', balance: '2,000 USDT', price: 100, oldPrice: 200 },
    { id: 'fusdt-3k', name: 'Flash 3,000 USDT', balance: '3,000 USDT', price: 150, oldPrice: 300 },
    { id: 'fusdt-4k', name: 'Flash 4,000 USDT', balance: '4,000 USDT', price: 200, oldPrice: 400 },
    { id: 'fusdt-5k', name: 'Flash 5,000 USDT', balance: '5,000 USDT', price: 250, oldPrice: 500 },
  ].map(p => ({ ...p, image: IMG.usdt, category: 'transfer', subCategory: 'flash-usdt', type: 'injected' as const, desc: { ar: 'شحن USDT فوري - صلاحية 70 يوم - TRC20/BEP20', en: 'Instant USDT top-up - 70 days validity - TRC20/BEP20' }, details: flashUsdtDetail })),

  // Flash Bitcoin
  ...[
    { id: 'fbtc-05', name: 'Flash 0.5 BTC', balance: '0.5 BTC', price: 99, oldPrice: 200 },
    { id: 'fbtc-1', name: 'Flash 1 BTC', balance: '1 BTC', price: 180, oldPrice: 350 },
    { id: 'fbtc-2', name: 'Flash 2 BTC', balance: '2 BTC', price: 350, oldPrice: 700 },
    { id: 'fbtc-4', name: 'Flash 4 BTC', balance: '4 BTC', price: 500, oldPrice: 1000 },
    { id: 'fbtc-5', name: 'Flash 5 BTC', balance: '5 BTC', price: 550, oldPrice: 1100 },
    { id: 'fbtc-10', name: 'Flash 10 BTC', balance: '10 BTC', price: 999, oldPrice: 2000 },
  ].map(p => ({ ...p, image: IMG.btc, category: 'transfer', subCategory: 'flash-btc', type: 'injected' as const, desc: { ar: 'شحن Bitcoin فوري - صلاحية 50 يوم - Bitcoin Mainnet', en: 'Instant Bitcoin top-up - 50 days validity - Bitcoin Mainnet' }, details: flashBtcDetail })),
];

export const getTransferProducts = (subId: string) => transferProducts.filter(p => p.subCategory === subId);

// E-wallet fields per wallet type
export const walletFields: Record<string, { label: string; required: boolean }[]> = {
  PayPal: [{ label: 'PayPal Email', required: true }, { label: 'Account Name', required: true }, { label: 'Notes', required: false }],
  Payoneer: [{ label: 'Payoneer Email', required: true }, { label: 'Payoneer ID', required: true }, { label: 'Notes', required: false }],
  Payer: [{ label: 'Payer Account (P...)', required: true }, { label: 'Notes', required: false }],
  Neteller: [{ label: 'Neteller Email', required: true }, { label: 'Account ID', required: true }, { label: 'Notes', required: false }],
  Skrill: [{ label: 'Skrill Email', required: true }, { label: 'Account Type', required: true }, { label: 'Notes', required: false }],
  CashApp: [{ label: '$Cashtag', required: true }, { label: 'Full Name', required: true }, { label: 'Notes', required: false }],
  Wise: [{ label: 'Account Number', required: true }, { label: 'Full Name', required: true }, { label: 'Account Type', required: false }],
  Revolut: [{ label: 'IBAN / Revtag', required: true }, { label: 'Username', required: true }, { label: 'Account Type', required: false }],
  'Perfect Money': [{ label: 'PM Account ID', required: true }, { label: 'Notes', required: false }],
};
