export interface StoreProduct {
  id: string;
  name: string;
  desc: { ar: string; en: string };
  details: { ar: string; en: string };
  price: number;
  oldPrice: number;
  balance: string;
  image: string;
  category: string;
  subCategory: string;
  type: 'injected' | 'pulled';
  isBundle?: boolean;
}

const IMG = {
  novbv: 'https://i.postimg.cc/FKXmcqr1/Screenshot-20260624-040940-Telegram.jpg',
  amexInj: 'https://i.postimg.cc/yY23MQNy/images-(31).jpg',
  paypal: 'https://i.postimg.cc/26js7NgP/images-(32).jpg',
  credit: 'https://i.postimg.cc/vTr2JqR5/pngtree-credit-card-mastercard-clipping-retail-vector-png-image-7235644.jpg',
  debit: 'https://i.postimg.cc/CK9vzTS4/images-(41).jpg',
  amex: 'https://i.postimg.cc/wjWcRcx5/images-(7).png',
  classic: 'https://i.postimg.cc/QxS0cWj8/Corporate-Classic-Card-Image.png',
  platinum: 'https://i.postimg.cc/RhBXL73g/images-(42).jpg',
  cashapp: 'https://i.postimg.cc/PfzD8z2x/images-(20).jpg',
  skrill: 'https://i.postimg.cc/7h0jxPzt/images-(44).jpg',
  revolut: 'https://i.postimg.cc/FH9w44HR/images-(43).jpg',
};

const novbvDetails = {
  ar: `بطاقات Visa & MasterCard بنظام (NOVBV)\n• النوع: بدون تحقق ثنائي (No 3D Secure / OTP)\n• المصدر: يتم فتحها يدوياً وتجهيزها بأعلى معايير الأمان\n• الرصيد: محقونة بأرصدة حقيقية وجاهزة للاستخدام الفوري\n• الأمان: آمنة تماماً من البلاغات (Anti-Chargeback)\n• التسليم: تسلم بكامل بياناتها (Fullz) مع شروحات ودلائل حصرية\n\n[ 👤 البيانات الشخصية ]\n• الاسم الكامل: J*** S****\n• تاريخ الميلاد: 199*-**-**\n• الـ SSN: ***-**-1234\n• البريد الإلكتروني: j***@*****.com\n• الجوال: +1 (***) ***-****\n\n[ 💳 بيانات البطاقة ]\n• رقم البطاقة: **** **** **** 4567\n• تاريخ الانتهاء: **/** | CVV: ***\n• النوع: Credit | المستوى: Platinum\n• البنك: ********** Bank\n\n[ 📍 بيانات العنوان (Billing Address) ]\n• الشارع: **** ***** St\n• المدينة: *******\n• الولاية: ** | الرمز البريدي: *****\n• الدولة: United States\n\n[ 🖥️ بيانات الجهاز والشبكة ]\n• IP Address: ***.***.***.**\n• User-Agent: Mozilla/5.0 (Windows NT 10.0...)`,
  en: `Visa & MasterCard NOVBV System\n• Type: No 3D Secure / OTP verification\n• Source: Manually opened with highest security standards\n• Balance: Injected with real balances, ready for immediate use\n• Security: Fully safe from chargebacks (Anti-Chargeback)\n• Delivery: Complete data (Fullz) with exclusive tutorials\n\n[ 👤 Personal Data ]\n• Full Name: J*** S****\n• DOB: 199*-**-**\n• SSN: ***-**-1234\n• Email: j***@*****.com\n• Phone: +1 (***) ***-****\n\n[ 💳 Card Data ]\n• Card Number: **** **** **** 4567\n• Exp: **/** | CVV: ***\n• Type: Credit | Level: Platinum\n• Bank: ********** Bank\n\n[ 📍 Billing Address ]\n• Street: **** ***** St\n• City: ******* | State: ** | ZIP: *****\n• Country: United States`,
};

const amexInjDetails = {
  ar: `بطاقات محقونة American Express بيانات بروتوكول 10.1 المتقدم\nتأتي هذه البطاقة ببيانات شخصية كاملة (Fullz) تم إعدادها وفتح حسابها يدوياً وحقنها بمبالغ مختلفة عبر ثغرات الاسترداد.\n\n• تقنية التلامس (NFC): إمكانية محاكاة الصرف عبر أجهزة الدفع المادي\n• البروتوكول: 10.1 المطور\n\n🔹 بيانات الإصدار:\n• موقع الجهة المصدرة: (USA - 840)\n• نوع البطاقة: American Express Corporate (Platinum/Grey)\n\n🔹 بيانات البطاقة:\n• اسم حامل البطاقة: **** * *****\n• رقم البطاقة: 3792 **** **** ***\n• تاريخ الانتهاء: **/**\n• الرمز الأمامي (CID/CVV): ****\n\n🔹 بيانات الدخول للتطبيق:\n• اسم المستخدم: *****_Corp_Admin\n• البريد: ****@****.com\n• كلمة المرور: *************\n\n🔹 بيانات الشركة والعنوان:\n• اسم الشركة: ******* ***\n• العنوان: 308 ****** **\n• المدينة: ******** | الولاية: *****\n• الرمز البريدي: 78*** | الدولة: United States`,
  en: `American Express Injected Cards - Protocol 10.1\nComplete personal data (Fullz), manually opened and injected via refund exploits.\n\n• NFC Technology: Physical payment device simulation capability\n• Protocol: Advanced 10.1\n\n🔹 Issuer Data:\n• Issuer Location: (USA - 840)\n• Card Type: American Express Corporate (Platinum/Grey)\n\n🔹 Card Data:\n• Cardholder Name: **** * *****\n• Card Number: 3792 **** **** ***\n• Expiry: **/** | CID/CVV: ****\n\n🔹 App Login:\n• User ID: *****_Corp_Admin\n• Email: ****@****.com\n• Password: *************`,
};

const paypalDetails = {
  ar: `[ 👤 بيانات صاحب الحساب ]\n• الاسم الكامل: M******* A*******\n• تاريخ الميلاد: 198*-**-**\n• البريد الإلكتروني (Login): u**********@email.com\n• كلمة المرور: **************\n• الجوال المربوط: +1-***-***-****\n\n[ 🏦 بيانات الحساب المالي ]\n• نوع الحساب: Personal / Business\n• حالة الحساب: Verified\n• البطاقة المربوطة: Visa **** 4242\n\n[ 📍 بيانات العنوان (Billing) ]\n• العنوان المسجل: **** ****** Rd, City, State, ZIP\n• الدولة: United States\n\n[ 🖥️ بيانات الجهاز والشبكة ]\n• IP Address: ***.***.***.**\n• COOKIE: [مُشفر - يسلم مع الطلب]`,
  en: `[ 👤 Account Owner Data ]\n• Full Name: M******* A*******\n• DOB: 198*-**-**\n• Email (Login): u**********@email.com\n• Password: **************\n• Phone: +1-***-***-****\n\n[ 🏦 Financial Account ]\n• Type: Personal / Business\n• Status: Verified\n• Linked Card: Visa **** 4242\n\n[ 📍 Billing Address ]\n• Address: **** ****** Rd, City, State, ZIP\n• Country: United States`,
};

const creditDetails = {
  ar: `[ 💳 بيانات البطاقة الأساسية ]\n• CC: XXXX-XXXX-XXXX-XXXX\n• EXP: XX/XX | CVC: ***\n• CH (الاسم): *********\n• VENDOR: Visa / Mastercard\n• TYPE: Credit\n• LEVEL: Platinum / Signature\n• BANK: [*********]\n\nبطاقات مديونية بحدود مرتفعة تصل إلى 50,000$. الصرف لا يظهر في كشف الحساب اللحظي بل يضاف لمديونية صاحب البطاقة نهاية الشهر.`,
  en: `[ 💳 Card Data ]\n• CC: XXXX-XXXX-XXXX-XXXX\n• EXP: XX/XX | CVC: ***\n• CH: ********* | VENDOR: Visa / Mastercard\n• TYPE: Credit | LEVEL: Platinum / Signature\n• BANK: [*********]\n\nHigh-limit credit cards up to $50,000. Charges don't appear in real-time statements.`,
};

const debitDetails = {
  ar: `[ ⚠️ تنبيه فني: بطاقات الديبت ]\nبطاقات ترتبط بالحساب البنكي مباشرة. أي حركة صرف تظهر فوراً.\n\n[ 💳 بيانات البطاقة ]\n• CC: XXXX-XXXX-XXXX-XXXX | EXP: XX/XX | CVC: ***\n• CH: ********* | VENDOR: Visa / Mastercard\n• TYPE: Debit | LEVEL: Classic / Gold\n• BANK: [*********]\n\n[ 📍 العنوان (Billing) ]\n• COUNTRY: United States | ZIP: *****\n• CITY: ***** | ADDRESS: *******************\n• PHONE: +1-***-***-**** | EMAIL: ******@*****.com`,
  en: `[ ⚠️ Technical Notice: Debit Cards ]\nCards linked directly to bank accounts. Every transaction appears instantly.\n\n[ 💳 Card Data ]\n• CC: XXXX-XXXX-XXXX-XXXX | EXP: XX/XX | CVC: ***\n• CH: ********* | TYPE: Debit | LEVEL: Classic / Gold\n\n[ 📍 Billing ]\n• Country: United States | ZIP: *****`,
};

const amexPulledDetails = {
  ar: `[ 💎 بيانات بروتوكول 10.1 المتقدم ]\n• دعم الشريحة (EMV): بيانات مشفرة للتعامل المادي\n• الصرف المباشر / بوابات الدفع: توافق تام\n• تقنية التلامس (NFC): محاكاة الصرف عبر أجهزة الدفع\n\n[ 💳 بيانات البطاقة ]\n• CC: XXXX-XXXX-XXXX-XXXX | EXP: XX/XX | CID: ****\n• شفرات الشريحة (EMV Data): [مُشفر]\n• النوع: AMEX | المستوى: Platinum/Centurion\n\n[ 👤 بيانات المالك (Fullz) ]\n• الاسم: ********* | الجوال: +1-***-***-****\n• البريد: ******@*****.com | SSN: ***-**-****\n\n[ 📍 العنوان ]\n• العنوان: ******************* | المدينة: *****\n• الدولة: United States`,
  en: `[ 💎 Advanced Protocol 10.1 Data ]\n• EMV Chip Support: Encrypted data for physical transactions\n• Direct Payment / Gateways: Full compatibility\n• NFC Technology: Payment device simulation\n\n[ 💳 Card Data ]\n• CC: XXXX-XXXX-XXXX-XXXX | EXP: XX/XX | CID: ****\n• EMV Data: [Encrypted]\n• Type: AMEX | Level: Platinum/Centurion\n\n[ 👤 Fullz ]\n• Name: ********* | Phone: +1-***-***-****\n• Email: ******@*****.com`,
};

export const cardsProducts: StoreProduct[] = [
  // ===== NOVBV CC - INJECTED =====
  ...[
    { id: 'novbv-1000', name: 'CARD NOVBV CC-1000', balance: '$1,000', price: 75, oldPrice: 100 },
    { id: 'novbv-1500', name: 'CARD NOVBV CC-1500', balance: '$1,500', price: 99, oldPrice: 130 },
    { id: 'novbv-2000', name: 'CARD NOVBV CC-2000', balance: '$2,000', price: 119, oldPrice: 160 },
    { id: 'novbv-3000', name: 'CARD NOVBV CC-3000', balance: '$3,000', price: 149, oldPrice: 180 },
    { id: 'novbv-4000', name: 'CARD NOVBV CC-4000', balance: '$4,000', price: 199, oldPrice: 250 },
    { id: 'novbv-5000', name: 'CARD NOVBV CC-5000', balance: '$5,000', price: 249, oldPrice: 300 },
    { id: 'novbv-6000', name: 'CARD NOVBV CC-6000', balance: '$6,000', price: 299, oldPrice: 380 },
    { id: 'novbv-7000', name: 'CARD NOVBV CC-7000', balance: '$7,000', price: 399, oldPrice: 450 },
    { id: 'novbv-10000', name: 'CARD NOVBV CC-10000', balance: '$10,000', price: 499, oldPrice: 580 },
    { id: 'novbv-12000', name: 'CARD NOVBV CC-12000', balance: '$12,000', price: 599, oldPrice: 690 },
    { id: 'novbv-15000', name: 'CARD NOVBV CC-15000', balance: '$15,000', price: 749, oldPrice: 850 },
    { id: 'novbv-20000', name: 'CARD NOVBV CC-20000', balance: '$20,000', price: 899, oldPrice: 1000 },
    { id: 'novbv-30000', name: 'CARD NOVBV CC-30000', balance: '$30,000', price: 1299, oldPrice: 1500 },
  ].map(p => ({ ...p, image: IMG.novbv, category: 'cards', subCategory: 'novbv', type: 'injected' as const, desc: { ar: 'بطاقات محقونة لتجاوز الـ OTP والسحب المباشر. البيانات كاملة (Fullz)', en: 'Injected cards bypassing OTP for direct withdrawal. Complete data (Fullz)' }, details: novbvDetails })),
  // NOVBV Bundles
  ...[
    { id: 'novbv-b5', name: 'NOVBV CC-BUNDLE-5', balance: '5 Cards', price: 199, oldPrice: 350, isBundle: true },
    { id: 'novbv-b10', name: 'NOVBV CC-BUNDLE-10', balance: '10 Cards', price: 399, oldPrice: 550, isBundle: true },
    { id: 'novbv-b15', name: 'NOVBV CC-BUNDLE-15', balance: '15 Cards', price: 499, oldPrice: 750, isBundle: true },
    { id: 'novbv-b20', name: 'NOVBV CC-BUNDLE-20', balance: '20 Cards', price: 599, oldPrice: 950, isBundle: true },
  ].map(p => ({ ...p, image: IMG.novbv, category: 'cards', subCategory: 'novbv', type: 'injected' as const, desc: { ar: 'بكج بطاقات محقونة NOVBV CC', en: 'NOVBV CC Injected Cards Bundle' }, details: novbvDetails })),

  // ===== AMEX INJECTED =====
  ...[
    { id: 'amex-inj-1000', name: 'AMEX-LOADED-1000', balance: '$1,000', price: 149, oldPrice: 300 },
    { id: 'amex-inj-1500', name: 'AMEX-LOADED-1500', balance: '$1,500', price: 199, oldPrice: 350 },
    { id: 'amex-inj-2000', name: 'AMEX-LOADED-2000', balance: '$2,000', price: 249, oldPrice: 400 },
    { id: 'amex-inj-2500', name: 'AMEX-LOADED-2500', balance: '$2,500', price: 299, oldPrice: 450 },
    { id: 'amex-inj-4000', name: 'AMEX-LOADED-4000', balance: '$4,000', price: 399, oldPrice: 600 },
    { id: 'amex-inj-7000', name: 'AMEX-LOADED-7000', balance: '$7,000', price: 599, oldPrice: 900 },
    { id: 'amex-inj-10000', name: 'AMEX-LOADED-10000', balance: '$10,000', price: 749, oldPrice: 1250 },
    { id: 'amex-inj-15000', name: 'AMEX-LOADED-15000', balance: '$15,000', price: 999, oldPrice: 1650 },
    { id: 'amex-inj-20000', name: 'AMEX-LOADED-20000', balance: '$20,000', price: 1299, oldPrice: 2150 },
    { id: 'amex-inj-25000', name: 'AMEX-LOADED-25000', balance: '$25,000', price: 1499, oldPrice: 2550 },
    { id: 'amex-inj-30000', name: 'AMEX-LOADED-30000', balance: '$30,000', price: 1999, oldPrice: 3250 },
  ].map(p => ({ ...p, image: IMG.amexInj, category: 'cards', subCategory: 'amex-inj', type: 'injected' as const, desc: { ar: 'بطاقات American Express محقونة بروتوكول 10.1 مع بيانات تطبيق كاملة', en: 'American Express Protocol 10.1 injected cards with full app credentials' }, details: amexInjDetails })),

  // ===== PAYPAL INJECTED =====
  ...[
    { id: 'pp-500', name: 'PayPal Account $500', balance: '$500', price: 99, oldPrice: 150 },
    { id: 'pp-1000', name: 'PayPal Account $1,000', balance: '$1,000', price: 180, oldPrice: 250 },
    { id: 'pp-2000', name: 'PayPal Account $2,000', balance: '$2,000', price: 250, oldPrice: 320 },
    { id: 'pp-3500', name: 'PayPal Account $3,500', balance: '$3,500', price: 450, oldPrice: 550 },
    { id: 'pp-5000', name: 'PayPal Account $5,000', balance: '$5,000', price: 600, oldPrice: 750 },
    { id: 'pp-7500', name: 'PayPal Account $7,500', balance: '$7,500', price: 900, oldPrice: 1100 },
    { id: 'pp-10000', name: 'PayPal Account $10,000', balance: '$10,000', price: 1200, oldPrice: 1500 },
  ].map(p => ({ ...p, image: IMG.paypal, category: 'cards', subCategory: 'paypal-inj', type: 'injected' as const, desc: { ar: 'حسابات PayPal شخصية وتجارية محقونة برصيد، ببيانات كاملة، تم فتحها يدوياً', en: 'Personal & Business PayPal accounts injected with balance, complete data, manually opened' }, details: paypalDetails })),
  // Extra injected wallets
  { id: 'skrill-1000', name: 'Skrill Account $1,000', balance: '$1,000', price: 150, oldPrice: 300, image: IMG.skrill, category: 'cards', subCategory: 'paypal-inj', type: 'injected', desc: { ar: 'حساب Skrill محقون برصيد $1,000 مع بيانات كاملة وتوثيق', en: 'Skrill account injected with $1,000 balance, complete data & verification' }, details: { ar: 'حساب Skrill موثق بالكامل (KYC Verified) محقون برصيد حقيقي. يسلم مع بيانات الدخول الكاملة والبطاقة المربوطة وبيانات المالك.', en: 'Fully verified Skrill account (KYC) injected with real balance. Delivered with full login credentials, linked card, and owner data.' } },
  { id: 'revolut-1000', name: 'Revolut Account $1,000', balance: '$1,000', price: 199, oldPrice: 400, image: IMG.revolut, category: 'cards', subCategory: 'paypal-inj', type: 'injected', desc: { ar: 'حساب Revolut محقون برصيد $1,000 مع بيانات كاملة', en: 'Revolut account injected with $1,000 balance, complete data' }, details: { ar: 'حساب Revolut موثق بالكامل محقون برصيد. يدعم التحويلات الدولية والعملات المتعددة. يسلم مع بيانات الدخول والبطاقة الافتراضية.', en: 'Fully verified Revolut account injected with balance. Supports international transfers and multiple currencies.' } },
  { id: 'cashapp-1000', name: 'CashApp Account $1,000', balance: '$1,000', price: 250, oldPrice: 300, image: IMG.cashapp, category: 'cards', subCategory: 'paypal-inj', type: 'injected', desc: { ar: 'حساب CashApp محقون برصيد $1,000 مع بيانات كاملة', en: 'CashApp account injected with $1,000 balance, complete data' }, details: { ar: 'حساب CashApp موثق محقون برصيد. يدعم إرسال واستقبال الأموال والبيتكوين. يسلم مع كامل بيانات الدخول.', en: 'Verified CashApp account injected with balance. Supports sending/receiving money and Bitcoin.' } },

  // ===== CREDIT CARDS - PULLED =====
  ...[
    { id: 'cred-800', name: 'CARD CREDIT-800', balance: '$800', price: 50, oldPrice: 70 },
    { id: 'cred-1500', name: 'CARD CREDIT-1500', balance: '$1,500', price: 75, oldPrice: 100 },
    { id: 'cred-2000', name: 'CARD CREDIT-2000', balance: '$2,000', price: 99, oldPrice: 130 },
    { id: 'cred-2500', name: 'CARD CREDIT-2500', balance: '$2,500', price: 119, oldPrice: 160 },
    { id: 'cred-3000', name: 'CARD CREDIT-3000', balance: '$3,000', price: 149, oldPrice: 190 },
    { id: 'cred-5000', name: 'CARD CREDIT-5000', balance: '$5,000', price: 199, oldPrice: 260 },
    { id: 'cred-7000', name: 'CARD CREDIT-7000', balance: '$7,000', price: 249, oldPrice: 330 },
    { id: 'cred-10000', name: 'CARD CREDIT-10000', balance: '$10,000', price: 349, oldPrice: 450 },
    { id: 'cred-15000', name: 'CARD CREDIT-15000', balance: '$15,000', price: 499, oldPrice: 650 },
  ].map(p => ({ ...p, image: IMG.credit, category: 'cards', subCategory: 'credit', type: 'pulled' as const, desc: { ar: 'بطاقات مديونية بحدود مرتفعة. وقت للعمل قبل صدور الفواتير', en: 'High-limit credit cards. Time to work before billing cycle' }, details: creditDetails })),
  ...[
    { id: 'cred-b5', name: 'CREDIT-BUNDLE-5', balance: '5 Cards', price: 140, oldPrice: 250, isBundle: true },
    { id: 'cred-b10', name: 'CREDIT-BUNDLE-10', balance: '10 Cards', price: 249, oldPrice: 400, isBundle: true },
    { id: 'cred-b15', name: 'CREDIT-BUNDLE-15', balance: '15 Cards', price: 350, oldPrice: 600, isBundle: true },
    { id: 'cred-b20', name: 'CREDIT-BUNDLE-20', balance: '20 Cards', price: 450, oldPrice: 800, isBundle: true },
  ].map(p => ({ ...p, image: IMG.credit, category: 'cards', subCategory: 'credit', type: 'pulled' as const, desc: { ar: 'بكج بطاقات Credit مسحوبة', en: 'Credit Cards Pulled Bundle' }, details: creditDetails })),

  // ===== DEBIT CARDS - PULLED =====
  ...[
    { id: 'deb-500', name: 'CARD DEBIT-500', balance: '$500', price: 25, oldPrice: 40 },
    { id: 'deb-1200', name: 'CARD DEBIT-1200', balance: '$1,200', price: 50, oldPrice: 75 },
    { id: 'deb-2000', name: 'CARD DEBIT-2000', balance: '$2,000', price: 75, oldPrice: 110 },
    { id: 'deb-3000', name: 'CARD DEBIT-3000', balance: '$3,000', price: 99, oldPrice: 140 },
    { id: 'deb-5000', name: 'CARD DEBIT-5000', balance: '$5,000', price: 149, oldPrice: 210 },
    { id: 'deb-7000', name: 'CARD DEBIT-7000', balance: '$7,000', price: 199, oldPrice: 280 },
    { id: 'deb-10000', name: 'CARD DEBIT-10000', balance: '$10,000', price: 299, oldPrice: 420 },
    { id: 'deb-15000', name: 'CARD DEBIT-15000', balance: '$15,000', price: 399, oldPrice: 550 },
    { id: 'deb-20000', name: 'CARD DEBIT-20000', balance: '$20,000', price: 499, oldPrice: 700 },
  ].map(p => ({ ...p, image: IMG.debit, category: 'cards', subCategory: 'debit', type: 'pulled' as const, desc: { ar: 'بطاقات مرتبطة بالرصيد البنكي مباشرة. تتطلب دقة عند الربط', en: 'Cards linked directly to bank balance. Requires precision when linking' }, details: debitDetails })),
  ...[
    { id: 'deb-b5', name: 'DEBIT-BUNDLE-5', balance: '5 Cards', price: 120, oldPrice: 200, isBundle: true },
    { id: 'deb-b10', name: 'DEBIT-BUNDLE-10', balance: '10 Cards', price: 149, oldPrice: 250, isBundle: true },
    { id: 'deb-b15', name: 'DEBIT-BUNDLE-15', balance: '15 Cards', price: 220, oldPrice: 370, isBundle: true },
    { id: 'deb-b20', name: 'DEBIT-BUNDLE-20', balance: '20 Cards', price: 290, oldPrice: 500, isBundle: true },
  ].map(p => ({ ...p, image: IMG.debit, category: 'cards', subCategory: 'debit', type: 'pulled' as const, desc: { ar: 'بكج بطاقات Debit مسحوبة', en: 'Debit Cards Pulled Bundle' }, details: debitDetails })),

  // ===== AMEX PULLED =====
  ...[
    { id: 'amex-600', name: 'AMEX-600', balance: '$600', price: 30, oldPrice: 50 },
    { id: 'amex-1000', name: 'AMEX-1000', balance: '$1,000', price: 49, oldPrice: 70 },
    { id: 'amex-1500', name: 'AMEX-1500', balance: '$1,500', price: 99, oldPrice: 120 },
    { id: 'amex-3000', name: 'AMEX-3000', balance: '$3,000', price: 199, oldPrice: 230 },
    { id: 'amex-5000', name: 'AMEX-5000', balance: '$5,000', price: 299, oldPrice: 380 },
    { id: 'amex-7000', name: 'AMEX-7000', balance: '$7,000', price: 449, oldPrice: 520 },
    { id: 'amex-10000', name: 'AMEX-10000', balance: '$10,000', price: 599, oldPrice: 700 },
    { id: 'amex-15000', name: 'AMEX-15000', balance: '$15,000', price: 799, oldPrice: 950 },
    { id: 'amex-30000', name: 'AMEX-30000', balance: '$30,000', price: 999, oldPrice: 1200 },
  ].map(p => ({ ...p, image: IMG.amex, category: 'cards', subCategory: 'amex-pulled', type: 'pulled' as const, desc: { ar: 'بطاقات American Express شريحة وبروتوكول 10.1 - بطاقات النخبة', en: 'American Express Chip & Protocol 10.1 - Elite cards' }, details: amexPulledDetails })),
  ...[
    { id: 'amex-b5', name: 'AMEX-BUNDLE-5', balance: '5 Cards', price: 149, oldPrice: 250, isBundle: true },
    { id: 'amex-b10', name: 'AMEX-BUNDLE-10', balance: '10 Cards', price: 179, oldPrice: 300, isBundle: true },
    { id: 'amex-b15', name: 'AMEX-BUNDLE-15', balance: '15 Cards', price: 249, oldPrice: 450, isBundle: true },
    { id: 'amex-b20', name: 'AMEX-BUNDLE-20', balance: '20 Cards', price: 349, oldPrice: 600, isBundle: true },
  ].map(p => ({ ...p, image: IMG.amex, category: 'cards', subCategory: 'amex-pulled', type: 'pulled' as const, desc: { ar: 'بكج بطاقات AMEX', en: 'AMEX Cards Bundle' }, details: amexPulledDetails })),

  // ===== CLASSIC - PULLED =====
  { id: 'classic-1', name: 'D3 Classic Card', balance: 'Raw Data', price: 20, oldPrice: 35, image: IMG.classic, category: 'cards', subCategory: 'classic', type: 'pulled', desc: { ar: 'بيانات خام (Raw Data) غير مفحوصة - Classic Visa/Mastercard', en: 'Raw unverified data - Classic Visa/Mastercard' }, details: { ar: '[ ⚠️ منطقة المحترفين ]\nهذه البطاقات تمتلك حماية مشفرة عالية جداً. لا يمكننا الجزم بالرصيد. نوفرها فقط لمن يمتلك الخبرة العالية والقدرة التقنية على فك التعقيد.', en: '[ ⚠️ Pro Zone ]\nThese cards have very high encrypted protection. Balance cannot be guaranteed. Available only for highly experienced users.' } },
  { id: 'classic-10', name: 'D3 Classic Bundle x10', balance: '10 Cards', price: 50, oldPrice: 100, image: IMG.classic, category: 'cards', subCategory: 'classic', type: 'pulled', isBundle: true, desc: { ar: 'بكج 10 بطاقات Classic خام', en: '10 Classic Raw Cards Bundle' }, details: { ar: 'بكج 10 بطاقات Classic خام بسعر مخفض.', en: 'Bundle of 10 Classic raw cards at discounted price.' } },

  // ===== PLATINUM - PULLED =====
  { id: 'plat-1', name: 'D3 Platinum Card', balance: 'Raw Data', price: 15, oldPrice: 25, image: IMG.platinum, category: 'cards', subCategory: 'platinum', type: 'pulled', desc: { ar: 'بيانات خام (Raw Data) غير مفحوصة - Platinum Visa/Mastercard', en: 'Raw unverified data - Platinum Visa/Mastercard' }, details: { ar: '[ ⚠️ منطقة المحترفين ]\nبطاقات بلاتينيوم بحماية 3D Secure عالية. مخصصة للعمليات الضخمة. تتطلب خبرة تقنية متقدمة.', en: '[ ⚠️ Pro Zone ]\nPlatinum cards with high 3D Secure protection. For large operations requiring advanced technical expertise.' } },
  { id: 'plat-15', name: 'D3 Platinum Bundle x15', balance: '15 Cards', price: 50, oldPrice: 100, image: IMG.platinum, category: 'cards', subCategory: 'platinum', type: 'pulled', isBundle: true, desc: { ar: 'بكج 15 بطاقة Platinum خام', en: '15 Platinum Raw Cards Bundle' }, details: { ar: 'بكج 15 بطاقة Platinum خام بسعر مخفض.', en: 'Bundle of 15 Platinum raw cards at discounted price.' } },
];

export const cardSubCategories = [
  { id: 'novbv', name: 'NOVBV CC', shortName: 'VBV', type: 'injected' as const, image: IMG.novbv, color: '#00d4ff' },
  { id: 'amex-inj', name: 'American Express محقونة', shortName: 'AME', type: 'injected' as const, image: IMG.amexInj, color: '#00d4ff' },
  { id: 'paypal-inj', name: 'PayPal محقونة', shortName: 'Pal', type: 'injected' as const, image: IMG.paypal, color: '#00d4ff' },
  { id: 'credit', name: 'Credit Cards', shortName: 'Cre', type: 'pulled' as const, image: IMG.credit, color: '#ff0040' },
  { id: 'debit', name: 'Debit Cards', shortName: 'Deb', type: 'pulled' as const, image: IMG.debit, color: '#ff0040' },
  { id: 'amex-pulled', name: 'AMEX Cards', shortName: 'AX', type: 'pulled' as const, image: IMG.amex, color: '#ff0040' },
  { id: 'classic', name: 'Classic Cards', shortName: 'Clc', type: 'pulled' as const, image: IMG.classic, color: '#ff0040' },
  { id: 'platinum', name: 'Platinum Cards', shortName: 'Plm', type: 'pulled' as const, image: IMG.platinum, color: '#ff0040' },
];

export const getCardProducts = (subCatId: string): StoreProduct[] => cardsProducts.filter(p => p.subCategory === subCatId);
export const getCardProductById = (id: string): StoreProduct | undefined => cardsProducts.find(p => p.id === id);
