import React from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';

const Cart: React.FC = () => {
  const { t, rtl, cartOpen, setCartOpen, cart, removeFromCart, updateQuantity, cartTotal, cartCount, setPaymentModalOpen } = useApp();

  if (!cartOpen) return null;

  const handleCheckout = () => {
    if (cart.length === 0) return;
    const products = cart.map(item =>
      `• ${item.name} x${item.quantity} — $${item.price * item.quantity}`
    ).join('\n');
    const message = `[🚨 طلب شراء جديد - BLACK MART]\n--------------------------------------\n🛒 سلة تسوق\n${products}\nالإجمالي: $${cartTotal}\n--------------------------------------\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.\n[SYSTEM_ID: AUTO]`;
    showBuyModal(rtl ? 'ar' : 'en', message);
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/70 z-[300] backdrop-blur-sm" onClick={() => setCartOpen(false)} />
      <div
        className={`fixed top-0 ${rtl ? 'left-0' : 'right-0'} w-[85%] sm:w-[400px] h-full bg-black z-[301] border border-neon-blue/30 flex flex-col slide-in-right`}
        style={{ direction: rtl ? 'rtl' : 'ltr' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neon-blue/20">
          <h2 className="text-lg font-bold text-neon-blue">🛒 {t('cart')}</h2>
          <button onClick={() => setCartOpen(false)} className="text-gray-400 hover:text-neon-red text-xl">✕</button>
        </div>

        {/* Info bar */}
        <div className="px-4 py-2 flex gap-2">
          <button
            onClick={() => { setCartOpen(false); setPaymentModalOpen(true); }}
            className="flex-1 py-2 text-xs font-bold bg-neon-gold/10 border border-neon-gold/30 rounded text-neon-gold hover:bg-neon-gold/20 transition-all"
          >
            {t('show_payments')}
          </button>
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-3">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <p className="text-gray-500 text-4xl mb-4">📭</p>
              <p className="text-gray-400 font-bold">{t('cart_empty')}</p>
              <button
                onClick={() => setCartOpen(false)}
                className="mt-4 px-6 py-2 bg-neon-blue/20 border border-neon-blue/40 rounded-lg text-neon-blue font-bold text-sm hover:bg-neon-blue/30 transition-all"
              >
                {t('start_shopping')}
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="flex gap-3 p-3 rounded-lg neon-border bg-dark-card">
                <div className="w-16 h-16 rounded bg-dark-surface border border-gray-800 flex items-center justify-center text-2xl flex-shrink-0">
                  🛍️
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-white truncate">{item.name}</p>
                  <p className="text-neon-green font-bold text-sm">${item.price}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-6 h-6 rounded bg-gray-800 text-white text-xs font-bold hover:bg-neon-red/30 transition-all flex items-center justify-center"
                    >
                      −
                    </button>
                    <span className="text-sm font-bold text-white w-6 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-6 h-6 rounded bg-gray-800 text-white text-xs font-bold hover:bg-neon-green/30 transition-all flex items-center justify-center"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ml-auto text-gray-500 hover:text-neon-red transition-colors"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div className="border-t border-neon-blue/20 p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">{cartCount} {t('items_count')}</span>
              <span className="text-neon-green font-black text-lg">${cartTotal}</span>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full py-3 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg text-lg hover:opacity-90 transition-all neon-pulse"
            >
              {t('checkout')}
            </button>
            <button
              onClick={() => setCartOpen(false)}
              className="w-full py-2 text-gray-500 text-sm hover:text-white transition-colors"
            >
              {t('close_cart')}
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default Cart;
