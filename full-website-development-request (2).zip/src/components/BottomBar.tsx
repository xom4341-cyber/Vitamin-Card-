import React from 'react';
import { useApp } from '../context/AppContext';

const BottomBar: React.FC = () => {
  const { t, setCurrentPage, setPaymentModalOpen, sessionTime, onlineUsers } = useApp();

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[80]" style={{ background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
      <div className="h-[1px] bg-gradient-to-r from-transparent via-neon-blue/20 to-transparent" />
      <div className="flex items-center justify-between px-3 py-2.5 text-xs">
        {/* Back button */}
        <button
          onClick={() => setCurrentPage('home')}
          className="px-3 py-1.5 rounded-lg bg-dark-surface border border-gray-800 text-neon-blue font-bold hover:bg-neon-blue/10 transition-all text-[11px]"
        >
          {t('back')}
        </button>

        {/* Payment methods */}
        <button
          onClick={() => setPaymentModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-neon-gold/5 border border-neon-gold/20 rounded-lg text-neon-gold font-bold hover:bg-neon-gold/10 transition-all text-[11px]"
        >
          💳 USDT | BTC | ETH
        </button>

        {/* Session timer & online */}
        <div className="flex items-center gap-3 text-[11px]">
          <span className="hidden sm:flex items-center gap-1 text-gray-600">
            <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
            {onlineUsers}
          </span>
          <span className="text-gray-600" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
            {formatTime(sessionTime)}
          </span>
        </div>
      </div>
    </div>
  );
};

export default BottomBar;
