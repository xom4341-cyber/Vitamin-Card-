import React from 'react';
import { useApp } from '../context/AppContext';

const Header: React.FC = () => {
  const { setSidebarOpen, setCartOpen, cartCount, setCurrentPage } = useApp();

  return (
    <header className="sticky top-0 z-[100]" style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
      {/* Top neon line */}
      <div className="h-[1px] bg-gradient-to-r from-transparent via-neon-blue/60 to-transparent" />

      <div className="flex items-center justify-between px-4 py-3">
        {/* Menu button */}
        <button
          onClick={() => setSidebarOpen(true)}
          className="w-9 h-9 rounded-lg bg-dark-surface border border-gray-800 flex items-center justify-center text-white hover:text-neon-blue hover:border-neon-blue/30 transition-all text-lg"
        >
          ☰
        </button>

        {/* Logo */}
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <span className="text-xl skull-glow transition-transform group-hover:scale-110">☠️</span>
          <span
            className="text-lg md:text-xl font-black tracking-[0.15em]"
            style={{ fontFamily: 'Orbitron, sans-serif' }}
          >
            <span className="text-neon-blue">BLACK</span>
            <span className="text-white ml-1.5">MART</span>
          </span>
        </button>

        {/* Channel + Cart */}
        <div className="flex items-center gap-2">
          <a href="https://t.me/QrRrut7Ejug0Mzg0" target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center text-[12px] hover:bg-neon-blue/20 transition-all">📢</a>
        <button
          onClick={() => setCartOpen(true)}
          className="w-9 h-9 rounded-lg bg-dark-surface border border-gray-800 flex items-center justify-center text-white hover:text-neon-blue hover:border-neon-blue/30 transition-all text-lg relative"
        >
          🛒
          {cartCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-neon-red text-white text-[9px] font-black rounded-full w-5 h-5 flex items-center justify-center count-up shadow-[0_0_8px_#ff004066]">
              {cartCount}
            </span>
          )}
        </button>
        </div>
      </div>

      {/* Bottom subtle line */}
      <div className="h-[1px] bg-gradient-to-r from-transparent via-gray-800/50 to-transparent" />
    </header>
  );
};

export default Header;
