import React from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import type { Product } from '../data/products';

interface Props {
  product: Product;
}

const ProductCard: React.FC<Props> = ({ product }) => {
  const { t, lang, addToCart, setProductDetail } = useApp();

  const handleBuy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const message = `[🚨 طلب شراء جديد - BLACK MART]\n--------------------------------------\nالخدمة: ${product.name[lang]}\nالسعر: $${product.price}\n--------------------------------------\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.\n[SYSTEM_ID: AUTO]`;
    showBuyModal(lang, message);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      id: product.id,
      name: product.name[lang],
      price: product.price,
      oldPrice: product.oldPrice,
      balance: product.balance,
      image: product.image,
      category: product.category,
    });
  };

  return (
    <div
      onClick={() => setProductDetail(product.id)}
      className="rounded-lg neon-border bg-dark-card overflow-hidden card-hover cursor-pointer group"
    >
      {/* Image */}
      <div className="aspect-[3/2] bg-dark-surface flex items-center justify-center text-3xl relative overflow-hidden">
        🛍️
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="p-2.5">
        <h4 className="text-xs font-bold text-white truncate mb-1 group-hover:text-neon-blue transition-colors">
          {product.name[lang]}
        </h4>
        <p className="text-[10px] text-gray-500 truncate mb-1.5">
          {product.desc[lang]}
        </p>

        {/* Balance */}
        <p className="text-[10px] text-neon-green font-bold mb-1">
          🟢 {product.balance}
        </p>

        {/* Prices */}
        <div className="flex items-center gap-1.5 mb-2">
          <span className="text-[10px] text-neon-red line-through">${product.oldPrice}</span>
          <span className="text-xs text-neon-green font-black">${product.price}</span>
        </div>

        {/* Buttons */}
        <div className="flex gap-1.5">
          <button
            onClick={(e) => { e.stopPropagation(); setProductDetail(product.id); }}
            className="flex-1 py-1.5 text-[10px] font-bold bg-gray-800 text-gray-300 rounded hover:bg-gray-700 transition-all"
          >
            {t('details')}
          </button>
          <button
            onClick={handleAddToCart}
            className="flex-1 py-1.5 text-[10px] font-bold bg-neon-blue/10 border border-neon-blue/30 text-neon-blue rounded hover:bg-neon-blue/20 transition-all"
          >
            🛒
          </button>
          <button
            onClick={handleBuy}
            className="flex-1 py-1.5 text-[10px] font-bold bg-neon-green/10 border border-neon-green/30 text-neon-green rounded hover:bg-neon-green/20 transition-all"
          >
            {t('buy_now')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
