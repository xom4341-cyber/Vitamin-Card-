import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';

const CommandCenter: React.FC = () => {
  const { t, setPaymentModalOpen } = useApp();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [hasShownWelcome, setHasShownWelcome] = useState(false);

  const slides = Array.from({ length: 7 }, (_, i) => ({
    title: t(`command_slide_${i}_title`),
    text: t(`command_slide_${i}_text`),
  }));

  // Typewriter effect
  useEffect(() => {
    setIsTyping(true);
    setDisplayText('');
    const text = slides[currentSlide].text;
    let charIdx = 0;
    const typeInterval = setInterval(() => {
      if (charIdx < text.length) {
        setDisplayText(text.slice(0, charIdx + 1));
        charIdx++;
      } else {
        clearInterval(typeInterval);
        setIsTyping(false);
      }
    }, 25);
    return () => clearInterval(typeInterval);
  }, [currentSlide]);

  // Auto slide - slide 0 shows for 5s, rest 10s
  useEffect(() => {
    const duration = currentSlide === 0 && !hasShownWelcome ? 5000 : 10000;
    intervalRef.current = setInterval(() => {
      if (currentSlide === 0) setHasShownWelcome(true);
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, duration);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [currentSlide, slides.length, hasShownWelcome]);

  const goToSlide = (idx: number) => {
    setCurrentSlide(idx);
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 10000);
  };

  return (
    <div className="relative rounded-xl bg-dark-card overflow-hidden" style={{ border: '1px solid #00d4ff20' }}>
      {/* Matrix background effect */}
      <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: 'linear-gradient(#00d4ff 1px, transparent 1px), linear-gradient(90deg, #00d4ff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
      <div className="scanline" />

      {/* Title bar */}
      <div className="flex items-center gap-2 px-4 py-2 bg-neon-blue/5 border-b border-neon-blue/10 relative z-10">
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-neon-red/70" />
          <div className="w-2.5 h-2.5 rounded-full bg-neon-gold/70" />
          <div className="w-2.5 h-2.5 rounded-full bg-neon-green/70" />
        </div>
        <span className="text-[10px] text-neon-blue font-bold ml-2 tracking-wider" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
          ██ COMMAND CENTER ██
        </span>
      </div>

      {/* Content */}
      <div className="p-4 md:p-5 min-h-[130px] relative z-10">
        <h3 className="text-neon-blue font-black text-sm md:text-base mb-3 tracking-wide" style={{ fontFamily: 'Orbitron, Share Tech Mono, monospace' }}>
          &gt; {slides[currentSlide].title}
        </h3>
        <p className="text-gray-300 text-xs md:text-sm leading-relaxed" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
          {displayText}
          {isTyping && <span className="typewriter-cursor inline-block w-2 ml-0.5" />}
        </p>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between px-4 py-2.5 border-t border-neon-blue/10 relative z-10">
        <div className="flex items-center gap-2">
          <button onClick={() => goToSlide((currentSlide - 1 + slides.length) % slides.length)} className="text-neon-blue hover:text-white transition-colors text-sm w-6 h-6 rounded bg-neon-blue/10 flex items-center justify-center">◀</button>
          <div className="flex gap-1">
            {slides.map((_, i) => (
              <button key={i} onClick={() => goToSlide(i)} className={`w-1.5 h-1.5 rounded-full transition-all ${i === currentSlide ? 'bg-neon-blue scale-125' : 'bg-gray-700 hover:bg-gray-500'}`} />
            ))}
          </div>
          <button onClick={() => goToSlide((currentSlide + 1) % slides.length)} className="text-neon-blue hover:text-white transition-colors text-sm w-6 h-6 rounded bg-neon-blue/10 flex items-center justify-center">▶</button>
        </div>
        <button onClick={() => setPaymentModalOpen(true)} className="px-3 py-1.5 bg-neon-gold/10 border border-neon-gold/30 rounded-lg text-neon-gold text-[10px] font-bold hover:bg-neon-gold/20 transition-all">{t('show_payments')}</button>
      </div>
    </div>
  );
};

export default CommandCenter;
