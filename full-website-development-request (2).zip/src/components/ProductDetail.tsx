import React from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import { getProductById } from '../data/products';

const ProductDetail: React.FC = () => {
  const { t, lang, rtl, productDetail, setProductDetail, addToCart } = useApp();

  if (!productDetail) return null;

  const product = getProductById(productDetail);
  if (!product) return null;

  const handleBuy = () => {
    const message = `[🚨 طلب شراء جديد - BLACK MART]\n--------------------------------------\nالخدمة: ${product.name[lang]}\nالسعر: $${product.price}\n--------------------------------------\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.\n[SYSTEM_ID: AUTO]`;
    showBuyModal(lang, message);
  };

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name[lang],
      price: product.price,
      oldPrice: product.oldPrice,
      balance: product.balance,
      image: product.image,
      category: product.category,
    });
  };

  return (
    <div className="fixed inset-0 z-[500] bg-black overflow-y-auto" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Content */}
      <div className="max-w-lg mx-auto px-4 py-6 pb-24">
        {/* Image */}
        <div className="w-full aspect-video rounded-xl bg-dark-card border border-neon-blue/20 flex items-center justify-center text-6xl mb-6">
          🛍️
        </div>

        {/* Name */}
        <h1 className="text-xl md:text-2xl font-black text-white mb-3">
          {product.name[lang]}
        </h1>

        {/* Balance */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-neon-green font-bold text-sm">🟢 {t('balance')}:</span>
          <span className="text-neon-green font-black text-lg">{product.balance}</span>
        </div>

        {/* Prices */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-neon-red line-through text-sm">🔴 ${product.oldPrice}</span>
          <span className="text-neon-green font-black text-2xl">🟢 ${product.price}</span>
        </div>

        {/* Details */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-6">
          <h3 className="text-neon-blue font-bold text-base mb-3">{t('product_details')}</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            {product.desc[lang]}
          </p>
          <div className="mt-4 space-y-2">
            <div className="flex justify-between py-2 border-b border-gray-800">
              <span className="text-gray-500 text-xs">{t('balance')}</span>
              <span className="text-neon-green text-xs font-bold">{product.balance}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-800">
              <span className="text-gray-500 text-xs">ID</span>
              <span className="text-gray-400 text-xs font-mono">{product.id}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-gray-500 text-xs">Type</span>
              <span className="text-neon-blue text-xs font-bold uppercase">{product.type}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed bottom buttons */}
      <div className="fixed bottom-0 left-0 right-0 glass border-t border-neon-blue/20 p-4 z-[501]">
        <div className="max-w-lg mx-auto flex gap-3">
          <button
            onClick={handleBuy}
            className="flex-1 py-3 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg hover:opacity-90 transition-all"
          >
            {t('continue_shopping')}
          </button>
          <button
            onClick={handleAddToCart}
            className="flex-1 py-3 bg-neon-blue/10 border border-neon-blue/40 text-neon-blue font-bold rounded-lg hover:bg-neon-blue/20 transition-all"
          >
            {t('add_to_cart')}
          </button>
          <button
            onClick={() => setProductDetail(null)}
            className="px-4 py-3 bg-gray-900 border border-gray-700 text-gray-400 font-bold rounded-lg hover:text-white hover:border-gray-500 transition-all"
          >
            ✕
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
