import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';

const products = [
  'NOVBV CC-3000','NOVBV CC-5000','AMEX 10.1','PayPal Account','Flash USDT',
  'Binance Gift Card','Apple Card','TikTok 500K','Bypass Pro Proxy','BlackGPT-Core',
  'Credit Card','Debit Card','Shopify Store','Amazon Gift Card','Shadow RDP',
  'Cards Checker','Flash Tool','Wise Account','Binance Verified','Elite Dump Course',
];

const FakePurchase: React.FC = () => {
  const { lang } = useApp();
  const [visible, setVisible] = useState(false);
  const [product, setProduct] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setProduct(products[Math.floor(Math.random() * products.length)]);
      setVisible(true);
      setTimeout(() => setVisible(false), 5000);
    }, 30000);

    // First one after 10 seconds
    const first = setTimeout(() => {
      setProduct(products[Math.floor(Math.random() * products.length)]);
      setVisible(true);
      setTimeout(() => setVisible(false), 5000);
    }, 10000);

    return () => { clearInterval(interval); clearTimeout(first); };
  }, []);

  if (!visible) return null;

  const msg = lang==='ar' ? `تم شراء ${product}` : lang==='ru' ? `Куплено: ${product}` : `Purchased: ${product}`;

  return (
    <div className="fixed top-[110px] left-1/2 -translate-x-1/2 z-[200] max-w-xs w-[90%]" style={{animation:'fadeInOut 5s ease-in-out'}}>
      <div className="bg-[#0a1a0a] border border-[#00ff4130] rounded-xl px-4 py-2.5 flex items-center gap-2 shadow-[0_0_15px_#00ff4115]">
        <span className="text-neon-green text-sm">✅</span>
        <p className="text-[11px] text-[#00ff88] font-bold flex-1" style={{fontFamily:'Share Tech Mono, monospace'}}>{msg}</p>
      </div>
      <style>{`@keyframes fadeInOut{0%{opacity:0;transform:translateX(-50%) translateY(-10px)}10%{opacity:1;transform:translateX(-50%) translateY(0)}85%{opacity:1}100%{opacity:0}}`}</style>
    </div>
  );
};

export default FakePurchase;
