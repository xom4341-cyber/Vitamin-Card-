import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';

interface Props {
  onComplete: () => void;
}

const LoadingScreen: React.FC<Props> = ({ onComplete }) => {
  const { t } = useApp();
  const [progress, setProgress] = useState(0);
  const [lines, setLines] = useState<{text:string;done:boolean}[]>([]);
  const [fading, setFading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [port] = useState(Math.floor(Math.random()*9000)+1000);
  const [packet, setPacket] = useState(0);

  // Matrix rain effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    void (window.devicePixelRatio || 1);
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.style.width = window.innerWidth + 'px';
    canvas.style.height = window.innerHeight + 'px';

    const fontSize = 14;
    const columns = Math.max(1, Math.floor(canvas.width / fontSize));
    const drops: number[] = Array(columns).fill(1);

    const chars = '01001011101001010110100101011010010101101001010110100101011010010101';

    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#00ff4120';
      ctx.font = `${fontSize}px 'Share Tech Mono', monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        // Vary green intensity
        const intensity = Math.random();
        if (intensity > 0.7) {
          ctx.fillStyle = '#00ff4140';
        } else if (intensity > 0.4) {
          ctx.fillStyle = '#00ff4125';
        } else {
          ctx.fillStyle = '#00ff4112';
        }
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    };

    const interval = setInterval(draw, 45);

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearInterval(interval);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Loading sequence
  useEffect(() => {
    const steps = [
      { text: t('loading_ip'), delay: 600 },
      { text: '(Tor) جاري الاتصال بجهاز التوجيه البصلي...', delay: 1200 },
      { text: '(SOCKS5) إنشاء طبقة بروكسي آمنة...', delay: 2000 },
      { text: '...حقن التواقيع المشفرة في السيرفر', delay: 2800 },
      { text: 'SHA-512 تشفير الهوية الرقمية بالكامل عبر...', delay: 3500 },
    ];

    steps.forEach(({ text, delay }) => {
      setTimeout(() => {
        setLines(prev => [...prev, { text, done: delay > 3000 }]);
      }, delay);
    });

    // Progress bar
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) { clearInterval(interval); return 100; }
        return prev + Math.random() * 3 + 1;
      });
      setPacket(prev => prev + Math.floor(Math.random() * 50) + 10);
    }, 60);

    // Fade and complete
    const fadeTimer = setTimeout(() => setFading(true), 4200);
    const completeTimer = setTimeout(() => onComplete(), 5000);

    return () => {
      clearInterval(interval);
      clearTimeout(fadeTimer);
      clearTimeout(completeTimer);
    };
  }, []);

  const clampedProgress = Math.min(Math.round(progress), 100);

  return (
    <div className={`fixed inset-0 z-[10000] bg-black flex flex-col items-center justify-center transition-opacity duration-700 ${fading ? 'opacity-0' : 'opacity-100'}`}>
      {/* Matrix canvas background */}
      <canvas ref={canvasRef} className="absolute inset-0 z-0" />

      {/* Content overlay */}
      <div className="relative z-10 w-full max-w-md px-6 flex flex-col items-center">
        {/* Status text with pulsing dot */}
        <div className="flex items-center gap-2 mb-4">
          <span className="text-[#00ff41] font-bold text-sm" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
            ...{t('loading_encrypt').replace('> ', '')}
          </span>
          <span className="w-2 h-2 rounded-full bg-[#00ff41] animate-pulse" />
        </div>

        {/* Progress bar - green neon */}
        <div className="w-full h-3 bg-gray-900/80 rounded-full overflow-hidden border border-[#00ff4130] mb-6">
          <div
            className="h-full rounded-full transition-all duration-150 ease-out"
            style={{
              width: `${clampedProgress}%`,
              background: 'linear-gradient(90deg, #00ff41, #00cc33)',
              boxShadow: '0 0 15px #00ff4166, 0 0 30px #00ff4133',
            }}
          />
        </div>

        {/* Terminal box */}
        <div className="w-full bg-black/80 border border-[#00ff4120] rounded-lg p-4 mb-4" style={{ backdropFilter: 'blur(5px)' }}>
          <div className="space-y-2">
            {lines.map((line, i) => (
              <div key={i} className="flex items-start gap-2" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
                <span className={`text-sm ${i === lines.length - 1 && !fading ? 'text-[#00ff41]' : 'text-[#00ff4180]'}`}>{'>'}</span>
                <span className={`text-sm ${i === lines.length - 1 && !fading ? 'text-[#00ff41]' : 'text-[#00ff4180]'}`}>
                  {line.text}
                </span>
                {i === lines.length - 1 && !fading && (
                  <span className="w-2 h-4 bg-[#00ff41] animate-pulse inline-block ml-1" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Port & Packet info */}
        <div className="text-[#00ff4160] text-xs tracking-widest" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
          SECURE PORT: {port} | PACKET: {packet}KB
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;
