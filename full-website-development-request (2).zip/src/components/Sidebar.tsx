import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { allLangs } from '../i18n';

interface UserData {
  name: string;
  email: string;
  id: string;
  avatar: string;
  points: number;
  referralLink: string;
}

const Sidebar: React.FC = () => {
  const { t, rtl, sidebarOpen, setSidebarOpen, setLang, setCurrentPage } = useApp();
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showShareOptions, setShowShareOptions] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [regLoading, setRegLoading] = useState(false);

  // Login fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');

  // Register fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regConfirm, setRegConfirm] = useState('');

  // User state from localStorage
  const [user, setUser] = useState<UserData | null>(() => {
    try {
      const saved = localStorage.getItem('bm_user_data');
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  });

  // Profile edit
  const [editName, setEditName] = useState(user?.name || '');

  useEffect(() => {
    if (user) {
      localStorage.setItem('bm_user_data', JSON.stringify(user));
      setEditName(user.name);
    }
  }, [user]);

  if (!sidebarOpen) return null;

  const handleNav = (page: string) => { setSidebarOpen(false); setCurrentPage(page); };

  // Email validation
  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  // Generate random ID
  const generateId = () => String(Math.floor(10000000 + Math.random() * 90000000));

  // Login handler
  const handleLogin = () => {
    setLoginError('');
    if (!loginEmail || !loginPass) { setLoginError(rtl ? 'يرجى ملء جميع الحقول' : 'Please fill all fields'); return; }
    if (!isValidEmail(loginEmail)) { setLoginError(rtl ? 'بريد إلكتروني غير صالح' : 'Invalid email address'); return; }
    // Always show "not registered"
    setLoginError(rtl ? '⚠️ الحساب غير مسجل في النظام' : '⚠️ Account not registered in the system');
  };

  // Register handler
  const handleRegister = () => {
    setLoginError('');
    if (!regName || !regEmail || !regPass || !regConfirm) { setLoginError(rtl ? 'يرجى ملء جميع الحقول' : 'Please fill all fields'); return; }
    if (!isValidEmail(regEmail)) { setLoginError(rtl ? 'بريد إلكتروني غير صالح' : 'Invalid email address'); return; }
    if (regPass !== regConfirm) { setLoginError(rtl ? 'كلمة المرور غير متطابقة' : 'Passwords do not match'); return; }
    if (regPass.length < 6) { setLoginError(rtl ? 'كلمة المرور قصيرة جداً (6 أحرف كحد أدنى)' : 'Password too short (min 6 chars)'); return; }

    setRegLoading(true);
    setLoginError('');
    setTimeout(() => {
      const newUser: UserData = {
        name: regName,
        email: regEmail,
        id: generateId(),
        avatar: '👤',
        points: 0,
        referralLink: `${window.location.origin}?ref=${generateId()}`,
      };
      setUser(newUser);
      setRegLoading(false);
      setShowRegister(false);
      setShowLogin(false);
      setRegName(''); setRegEmail(''); setRegPass(''); setRegConfirm('');
    }, 10000);
  };

  // Logout
  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('bm_user_data');
    setShowProfile(false);
  };

  // Profile save
  const handleSaveProfile = () => {
    if (user && editName.trim()) {
      setUser({ ...user, name: editName.trim() });
    }
  };

  // ===== PROFILE PAGE =====
  if (showProfile && user) {
    return (
      <>
        <div className="fixed inset-0 bg-black/80 z-[200] backdrop-blur-sm" onClick={() => setShowProfile(false)} />
        <div className="fixed inset-0 z-[201] bg-black overflow-y-auto" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
          <div className="max-w-md mx-auto px-4 py-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-black text-neon-blue">{rtl ? 'صفحة العضو' : 'Member Profile'}</h2>
              <button onClick={() => { setShowProfile(false); setSidebarOpen(true); }} className="w-8 h-8 rounded-lg bg-neon-red/10 border border-neon-red/20 text-neon-red flex items-center justify-center">✕</button>
            </div>

            {/* Avatar & Info */}
            <div className="rounded-xl bg-dark-card p-5 text-center mb-4 border border-neon-blue/10">
              <div className="relative w-20 h-20 mx-auto mb-3">
                {user.avatar.startsWith('data:') ? (
                  <img src={user.avatar} alt="" className="w-20 h-20 rounded-full object-cover border-2 border-neon-blue/30" />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-neon-blue/10 border-2 border-neon-blue/30 flex items-center justify-center text-4xl">{user.avatar}</div>
                )}
                <label className="absolute bottom-0 right-0 w-7 h-7 bg-neon-blue rounded-full flex items-center justify-center cursor-pointer text-black text-xs font-bold border-2 border-black">
                  📷
                  <input type="file" accept="image/*" className="hidden" onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = ev => { if (ev.target?.result && user) setUser({ ...user, avatar: ev.target.result as string }); };
                      reader.readAsDataURL(file);
                    }
                  }} />
                </label>
              </div>
              <h3 className="text-lg font-black text-white">{user.name}</h3>
              <p className="text-xs text-gray-500 font-mono mt-1">ID: {user.id}</p>
              <p className="text-[10px] text-gray-600 mt-1">{user.email}</p>
            </div>

            {/* Edit Name */}
            <div className="rounded-xl bg-dark-card p-4 mb-4 border border-gray-800/50">
              <h4 className="text-xs font-bold text-neon-blue mb-2">{rtl ? 'تعديل الاسم' : 'Edit Name'}</h4>
              <input value={editName} onChange={e => setEditName(e.target.value)} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-neon-blue/40 mb-2" />
              <button onClick={handleSaveProfile} className="w-full py-2 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-xs font-bold">{rtl ? '💾 حفظ التغييرات' : '💾 Save Changes'}</button>
            </div>

            {/* Points Wallet */}
            <div className="rounded-xl bg-dark-card p-4 mb-4 border border-neon-gold/10">
              <h4 className="text-xs font-bold text-neon-gold mb-2">💰 {rtl ? 'محفظة النقاط' : 'Points Wallet'}</h4>
              <p className="text-2xl font-black text-neon-gold text-center my-3">{user.points} <span className="text-sm">{rtl ? 'نقطة' : 'Points'}</span></p>
              <p className="text-[10px] text-gray-500 text-center">{rtl ? 'شارك رابط الإحالة واكسب نقاط مع كل زائر جديد!' : 'Share your referral link and earn points with every new visitor!'}</p>
            </div>

            {/* Referral Link */}
            <div className="rounded-xl bg-dark-card p-4 mb-4 border border-neon-green/10">
              <h4 className="text-xs font-bold text-neon-green mb-2">🔗 {rtl ? 'رابط الإحالة الخاص بك' : 'Your Referral Link'}</h4>
              <div className="flex gap-2">
                <code className="flex-1 text-[10px] text-gray-400 bg-dark-surface px-3 py-2 rounded-lg font-mono break-all border border-gray-800" style={{ userSelect: 'text' }}>{user.referralLink}</code>
                <button onClick={() => navigator.clipboard.writeText(user.referralLink)} className="px-3 py-2 bg-neon-green/10 border border-neon-green/20 rounded-lg text-neon-green text-xs font-bold flex-shrink-0">📋</button>
              </div>
            </div>

            {/* Logout */}
            <button onClick={handleLogout} className="w-full py-3 bg-neon-red/10 border border-neon-red/20 rounded-xl text-neon-red font-bold text-sm mt-4">
              🚪 {rtl ? 'تسجيل خروج' : 'Logout'}
            </button>
          </div>
        </div>
      </>
    );
  }

  // ===== REGISTRATION LOADING =====
  if (regLoading) {
    return (
      <>
        <div className="fixed inset-0 bg-black/90 z-[200]" />
        <div className="fixed inset-0 z-[201] flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-3 border-neon-blue/30 border-t-neon-blue rounded-full animate-spin mb-4" style={{ borderWidth: '3px' }} />
          <p className="text-neon-blue text-sm font-bold animate-pulse" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
            {rtl ? '...جاري التحقق من التشفير' : 'Verifying encryption...'}
          </p>
          <p className="text-gray-600 text-[10px] mt-2">{rtl ? 'يرجى الانتظار' : 'Please wait'}</p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="fixed inset-0 bg-black/80 z-[200] backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
      <div className="fixed top-0 right-0 w-[75%] sm:w-[50%] max-w-sm h-full z-[201] overflow-y-auto slide-in-right" style={{ direction: rtl ? 'rtl' : 'ltr', background: 'linear-gradient(180deg, #060610 0%, #000 100%)', borderLeft: '1px solid #00d4ff22' }}>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neon-blue/15">
          <div className="flex items-center gap-2">
            <span className="text-lg skull-glow">☠️</span>
            <span className="text-sm font-black tracking-wider" style={{ fontFamily: 'Orbitron, sans-serif' }}>
              <span className="text-neon-blue">BLACK</span><span className="text-white ml-1">MART</span>
            </span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="w-7 h-7 rounded bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center text-neon-blue text-sm">✕</button>
        </div>

        {/* ===== USER SECTION ===== */}
        {user ? (
          /* LOGGED IN - Member card */
          <div className="mx-4 mt-3 rounded-xl bg-dark-card border border-neon-blue/15 p-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center text-xl">{user.avatar}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate">{user.name}</p>
                <p className="text-[9px] text-gray-500 font-mono">ID: {user.id}</p>
              </div>
              <button onClick={() => setShowProfile(true)} className="px-2.5 py-1.5 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-[9px] font-bold">
                {rtl ? 'عرض الصفحة' : 'View Profile'}
              </button>
            </div>
          </div>
        ) : (
          /* NOT LOGGED IN - Login button */
          <div className="mx-4 mt-3">
            <button onClick={() => { setShowLogin(true); setShowRegister(false); setLoginError(''); }} className="w-full flex items-center gap-3 p-3 rounded-xl bg-dark-card border border-gray-800/50 hover:border-neon-blue/20 transition-all">
              <span className="text-lg">👤</span>
              <span className="text-sm font-bold text-gray-300">{t('sidebar_login')}</span>
            </button>
          </div>
        )}

        {/* ===== LOGIN MODAL (inside sidebar) ===== */}
        {showLogin && !user && !showRegister && (
          <div className="mx-4 mt-3 rounded-xl bg-dark-card border border-neon-blue/20 p-4 fade-in">
            <h3 className="text-sm font-bold text-neon-blue mb-3">{rtl ? 'تسجيل الدخول' : 'Login'}</h3>
            <input value={loginEmail} onChange={e => setLoginEmail(e.target.value)} type="email" placeholder={rtl ? 'البريد الإلكتروني' : 'Email Address'} className="w-full mb-2 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={loginPass} onChange={e => setLoginPass(e.target.value)} type="password" placeholder={rtl ? 'كلمة المرور' : 'Password'} className="w-full mb-3 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            {loginError && <p className="text-neon-red text-[10px] mb-2 p-2 rounded bg-neon-red/5 border border-neon-red/10">{loginError}</p>}
            <button onClick={handleLogin} className="w-full py-2.5 bg-neon-blue/20 border border-neon-blue/40 rounded-lg text-neon-blue font-bold text-sm mb-2">{rtl ? 'دخول' : 'Login'}</button>
            <button onClick={() => { setShowRegister(true); setLoginError(''); }} className="w-full text-center text-xs text-neon-red font-bold hover:underline">{rtl ? 'إنشاء حساب جديد' : 'Create New Account'}</button>
            <button onClick={() => setShowLogin(false)} className="w-full mt-2 text-center text-[10px] text-gray-600">✕ {t('close')}</button>
          </div>
        )}

        {/* ===== REGISTER MODAL (inside sidebar) ===== */}
        {showRegister && !user && (
          <div className="mx-4 mt-3 rounded-xl bg-dark-card border border-neon-blue/20 p-4 fade-in">
            <h3 className="text-sm font-bold text-neon-blue mb-1">{rtl ? 'سجّل في Black Mart' : 'Register at Black Mart'}</h3>
            <p className="text-[9px] text-gray-500 mb-3">{rtl ? 'بياناتك مشفرة بتقنية التشفير الطرفي (End-to-End)، حتى نحن لا نملك صلاحية الوصول إليها.' : 'Your data is encrypted with End-to-End encryption. Even we cannot access it.'}</p>
            <input value={regName} onChange={e => setRegName(e.target.value)} placeholder={rtl ? 'الاسم' : 'Name'} className="w-full mb-2 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={regEmail} onChange={e => setRegEmail(e.target.value)} type="email" placeholder={rtl ? 'البريد الإلكتروني' : 'Email Address'} className="w-full mb-2 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={regPass} onChange={e => setRegPass(e.target.value)} type="password" placeholder={rtl ? 'كلمة المرور' : 'Password'} className="w-full mb-2 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={regConfirm} onChange={e => setRegConfirm(e.target.value)} type="password" placeholder={rtl ? 'تأكيد كلمة المرور' : 'Confirm Password'} className="w-full mb-3 px-3 py-2.5 bg-dark-surface border border-gray-800 rounded-lg text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            {loginError && <p className="text-neon-red text-[10px] mb-2 p-2 rounded bg-neon-red/5 border border-neon-red/10">{loginError}</p>}
            <button onClick={handleRegister} className="w-full py-2.5 bg-gradient-to-r from-neon-blue to-neon-green text-black font-bold text-sm rounded-lg mb-2">{rtl ? 'إنشاء حساب' : 'Create Account'}</button>
            <button onClick={() => { setShowRegister(false); setLoginError(''); }} className="w-full text-center text-[10px] text-gray-500">{rtl ? '← العودة لتسجيل الدخول' : '← Back to Login'}</button>
          </div>
        )}

        <div className="mx-5 my-2 h-[1px] bg-gray-800/50" />

        {/* ===== 9 MENU BUTTONS (always visible) ===== */}
        <div className="py-1">
          {/* 1. Language */}
          <button onClick={() => setShowLangPicker(!showLangPicker)} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">🌐</span>
            <span className="flex-1 text-start">{t('sidebar_language')}</span>
            <span className="text-neon-blue text-xs">{showLangPicker ? '▲' : '▼'}</span>
          </button>
          {showLangPicker && (
            <div className="px-5 py-2 flex gap-2 fade-in">
              {allLangs.map(l => (
                <button key={l.code} onClick={() => { setLang(l.code); setShowLangPicker(false); setSidebarOpen(false); }} className="flex-1 py-2 bg-neon-red/15 border border-neon-red/30 rounded-lg text-white text-xs font-bold hover:bg-neon-red/30 transition-all">{l.flag} {l.name}</button>
              ))}
            </div>
          )}

          <div className="mx-5 my-1 h-[1px] bg-gray-800/50" />

          {/* 2. Payment Methods */}
          <button onClick={() => handleNav('payment-page')} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">💳</span><span className="flex-1 text-start">{t('sidebar_payment')}</span>
          </button>

          {/* 3. Promo */}
          <button onClick={() => handleNav('promo')} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">📢</span><span className="flex-1 text-start">{t('sidebar_promo')}</span>
          </button>

          <div className="mx-5 my-1 h-[1px] bg-gray-800/50" />

          {/* 4. Support */}
          <a href="https://t.me/Visacardnovbv?direct" target="_blank" rel="noopener noreferrer" className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">🎧</span><span className="flex-1 text-start">{t('sidebar_support')}</span>
          </a>

          {/* 5. Orders */}
          <a href="http://t.me/carding2t22?direct" target="_blank" rel="noopener noreferrer" className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">⚡</span><span className="flex-1 text-start">{t('sidebar_order')}</span>
          </a>

          <div className="mx-5 my-1 h-[1px] bg-gray-800/50" />

          {/* 6. Injected Cards */}
          <button onClick={() => { setSidebarOpen(false); setCurrentPage('store'); setTimeout(() => window.dispatchEvent(new CustomEvent('nav-to', { detail: 'cards-novbv' })), 100); }} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">💎</span><span className="flex-1 text-start">{t('sidebar_injected')}</span>
          </button>

          {/* 7. Proxy → directly to proxy products */}
          <button onClick={() => { setSidebarOpen(false); setCurrentPage('store'); setTimeout(() => window.dispatchEvent(new CustomEvent('nav-to', { detail: 'proxy-products' })), 100); }} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">🔒</span><span className="flex-1 text-start">{t('sidebar_proxy')}</span>
          </button>

          <div className="mx-5 my-1 h-[1px] bg-gray-800/50" />

          {/* 8. Share */}
          <button onClick={() => { if (navigator.share) { navigator.share({ title: 'Black Mart', url: window.location.href }); } else { setShowShareOptions(!showShareOptions); } }} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">📤</span><span className="flex-1 text-start">{t('sidebar_share')}</span>
          </button>
          {showShareOptions && (
            <div className="px-5 py-2 space-y-2">
              <div className="flex gap-2">
                <a href={`https://wa.me/?text=${encodeURIComponent('Black Mart ☠️ ' + window.location.href)}`} target="_blank" rel="noopener noreferrer" className="flex-1 py-2 bg-neon-green/10 border border-neon-green/20 rounded text-neon-green text-xs font-bold text-center">WhatsApp</a>
                <a href={`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=Black+Mart`} target="_blank" rel="noopener noreferrer" className="flex-1 py-2 bg-neon-blue/10 border border-neon-blue/20 rounded text-neon-blue text-xs font-bold text-center">Telegram</a>
                <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=Black+Mart`} target="_blank" rel="noopener noreferrer" className="flex-1 py-2 bg-gray-800 border border-gray-700 rounded text-white text-xs font-bold text-center">X</a>
              </div>
              <button onClick={() => navigator.clipboard.writeText(window.location.href)} className="w-full py-2 bg-neon-gold/10 border border-neon-gold/20 rounded text-neon-gold text-xs font-bold">📋 {t('copy_link')}</button>
            </div>
          )}

          {/* 9. Bot - opens inline */}
          <button onClick={() => { setSidebarOpen(false); setCurrentPage('guides'); setTimeout(()=>window.dispatchEvent(new CustomEvent('open-bot')),200); }} className="w-full flex items-center gap-3 px-5 py-3 text-gray-300 hover:bg-neon-blue/5 hover:text-white transition-all text-sm font-bold">
            <span className="text-lg w-7 text-center">🤖</span><span className="flex-1 text-start">{t('sidebar_bot')}</span>
          </button>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-800/30 mt-2">
          {user && (
            <button onClick={handleLogout} className="w-full py-2 bg-neon-red/5 border border-neon-red/10 rounded-lg text-neon-red text-xs font-bold mb-2">
              🚪 {rtl ? 'تسجيل خروج' : 'Logout'}
            </button>
          )}
          <button onClick={() => { window.location.reload(); }} className="w-full py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold mb-2 hover:text-white hover:border-gray-600 transition-all">
            🔄 {rtl ? 'تحديث الموقع' : 'Refresh Site'}
          </button>
          <p className="text-[10px] text-gray-700 text-center" style={{ fontFamily: 'Share Tech Mono, monospace' }}>Black Mart v2.0 — Encrypted</p>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
