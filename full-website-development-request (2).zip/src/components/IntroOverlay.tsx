import React, { useState } from 'react';
import { type Lang, allLangs } from '../i18n';

interface Props {
  onSelectLang: (lang: Lang) => void;
}

const IntroOverlay: React.FC<Props> = ({ onSelectLang }) => {
  const [showMore, setShowMore] = useState(false);

  return (
    <div className="fixed inset-0 z-[10000] bg-black flex flex-col items-center justify-center overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_#00d4ff05_0%,_transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,_#ff004005_0%,_transparent_50%)]" />

      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: 'linear-gradient(#00d4ff 1px, transparent 1px), linear-gradient(90deg, #00d4ff 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }}
      />

      {/* Top neon bar */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-neon-blue to-transparent neon-pulse" />

      {/* Skull */}
      <div className="text-7xl md:text-8xl mb-6 skull-glow relative">
        ☠️
        <div className="absolute inset-0 blur-2xl bg-neon-red/10 rounded-full" />
      </div>

      {/* Logo */}
      <div className="flex items-center gap-3 mb-5 relative">
        <span className="text-4xl md:text-6xl font-black text-neon-blue tracking-[0.2em]" style={{ fontFamily: 'Orbitron, sans-serif' }}>
          Black
        </span>
        <span className="text-4xl md:text-6xl font-black text-white tracking-[0.2em] glitch-text" style={{ fontFamily: 'Orbitron, sans-serif' }}>
          Mart
        </span>
      </div>

      {/* Separator line */}
      <div className="w-32 h-[1px] bg-gradient-to-r from-transparent via-neon-blue/50 to-transparent mb-5" />

      {/* Taglines */}
      <p className="text-gray-300 text-base md:text-lg mb-1 text-center px-4 font-bold">
        كل ما تبحث عنه في الظلام موجود هنا
      </p>
      <p className="text-gray-500 text-xs md:text-sm mb-12 text-center px-4" style={{ fontFamily: 'Share Tech Mono, monospace' }}>
        Everything you seek in the dark is here
      </p>

      {/* Main 3 languages */}
      <div className="flex flex-row gap-3 mb-8 px-4">
        {allLangs.map((l) => (
          <button
            key={l.code}
            onClick={() => onSelectLang(l.code)}
            className="px-5 md:px-8 py-3 md:py-4 bg-transparent border border-neon-blue/40 rounded-xl text-white font-bold text-sm md:text-base hover:bg-neon-blue/10 hover:border-neon-blue hover:shadow-[0_0_20px_#00d4ff33] transition-all duration-300 min-w-[100px] md:min-w-[140px] relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-neon-blue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="relative">{l.name} {l.flag}</span>
          </button>
        ))}
      </div>

      {/* More languages arrow */}
      <button
        onClick={() => setShowMore(!showMore)}
        className="text-neon-blue text-2xl arrow-bounce cursor-pointer mb-4"
      >
        {showMore ? '↑' : '↓'}
      </button>
      <p className="text-gray-600 text-[10px] mb-4">More languages</p>

      {/* Additional languages dropdown */}
      {showMore && (
        <div className="fade-in grid grid-cols-2 md:grid-cols-3 gap-2 max-w-md px-4">
          {[
            { name: 'Français 🇫🇷' },
            { name: 'Español 🇪🇸' },
            { name: 'Deutsch 🇩🇪' },
            { name: 'Türkçe 🇹🇷' },
            { name: '中文 🇨🇳' },
            { name: '日本語 🇯🇵' },
          ].map((l, i) => (
            <button
              key={i}
              onClick={() => onSelectLang('en')}
              className="px-4 py-2 bg-transparent border border-gray-800 rounded-lg text-gray-500 text-sm hover:border-neon-blue/30 hover:text-white transition-all"
            >
              {l.name}
            </button>
          ))}
        </div>
      )}

      {/* Bottom neon bar */}
      <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-neon-blue to-transparent neon-pulse" />

      {/* Side glow effects */}
      <div className="absolute top-1/2 left-0 w-1 h-32 -translate-y-1/2 bg-gradient-to-b from-transparent via-neon-blue/30 to-transparent" />
      <div className="absolute top-1/2 right-0 w-1 h-32 -translate-y-1/2 bg-gradient-to-b from-transparent via-neon-blue/30 to-transparent" />
    </div>
  );
};

export default IntroOverlay;
