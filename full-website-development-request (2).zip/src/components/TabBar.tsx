import React from 'react';
import { useApp } from '../context/AppContext';

const tabs = [
  { id: 'store', icon: '🏪', key: 'store' },
  { id: 'tools', icon: '🛠️', key: 'tools' },
  { id: 'channels', icon: '💳', key: 'channels' },
  { id: 'guides', icon: '📖', key: 'guides' },
];

const TabBar: React.FC = () => {
  const { t, currentPage, setCurrentPage } = useApp();

  return (
    <div className="sticky top-[53px] z-[90]" style={{ background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(15px)', WebkitBackdropFilter: 'blur(15px)' }}>
      <div className="flex">
        {tabs.map((tab) => {
          const isActive = currentPage === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentPage(tab.id)}
              className={`flex-1 py-2.5 text-center text-[13px] font-bold transition-all duration-300 relative ${
                isActive
                  ? 'text-neon-blue'
                  : 'text-gray-600 hover:text-gray-300'
              }`}
            >
              <span className="mr-1">{tab.icon}</span>
              <span>{t(tab.key)}</span>
              {isActive && (
                <div className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-neon-blue rounded-full shadow-[0_0_8px_#00d4ff66]" />
              )}
            </button>
          );
        })}
      </div>
      <div className="h-[1px] bg-gradient-to-r from-transparent via-gray-800/30 to-transparent" />
    </div>
  );
};

export default TabBar;
