import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const fakeReviews = [
  { name: 'M***d', stars: 5, ar: 'بطاقة ممتازة اشتغلت من أول مرة. خدمة سريعة جداً', en: 'Excellent card, worked first time. Very fast service', ru: 'Отличная карта, сработала с первого раза' },
  { name: 'A***r', stars: 5, ar: 'أفضل متجر تعاملت معه. الشروحات واضحة والدعم ممتاز', en: 'Best store I dealt with. Clear tutorials and great support', ru: 'Лучший магазин. Понятные инструкции и отличная поддержка' },
  { name: 'K***n', stars: 4, ar: 'البروكسي شغال بشكل مثالي. أنصح فيه بقوة', en: 'Proxy works perfectly. Highly recommended', ru: 'Прокси работает идеально. Очень рекомендую' },
  { name: 'S***a', stars: 5, ar: 'حساب PayPal محقون برصيد حقيقي. تم التحويل بنجاح', en: 'Injected PayPal with real balance. Transfer successful', ru: 'PayPal с реальным балансом. Перевод успешен' },
  { name: 'R***k', stars: 5, ar: 'الكورس الشامل غير حياتي. محتوى احترافي 100%', en: 'The comprehensive course changed my life. 100% professional', ru: 'Курс изменил мою жизнь. 100% профессионально' },
  { name: 'D***x', stars: 4, ar: 'شحن TikTok وصل خلال دقائق. سرعة خيالية', en: 'TikTok top-up arrived in minutes. Incredible speed', ru: 'Пополнение TikTok пришло за минуты. Невероятная скорость' },
  { name: 'F***l', stars: 5, ar: 'بطاقات الهدايا شغالة 100%. أكواد حقيقية', en: 'Gift cards 100% working. Real codes', ru: 'Подарочные карты работают 100%. Реальные коды' },
  { name: 'T***r', stars: 5, ar: 'تحويل SWIFT وصل لحسابي خلال ساعة. مذهل', en: 'SWIFT transfer arrived in 1 hour. Amazing', ru: 'SWIFT перевод пришёл за час. Потрясающе' },
  { name: 'N***o', stars: 4, ar: 'أدوات التفريغ قوية جداً. شكراً للفريق', en: 'Extraction tools are very powerful. Thanks team', ru: 'Инструменты очень мощные. Спасибо команде' },
  { name: 'B***z', stars: 5, ar: 'خدمة عملاء على مدار الساعة. رد سريع واحترافي', en: '24/7 customer service. Fast and professional response', ru: 'Поддержка 24/7. Быстрый профессиональный ответ' },
];

const Reviews: React.FC = () => {
  const { lang, rtl } = useApp();
  const L = (lang==='ar'?'ar':lang==='ru'?'ru':'en') as 'ar'|'en'|'ru';
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  const isLoggedIn = !!localStorage.getItem('bm_user_data');

  const title = L==='ar'?'تقييمات العملاء':L==='ru'?'Отзывы клиентов':'Customer Reviews';
  const writeBtn = L==='ar'?'✍️ اكتب تقييم':L==='ru'?'✍️ Написать отзыв':'✍️ Write Review';
  const loginMsg = L==='ar'?'يرجى تسجيل الدخول أولاً لكتابة تقييم':L==='ru'?'Войдите, чтобы написать отзыв':'Please login first to write a review';
  const submitBtn = L==='ar'?'إرسال التقييم':L==='ru'?'Отправить':'Submit Review';
  const successMsg = L==='ar'?'✅ شكراً لتقييمك! سيتم التأكد من تقييمك وبعدها يتم تحريره وعرضه للعامة.':L==='ru'?'✅ Спасибо за отзыв! Он будет проверен и опубликован.':'✅ Thank you! Your review will be verified and published publicly.';
  const placeholder = L==='ar'?'اكتب تقييمك هنا...':L==='ru'?'Напишите отзыв...':'Write your review...';
  const verified = L==='ar'?'عميل موثق':L==='ru'?'Проверенный':'Verified';

  const handleSubmit = () => {
    if (!text.trim()) return;
    setSubmitted(true);
    setText('');
    setShowForm(false);
  };

  return (
    <div className="px-4 mt-6 mb-6" style={{direction:rtl?'rtl':'ltr'}}>
      <div className="rounded-xl bg-dark-card border border-neon-blue/10 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-black text-neon-blue">⭐ {title}</h3>
          <div className="flex items-center gap-1">
            <span className="text-neon-gold text-xs">⭐⭐⭐⭐⭐</span>
            <span className="text-[10px] text-gray-500">(4.9)</span>
          </div>
        </div>

        {/* Reviews list */}
        <div className="space-y-2.5 mb-4 max-h-64 overflow-y-auto">
          {fakeReviews.map((r, i) => (
            <div key={i} className="rounded-lg bg-dark-surface border border-gray-800/30 p-3">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-neon-blue/10 flex items-center justify-center text-[10px]">👤</div>
                  <span className="text-[10px] font-bold text-white">{r.name}</span>
                  <span className="text-[8px] px-1.5 py-0.5 bg-neon-green/10 border border-neon-green/20 rounded-full text-neon-green">✓ {verified}</span>
                </div>
                <div className="text-[9px] text-neon-gold">{'⭐'.repeat(r.stars)}</div>
              </div>
              <p className="text-[10px] text-gray-400 leading-[1.6]">{r[L]}</p>
            </div>
          ))}
        </div>

        {/* Write review button */}
        {!showForm && !submitted && (
          <button onClick={() => setShowForm(true)} className="w-full py-2.5 bg-neon-blue/8 border border-neon-blue/15 rounded-xl text-neon-blue text-xs font-bold">{writeBtn}</button>
        )}

        {/* Review form */}
        {showForm && (
          <div className="rounded-lg bg-dark-surface border border-neon-blue/10 p-3">
            {!isLoggedIn ? (
              <div className="text-center py-3">
                <p className="text-[11px] text-neon-red mb-2">🔒 {loginMsg}</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-1 mb-2">
                  {[1,2,3,4,5].map(s => (
                    <button key={s} onClick={() => setRating(s)} className={`text-lg ${s <= rating ? 'text-neon-gold' : 'text-gray-700'}`}>⭐</button>
                  ))}
                </div>
                <textarea value={text} onChange={e => setText(e.target.value)} rows={3} placeholder={placeholder} className="w-full bg-dark-card border border-gray-700 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 outline-none focus:border-neon-blue/40 resize-none mb-2" />
                <button onClick={handleSubmit} disabled={!text.trim()} className="w-full py-2 bg-neon-blue/15 border border-neon-blue/30 rounded-lg text-neon-blue text-xs font-bold disabled:opacity-40">{submitBtn}</button>
              </>
            )}
            <button onClick={() => setShowForm(false)} className="w-full mt-1 py-1.5 text-gray-600 text-[9px]">{L==='ar'?'إغلاق':L==='ru'?'Закрыть':'Close'}</button>
          </div>
        )}

        {/* Success message */}
        {submitted && (
          <div className="rounded-lg bg-neon-green/5 border border-neon-green/15 p-3 text-center">
            <p className="text-[11px] text-neon-green font-bold">{successMsg}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reviews;
