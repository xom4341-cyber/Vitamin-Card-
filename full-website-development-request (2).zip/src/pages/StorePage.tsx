import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import { showCartToast } from '../utils/cartToast';
import { showSectionBanner } from '../utils/sectionBanner';
import { storeCategories } from '../data/products';
import { cardSubCategories, getCardProducts, type StoreProduct } from '../data/storeProducts';
import { transferSubCategories, getTransferProducts, walletFields } from '../data/transferProducts';
import { topupSections, visualPackages, audioApps, topupWarning } from '../data/topupProducts';
import { giftSubCategories, getGiftProducts } from '../data/giftProducts';
import { proxySubCategories, getProxyProducts, proxyDurations, d2Quantities } from '../data/proxyProducts';
import { accountSubCategories, getAccountProducts } from '../data/accountsProducts';

// TG moved to buyModal.ts

const StorePage: React.FC = () => {
  const { t, lang, rtl, addToCart, cartCount, setPaymentModalOpen, setCurrentPage } = useApp();
  const [showExplanation, setShowExplanation] = useState(false);

  // Show section banner once
  useEffect(() => { showSectionBanner(lang); }, []);

  // Listen for navigation events from sidebar
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail === 'cards-novbv') { setActiveCat('cards'); setActiveSub('novbv'); }
      if (detail === 'proxy') { setActiveCat('proxy'); setActiveSub(null); }
      if (detail === 'proxy-products') { setActiveCat('proxy'); setActiveSub('proxy'); }
      if (detail === 'accounts') { setActiveCat('accounts'); setActiveSub(null); }
    };
    window.addEventListener('nav-to', handler);
    return () => window.removeEventListener('nav-to', handler);
  }, []);
  const [activeCat, setActiveCat] = useState<string|null>(null);
  const [activeSub, setActiveSub] = useState<string|null>(null);
  // detail state removed - inline details used instead
  const [cardsFilter, setCardsFilter] = useState<'all'|'injected'|'pulled'>('all');
  const [showCardsDiff, setShowCardsDiff] = useState(false);
  const [buyingId, setBuyingId] = useState<string|null>(null);
  const [productFilter, setProductFilter] = useState<'all'|'big'|'bundle'>('all');
  const [expandedDetail, setExpandedDetail] = useState<string|null>(null);
  // Slideshow state (must be at top level with all hooks)
  const [slideIdx, setSlideIdx] = useState(0);
  const [nameGlow, setNameGlow] = useState(true);
  useEffect(() => {
    const t1 = setInterval(() => setSlideIdx(p => (p + 1) % 6), 5000);
    const t2 = setInterval(() => setNameGlow(p => !p), 2000);
    return () => { clearInterval(t1); clearInterval(t2); };
  }, []);
  // Transfer custom order
  // showCustomOrder removed - always visible
  const [customWallet, setCustomWallet] = useState('PayPal');
  const [customAmount, setCustomAmount] = useState('');
  const [customFields, setCustomFields] = useState<Record<string,string>>({});
  const [bankFields, setBankFields] = useState<Record<string,string>>({});
  const [flashPlatform, setFlashPlatform] = useState('');
  const [flashNetwork, setFlashNetwork] = useState('');
  const [flashAddr, setFlashAddr] = useState('');
  // Topup state
  const [topupApp, setTopupApp] = useState('');
  const [topupPkg, setTopupPkg] = useState('');
  const [topupUser, setTopupUser] = useState('');
  const [topupPass, setTopupPass] = useState('');
  const [topupCustomQty, setTopupCustomQty] = useState('');
  const [topupId, setTopupId] = useState('');
  // showTopupTool removed - always visible
  const [showTopupWarn, setShowTopupWarn] = useState(false);
  const [selVisualApp, setSelVisualApp] = useState('TikTok');
  const L = lang==='ar'?'ar':'en';

  const payInfo = lang==='ru'
    ? `\n📝 Оплата:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nПосле оплаты отправьте подтверждение.`
    : lang==='en'
    ? `\n📝 Payment:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nAfter payment send proof and delivery will be automatic.`
    : `\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.`;

  const ol = lang==='ru'?'Новый заказ':lang==='en'?'New Order':'طلب شراء جديد';
  const buildMsg = (p: StoreProduct) => {
    const c = p.category; const s = p.subCategory;
    const n = p.name; const b = p.balance; const pr = p.price;
    let type=''; let detail='';
    if (lang==='ru') {
      if(c==='cards'){type=s==='novbv'||s==='amex-inj'?'💳 Инъектированная карта':s==='paypal-inj'?'💰 Инъектированный аккаунт':'💳 Извлечённая карта';detail=`Карта: ${n}\nБаланс: ${b}\nЦена: ${pr}$`;}
      else if(c==='transfer'){type='💸 Перевод';detail=`Перевод: ${n}\nСумма: ${b}\nЦена: ${pr}$`;}
      else if(c==='accounts'){type='👤 Аккаунт';detail=`Аккаунт: ${n}\nТип: ${b}\nЦена: ${pr}$`;}
      else if(c==='gifts'){type='🎁 Подарочная карта';detail=`Карта: ${n}\nБаланс: ${b}\nЦена: ${pr}$`;}
      else if(c==='proxy'){type=s==='academy'?'🎓 Курс':s==='d2'?'🔗 Пакет D2':s==='elite'?'🛠️ Услуга':s==='ai'?'🤖 ИИ':'🔒 Прокси';detail=`Услуга: ${n}\nЦена: ${pr}$`;}
      else{type='📦 Услуга';detail=`Услуга: ${n}\nЦена: ${pr}$`;}
    } else if (lang==='en') {
      if(c==='cards'){type=s==='novbv'||s==='amex-inj'?'💳 Injected Card':s==='paypal-inj'?'💰 Injected Account':'💳 Pulled Card';detail=`Card: ${n}\nBalance: ${b}\nPrice: ${pr}$`;}
      else if(c==='transfer'){type='💸 Transfer';detail=`Transfer: ${n}\nAmount: ${b}\nPrice: ${pr}$`;}
      else if(c==='accounts'){type='👤 Account';detail=`Account: ${n}\nType: ${b}\nPrice: ${pr}$`;}
      else if(c==='gifts'){type='🎁 Gift Card';detail=`Card: ${n}\nBalance: ${b}\nPrice: ${pr}$`;}
      else if(c==='proxy'){type=s==='academy'?'🎓 Course':s==='d2'?'🔗 D2 Package':s==='elite'?'🛠️ Service':s==='ai'?'🤖 AI':'🔒 Proxy';detail=`Service: ${n}\nPrice: ${pr}$`;}
      else{type='📦 Service';detail=`Service: ${n}\nPrice: ${pr}$`;}
    } else {
      if(c==='cards'){type=s==='novbv'||s==='amex-inj'?'💳 بطاقة محقونة':s==='paypal-inj'?'💰 حساب محقون':'💳 بطاقة مسحوبة';detail=`البطاقة: ${n}\nالرصيد: ${b}\nالسعر: ${pr}$`;}
      else if(c==='transfer'){type='💸 تحويل';detail=`التحويل: ${n}\nالمبلغ: ${b}\nالسعر: ${pr}$`;}
      else if(c==='accounts'){type='👤 حساب مستعار';detail=`الحساب: ${n}\nالنوع: ${b}\nالسعر: ${pr}$`;}
      else if(c==='gifts'){type='🎁 بطاقة هدايا';detail=`البطاقة: ${n}\nالرصيد: ${b}\nالسعر: ${pr}$`;}
      else if(c==='proxy'){type=s==='academy'?'🎓 كورس':s==='d2'?'🔗 حزمة D2':s==='elite'?'🛠️ خدمة':s==='ai'?'🤖 ذكاء اصطناعي':'🔒 بروكسي';detail=`الخدمة: ${n}\nالسعر: ${pr}$`;}
      else{type='📦 خدمة';detail=`الخدمة: ${n}\nالسعر: ${pr}$`;}
    }
    return `[🚨 ${ol} - BLACK MART]\n--------------------------------------\n${type}\n${detail}\n--------------------------------------${payInfo}\n--------------------------------------\n[SYSTEM_ID: AUTO]`;
  };

  const handleBuy = (p: StoreProduct) => {
    setBuyingId(p.id);
    const msg = buildMsg(p);
    setBuyingId(null);
    showBuyModal(lang, msg);
  };

  const handleAddCart = (p: StoreProduct) => {
    addToCart({id:p.id,name:p.name,price:p.price,oldPrice:p.oldPrice,balance:p.balance,image:p.image,category:p.category});
    showCartToast(lang, cartCount + 1);
  };

  // renderDetails removed - using SectionDetailsBox instead

  // State for showing section details
  const [showSectionDetails, setShowSectionDetails] = useState(false);

  // Product Card component with dropdown details
  const ProductCard = ({p}:{p:StoreProduct}) => {
    const isOpen = expandedDetail === p.id;
    const detailLines = (p.details[L]||'').replace(/\\n/g,'\n').split('\n');
    return (
    <div className="rounded-xl bg-dark-card overflow-hidden card-hover group" style={{border:'1px solid #00d4ff12'}}>
      <div className="relative"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-blue z-10"/><div className="aspect-[3/2] overflow-hidden"><img src={p.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/></div><div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/>{p.isBundle&&<span className="absolute top-3 right-2 px-1.5 py-0.5 bg-neon-gold/20 border border-neon-gold/40 rounded text-[8px] text-neon-gold font-bold z-10">BUNDLE</span>}</div>
      <div className="p-2.5">
        <h4 className="text-[11px] font-black text-white mb-0.5 group-hover:text-neon-blue transition-colors truncate">{p.name}</h4>
        <p className="text-[9px] text-gray-500 mb-1 line-clamp-2 leading-[1.5]">{p.desc[L]}</p>
        <div className="text-[9px] text-neon-green font-bold mb-0.5">🟢 {p.balance}</div>
        <div className="flex items-center gap-1.5 mb-2"><span className="text-[9px] text-neon-red line-through">${p.oldPrice}</span><span className="text-sm text-neon-green font-black">${p.price}</span></div>
        <div className="flex gap-1">
          <button onClick={(e)=>{e.stopPropagation();setExpandedDetail(isOpen?null:p.id);}} className="flex-1 py-1.5 text-[9px] font-bold bg-gray-800 text-gray-300 rounded hover:bg-gray-700">{isOpen?'✕':'ℹ️'} {rtl?'تفاصيل':'Details'}</button>
          <button onClick={(e)=>{e.stopPropagation();handleAddCart(p);}} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-blue/10 border border-neon-blue/20 text-neon-blue rounded">🛒</button>
          <button onClick={(e)=>{e.stopPropagation();handleBuy(p);}} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-red/10 border border-neon-red/20 text-neon-red rounded">{buyingId===p.id?'⏳':rtl?'شراء':'Buy'}</button>
        </div>
        {/* Dropdown details */}
        {isOpen && (
          <div className="mt-2 rounded-lg bg-dark-surface border border-neon-blue/10 p-2.5">
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {detailLines.map((l,i)=>{if(!l.trim())return<div key={i} className="h-1.5"/>;const tr=l.trim();const isBullet=/^[•\-▸]/.test(tr);const isHead=/^\[|^🔹|^🔒|^💳|^👤|^📍|^🖥|^📦|^⚠/.test(tr);const blur=/\*{3,}/.test(tr);if(isHead)return<h4 key={i} className="text-[9px] font-black text-neon-blue mt-1.5 pt-1 border-t border-gray-800/30">{tr}</h4>;if(isBullet)return<div key={i} className="flex items-start gap-1.5 text-[9px] text-gray-400 leading-[1.6]"><span className="text-neon-blue text-[8px]">▸</span><span className={blur?'blur-[2px] select-none':''}>{tr.replace(/^[•\-▸]\s*/,'')}</span></div>;return<p key={i} className={`text-[9px] leading-[1.6] ${blur?'text-gray-600 blur-[2px]':'text-gray-400'}`}>{tr}</p>;})}
            </div>
            <button onClick={(e)=>{e.stopPropagation();setExpandedDetail(null);}} className="w-full mt-2 py-1.5 bg-gray-800 rounded text-gray-500 text-[8px] font-bold">✕ {rtl?'إغلاق':'Close'}</button>
          </div>
        )}
      </div>
    </div>
    );
  };

  // Section Details Box (shows below products)
  const SectionDetailsBox = ({detailText}:{detailText:string}) => {
    const lines = detailText.replace(/\\n/g, '\n').split('\n');
    return (
      <div className="px-4 mt-4">
        <button onClick={()=>setShowSectionDetails(!showSectionDetails)} className="w-full py-2.5 rounded-xl bg-dark-card border border-neon-blue/15 text-neon-blue text-xs font-bold">
          {showSectionDetails ? (rtl?'✕ إغلاق التفاصيل':'✕ Close Details') : (rtl?'📋 عرض التفاصيل':'📋 Show Details')}
        </button>
        {showSectionDetails && (
          <div className="mt-3 space-y-2">
            {lines.map((line,i) => {
              if (!line.trim()) return <div key={i} className="h-2" />;
              const tr = line.trim();
              const isBullet = /^[•\-▸]/.test(tr);
              const isHead = /^\[|^🔹|^🔒|^🛡|^💳|^👤|^📍|^🖥|^🏦|^💎|^⚠|^📦|^📜/.test(tr);
              const hasBlur = /\*{3,}|XXXX/.test(tr);
              const hc = tr.includes('⚠')?'#ff0040':tr.includes('🔒')||tr.includes('🛡')?'#00ff88':tr.includes('💳')||tr.includes('🔹')?'#00d4ff':tr.includes('👤')?'#aa44ff':tr.includes('📍')?'#44cc44':tr.includes('🖥')?'#ff8844':'#ffd700';
              if (isHead) return (
                <div key={i} className="rounded-xl bg-dark-card p-3 mt-2" style={{border:`1px solid ${hc}20`}}>
                  <div className="h-[2px] rounded-full mb-2" style={{background:`${hc}40`}} />
                  <h4 className="text-[11px] font-black" style={{color:hc}}>{tr}</h4>
                </div>
              );
              if (isBullet) return (
                <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-dark-surface border border-gray-800/20 mx-1">
                  <span className="text-neon-blue mt-0.5 text-[10px] flex-shrink-0">▸</span>
                  <span className={`text-[11px] leading-[1.7] ${hasBlur?'text-gray-600 blur-[3px] select-none':'text-gray-400'}`}>{tr.replace(/^[•\-▸]\s*/,'')}</span>
                  {hasBlur && <span className="text-[8px] text-neon-red/50 flex-shrink-0">🔒</span>}
                </div>
              );
              return <p key={i} className={`text-[11px] leading-[1.7] px-1 ${hasBlur?'text-gray-600 blur-[3px] select-none':'text-gray-300'}`}>{tr}</p>;
            })}
            {/* Close button at bottom */}
            <button onClick={()=>setShowSectionDetails(false)} className="w-full py-2 mt-2 bg-dark-surface border border-gray-800 rounded-xl text-gray-500 text-[10px] font-bold">
              ✕ {rtl?'إغلاق التفاصيل':'Close Details'}
            </button>
          </div>
        )}
      </div>
    );
  };

  // ===== TRANSFER SECTION =====
  if (activeCat === 'transfer') {
    if (activeSub) {
      const products = getTransferProducts(activeSub);
      const subInfo = transferSubCategories.find(s=>s.id===activeSub);
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          {/* Quick nav */}
          <div className="px-4 pt-3 flex gap-1 overflow-x-auto pb-1">{transferSubCategories.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-2.5 py-1.5 rounded text-[9px] font-bold ${activeSub===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.shortName}</button>)}</div>
          <div className="px-4 pt-2 flex justify-between items-center"><button onClick={()=>setActiveSub(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
          {/* Products */}
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>
          {products[0] && <SectionDetailsBox detailText={products[0].details[L]} />}
          {/* Bank Wire Policy - only for bank-wire sub */}
          {activeSub==='bank-wire'&&(
            <div className="px-4 mt-3">
              <button onClick={()=>setShowCardsDiff(!showCardsDiff)} className="w-full py-2.5 rounded-xl bg-black border border-neon-gold/20 text-neon-gold text-xs font-bold">
                {showCardsDiff?(rtl?'✕ إغلاق سياسة الصفقات':'✕ Close Policy'):(rtl?'🛡️ عرض سياسة الصفقات':'🛡️ Show Transaction Policy')}
              </button>
              {showCardsDiff&&(
                <div className="mt-3 space-y-2">
                  <div className="rounded-xl bg-dark-card p-3.5" style={{border:'1px solid #ffd70015'}}>
                    <div className="h-[2px] bg-neon-gold/40 rounded mb-3"/>
                    <h4 className="text-xs font-black text-neon-gold mb-2">🛡️ {rtl?'سياسة الصفقات (Transaction Policy)':'Transaction Policy'}</h4>
                    <div className="space-y-2">
                      <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/20">
                        <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl?'1. العمليات الرقمية:':'1. Digital Operations:'}</p>
                        <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl?'تنفذ جميع الصفقات (أقل من 2,000$) رقمياً بالكامل عبر قنواتنا الرسمية بسرعة فائقة وبكل سرية.':'All transactions under $2,000 are executed fully digitally via our official channels with speed and secrecy.'}</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/20">
                        <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl?'2. المقابلات الشخصية (2,000$+):':'2. Personal Meetings ($2,000+):'}</p>
                        <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl?'• شرط الأهلية: متاحة فقط للصفقات 2,000$ فما فوق\n• إثبات الملاءة: تصوير فيديو يظهر محفظتك الرقمية\n• التنسيق المسبق: حجز مسبق مع المسؤول المعتمد':'• Eligibility: Available only for $2,000+ deals\n• Proof of funds: Video showing your digital wallet\n• Prior coordination: Advance booking with certified manager'}</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/20">
                        <p className="text-[10px] text-neon-green font-bold mb-1">{rtl?'🌍 الدول المتوفرة للمقابلة:':'🌍 Available Meeting Locations:'}</p>
                        <div className="flex flex-wrap gap-1.5 mt-1">{[rtl?'🇸🇦 السعودية: جدة':'🇸🇦 Saudi: Jeddah',rtl?'🇺🇸 أمريكا: تكساس':'🇺🇸 USA: Texas',rtl?'🇷🇺 روسيا: موسكو':'🇷🇺 Russia: Moscow',rtl?'🇩🇪 ألمانيا: برلين':'🇩🇪 Germany: Berlin'].map((c,i)=><span key={i} className="px-2 py-1 bg-dark-card rounded text-[9px] text-gray-400 border border-gray-800">{c}</span>)}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/20">
                        <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl?'3. بروتوكول التسليم:':'3. Delivery Protocol:'}</p>
                        <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl?'• يلتقي بك مندوبنا المعتمد\n• تحويل رسوم الخدمة للمحفظة المحددة\n• فور التأكيد يتم تحويل المبلغ لحسابك\n• ضمان: لا يغادر المندوب إلا بعد تأكدك من وصول المبلغ':'• Our certified agent meets you\n• Transfer service fee to specified wallet\n• Upon confirmation, amount transferred to your account\n• Guarantee: Agent stays until you confirm receipt'}</p>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-xl bg-dark-card p-3" style={{border:'1px solid #00d4ff15'}}>
                    <h4 className="text-[10px] font-black text-neon-blue mb-1">📜 {rtl?'بروتوكول التحويل البنكي الآمن:':'Safe Bank Transfer Protocol:'}</h4>
                    <div className="space-y-1">{(rtl?['التغطية: متاح لكافة البنوك (الخليجية، الأوروبية، والأمريكية)','السرية: نظام طبقات متعددة لإخفاء مصدر التحويل','الضمان: حوالة بديلة فورية في حال الرفض بدون رسوم إضافية']:['Coverage: Available for all banks (Gulf, European, American)','Secrecy: Multi-layer system to hide transfer source','Guarantee: Instant alternative transfer if rejected, no extra fees']).map((t2,i)=><div key={i} className="flex items-start gap-2 text-[10px] text-gray-400 p-1"><span className="text-neon-green">✓</span>{t2}</div>)}</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-neon-red/5 border border-neon-red/15">
                    <p className="text-[9px] text-neon-red leading-[1.7]">{rtl?'⚠️ إخلاء مسؤولية: نحن مسؤولون عن إيصال الأموال لحسابك فقط. أي إجراءات لاحقة تتعلق بطرق صرف الأموال أو غسيلها تقع تحت مسؤوليتك الشخصية والكاملة.':'⚠️ Disclaimer: We are responsible only for delivering funds to your account. Any subsequent actions regarding spending or laundering are your full personal responsibility.'}</p>
                  </div>
                  <button onClick={()=>setShowCardsDiff(false)} className="w-full py-2 bg-dark-surface border border-gray-800 rounded-xl text-gray-500 text-[10px] font-bold">✕ {rtl?'إغلاق':'Close'}</button>
                </div>
              )}
            </div>
          )}
          {/* Custom order section for specific subcategories */}
          {(activeSub==='paypal-inject'||activeSub==='bank-wire'||activeSub==='flash-usdt'||activeSub==='amex-inject')&&(
            <div className="px-4 mt-4">
              {true&&(
                <div className="mt-3 rounded-xl bg-dark-card p-4 fade-in" style={{border:'1px solid #00d4ff15'}}>
                  <h4 className="text-xs font-black text-neon-blue mb-3">{rtl?'طلب كمية مخصصة':'Custom Amount Order'}</h4>
                  {/* E-wallet selector */}
                  {activeSub==='paypal-inject'&&(
                    <div className="mb-3"><label className="text-[10px] text-gray-500 block mb-1">{rtl?'اختر المحفظة':'Select Wallet'}</label><select value={customWallet} onChange={e=>setCustomWallet(e.target.value)} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none">{['PayPal','Payoneer','Payer','Neteller','Skrill','CashApp','Wise','Revolut','Perfect Money'].map(w=><option key={w} value={w}>{w}</option>)}</select></div>
                  )}
                  {/* Amount */}
                  <div className="mb-2"><label className="text-[10px] text-gray-500 block mb-1">{rtl?'الكمية (أدنى 1000)':'Amount (min 1000)'}</label><input type="number" value={customAmount} onChange={e=>setCustomAmount(e.target.value)} placeholder="1000" min="1000" className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/></div>
                  {customAmount&&Number(customAmount)>=1000&&<p className="text-neon-green text-xs font-bold mb-3">{rtl?'السعر:':'Price:'} ${activeSub==='flash-usdt'?Number(customAmount)/20:activeSub==='amex-inject'?Number(customAmount)*0.13:Number(customAmount)*0.15}</p>}
                  {Number(customAmount)>0&&Number(customAmount)<1000&&<p className="text-neon-red text-[10px] mb-2">{rtl?'⚠️ الحد الأدنى 1000':'⚠️ Minimum is 1000'}</p>}
                  {/* Flash fields */}
                  {activeSub==='flash-usdt'&&Number(customAmount)>=1000&&(
                    <div className="space-y-2 mb-3">
                      <select value={flashPlatform} onChange={e=>setFlashPlatform(e.target.value)} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر المنصة':'Select Platform'}</option><option>Binance Wallet Exchange</option><option>Trust Wallet</option></select>
                      <select value={flashNetwork} onChange={e=>setFlashNetwork(e.target.value)} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر الشبكة':'Select Network'}</option><option>BEP20 Binance Chain</option><option>TRC20 Tron Network</option></select>
                      <input value={flashAddr} onChange={e=>setFlashAddr(e.target.value)} placeholder={rtl?'عنوان محفظة الاستلام':'Receiving wallet address'} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                    </div>
                  )}
                  {/* Bank wire fields */}
                  {activeSub==='bank-wire'&&Number(customAmount)>=1000&&(
                    <div className="space-y-2 mb-3">{['Account Name','SWIFT/BIC','IBAN','Bank Name & Address'].map(f=><input key={f} value={bankFields[f]||''} onChange={e=>setBankFields({...bankFields,[f]:e.target.value})} placeholder={f} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>)}</div>
                  )}
                  {/* E-wallet fields */}
                  {activeSub==='paypal-inject'&&Number(customAmount)>=1000&&walletFields[customWallet]&&(
                    <div className="space-y-2 mb-3">{walletFields[customWallet].map(f=><input key={f.label} value={customFields[f.label]||''} onChange={e=>setCustomFields({...customFields,[f.label]:e.target.value})} placeholder={f.label+(f.required?' *':'')} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>)}</div>
                  )}
                  {/* AMEX inject fields */}
                  {activeSub==='amex-inject'&&Number(customAmount)>=1000&&(
                    <div className="space-y-2 mb-3">{['Cardholder Name','Card Number (CC)','Expiry + CID','Billing Address'].map(f=><input key={f} value={customFields[f]||''} onChange={e=>setCustomFields({...customFields,[f]:e.target.value})} placeholder={f} className="w-full bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>)}</div>
                  )}
                  {/* Submit */}
                  <button onClick={()=>{
                    const amt = Number(customAmount);
                    if(amt<1000)return;
                    let msg = `طلب مخصص - BLACK MART\nالقسم: ${subInfo?.name[L]}\nالكمية: ${amt}\nالسعر: $${activeSub==='flash-usdt'?amt/20:activeSub==='amex-inject'?Math.round(amt*0.13):Math.round(amt*0.15)}\n`;
                    if(activeSub==='paypal-inject')msg+=`المحفظة: ${customWallet}\n${Object.entries(customFields).map(([k,v])=>`${k}: ${v}`).join('\n')}\n`;
                    if(activeSub==='bank-wire')msg+=Object.entries(bankFields).map(([k,v])=>`${k}: ${v}`).join('\n')+'\n';
                    if(activeSub==='flash-usdt')msg+=`المنصة: ${flashPlatform}\nالشبكة: ${flashNetwork}\nالعنوان: ${flashAddr}\n`;
                    if(activeSub==='amex-inject')msg+=Object.entries(customFields).map(([k,v])=>`${k}: ${v}`).join('\n')+'\n';
                    msg+=lang==='ru'?'Предоставьте детали и кошелёк.':lang==='en'?'Please provide details and wallet.':'زودني بالتفاصيل ومحفظة الدفع.';
                    showBuyModal(lang,msg);
                  }} className="w-full py-2.5 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg text-xs">{rtl?'تأكيد وشراء ⚡':'Confirm & Buy ⚡'}</button>
                </div>
              )}
            </div>
          )}
        </div>
      );
    }
    // Transfer sub-categories
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3 flex justify-between items-center"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {transferSubCategories.map(sub=>(
            <div key={sub.id} onClick={()=>setActiveSub(sub.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:`1px solid ${sub.color}15`}}>
              <div className="relative h-20 md:h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px]" style={{background:sub.color}}/><img src={sub.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-lg">{sub.icon}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-1">{sub.name[L]}</h4><div className="h-[2px] w-full rounded mb-2" style={{background:`${sub.color}30`}}/><button className="w-full py-1.5 rounded text-[9px] font-bold" style={{background:`${sub.color}08`,color:sub.color,border:`1px solid ${sub.color}20`}}>{t('enter')} →</button></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ===== ACCOUNTS SECTION =====
  if (activeCat === 'accounts') {
    if (activeSub) {
      const products = getAccountProducts(activeSub);
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1 overflow-x-auto pb-1">{accountSubCategories.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-2.5 py-1.5 rounded text-[9px] font-bold ${activeSub===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.shortName}</button>)}</div>
          <div className="px-4 pt-2 flex justify-between items-center"><button onClick={()=>setActiveSub(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>
          {products[0]&&<SectionDetailsBox detailText={products[0].details[L]}/>}
        </div>
      );
    }
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {accountSubCategories.map(sub=>(
            <div key={sub.id} onClick={()=>setActiveSub(sub.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:`1px solid ${sub.color}15`}}>
              <div className="relative h-20 md:h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px]" style={{background:sub.color}}/><img src={sub.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onError={e=>{(e.target as HTMLImageElement).style.display='none';}}/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-lg">{sub.icon}</span><span className="absolute bottom-2 right-2 text-[9px] text-gray-400">{getAccountProducts(sub.id).length}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-1">{sub.name}</h4><div className="h-[2px] w-full rounded mb-2" style={{background:`${sub.color}30`}}/><button className="w-full py-1.5 rounded text-[9px] font-bold" style={{background:`${sub.color}08`,color:sub.color,border:`1px solid ${sub.color}20`}}>{t('enter')} →</button></div>
            </div>
          ))}
        </div>
        {/* Accounts explanation */}
        <div className="px-4 mt-4">
          <div className="rounded-xl bg-black border border-neon-blue/20 overflow-hidden">
            <div className="h-[3px] bg-neon-blue"/>
            <div className="p-3.5">
              <h4 className="text-xs font-black text-neon-blue mb-2">👤 {rtl?'الحسابات المستعارة':'Alias Accounts'}</h4>
              <p className="text-[10px] text-gray-400 leading-[1.7] mb-2">{rtl?'الخصوصية المطلقة للعمليات الحساسة.':'Absolute privacy for sensitive operations.'}</p>
              <div className="space-y-1.5">
                {(rtl?[
                  'جوهر الخدمة: حسابات أُنشئت بهويات "مصنعة" (Synthetic) وليست مسروقة، تتضمن بصمة رقمية متكاملة (IP، سجل تاريخي، وعنوان مطابقة) لتجاوز أنظمة البنوك والمتاجر.',
                  'لماذا هي الخيار الأضمن؟: تمنحك فصلاً تاماً عن هويتك الحقيقية وتاريخك الرقمي، مع ضمان "الاستمرارية" لعدم وجود طرف متضرر يمكنه تقديم بلاغ.',
                  'جاهزية الاستلام: تستلم "كتيب الهوية" (Identity Dossier) كاملاً مع الحساب، مما يجعل الشخصية المستعارة موثوقة بالكامل وجاهزة للاستخدام الفوري.',
                  'الحسابات المستعارة ليست مجرد حسابات، هي درعك القانوني والتقني في المشاريع الحساسة.',
                ]:[
                  'Core service: Accounts created with "synthetic" identities (not stolen), including complete digital fingerprint (IP, history, matching address) to bypass bank and store systems.',
                  'Why the safest choice?: Complete separation from your real identity and digital history, with guaranteed "continuity" as there is no damaged party to file a report.',
                  'Ready to receive: You receive a complete "Identity Dossier" with the account, making the alias fully trusted and ready for immediate use.',
                  'Alias accounts are not just accounts — they are your legal and technical shield for sensitive projects.',
                ]).map((txt,i)=>(
                  <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-dark-surface border border-gray-800/20">
                    <span className="text-neon-blue mt-0.5 text-[10px]">▸</span>
                    <span className="text-[10px] text-gray-400 leading-[1.7]">{txt}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ===== PROXY SECTION =====
  if (activeCat === 'proxy') {
    if (activeSub) {
      const products = getProxyProducts(activeSub);
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1 overflow-x-auto pb-1">{proxySubCategories.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-2.5 py-1.5 rounded text-[9px] font-bold ${activeSub===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.shortName}</button>)}</div>
          <div className="px-4 pt-2 flex justify-between items-center"><button onClick={()=>setActiveSub(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>
          {products[0]&&<SectionDetailsBox detailText={products[0].details[L]}/>}
          {/* Custom tools per sub */}
          {activeSub==='proxy'&&(
            <div className="px-4 mt-4">
              {true&&(
                <div className="mt-3 rounded-xl bg-dark-card p-4 fade-in" style={{border:'1px solid #00d4ff15'}}>
                  <select value={customWallet} onChange={e=>setCustomWallet(e.target.value)} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'نوع البروكسي':'Proxy Type'}</option><option>Residential</option><option>Datacenter</option></select>
                  <select value={customAmount} onChange={e=>setCustomAmount(e.target.value)} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر المدة':'Select Duration'}</option>{proxyDurations.map(d=><option key={d.label} value={`${d.label}|${d.price}`}>{rtl?d.labelAr:d.label} — ${d.price}</option>)}</select>
                  <input value={flashAddr} onChange={e=>setFlashAddr(e.target.value)} placeholder={rtl?'عنوان الـ IP المراد برمجته':'IP address to program'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                  {customAmount&&<p className="text-neon-green text-xs font-bold mb-2">{rtl?'السعر:':'Price:'} ${customAmount.split('|')[1]}</p>}
                  <button disabled={!customWallet||!customAmount||!flashAddr} onClick={()=>{const msg=lang==='ru'?`Заказ прокси\nТип: ${customWallet}\nСрок: ${customAmount.split('|')[0]}\nЦена: $${customAmount.split('|')[1]}\nIP: ${flashAddr}`:lang==='en'?`Proxy Order\nType: ${customWallet}\nDuration: ${customAmount.split('|')[0]}\nPrice: $${customAmount.split('|')[1]}\nIP: ${flashAddr}`:`طلب اشتراك بروكسي مخصص\nالنوع: ${customWallet}\nالمدة: ${customAmount.split('|')[0]}\nالسعر: $${customAmount.split('|')[1]}\nالـ IP: ${flashAddr}`;showBuyModal(lang,msg);}} className="w-full py-2.5 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg text-xs disabled:opacity-40">🛒 {rtl?'تأكيد طلب الاشتراك':'Confirm Subscription'}</button>
                </div>
              )}
            </div>
          )}
          {activeSub==='d2'&&(
            <div className="px-4 mt-4">
              {true&&(
                <div className="mt-3 rounded-xl bg-dark-card p-4 fade-in" style={{border:'1px solid #00d4ff15'}}>
                  <div className="space-y-2 mb-3">{d2Quantities.map(q=><button key={q.label} onClick={()=>{const msg=lang==='ru'?`Заказ D2 ссылок\nКоличество: ${q.label}\nЦена: $${q.price}`:lang==='en'?`D2 Links Order\nQuantity: ${q.label}\nPrice: $${q.price}`:`طلب شراء روابط D2\nالكمية: ${q.label}\nالسعر: $${q.price}`;showBuyModal(lang,msg);}} className="w-full py-2.5 flex justify-between items-center bg-dark-surface border border-gray-800 rounded-lg px-4 hover:border-neon-blue/30 transition-all"><span className="text-xs text-white font-bold">{rtl?q.labelAr:q.label}</span><span className="text-neon-green font-bold text-sm">${q.price}</span></button>)}</div>
                </div>
              )}
            </div>
          )}
          {/* Go to tools button */}
          <div className="px-4 mt-4"><button onClick={()=>setCurrentPage('tools')} className="w-full py-2.5 bg-neon-red/8 border border-neon-red/15 rounded-xl text-neon-red text-xs font-bold">🚀 {rtl?'عرض أدوات التفريغ':'View Exploitation Tools'}</button></div>
        </div>
      );
    }
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {proxySubCategories.map(sub=>(
            <div key={sub.id} onClick={()=>setActiveSub(sub.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:`1px solid ${sub.color}15`}}>
              <div className="relative h-20 md:h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px]" style={{background:sub.color}}/><img src={sub.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onError={e=>{(e.target as HTMLImageElement).src='https://images.pexels.com/photos/5380618/pexels-photo-5380618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400';}}/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-lg">{sub.icon}</span><span className="absolute bottom-2 right-2 text-[9px] text-gray-400">{getProxyProducts(sub.id).length}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-0.5">{sub.name}</h4>{lang==='ar'&&sub.nameAr&&<p className="text-[8px] text-gray-500 mb-1">{sub.nameAr}</p>}<div className="h-[2px] w-full rounded mb-2" style={{background:`${sub.color}30`}}/><button className="w-full py-1.5 rounded text-[9px] font-bold" style={{background:`${sub.color}08`,color:sub.color,border:`1px solid ${sub.color}20`}}>{t('enter')} →</button></div>
            </div>
          ))}
        </div>
        <div className="px-4 mt-4"><button onClick={()=>setCurrentPage('tools')} className="w-full py-2.5 bg-neon-red/8 border border-neon-red/15 rounded-xl text-neon-red text-xs font-bold">🚀 {rtl?'عرض أدوات التفريغ':'View Exploitation Tools'}</button></div>
      </div>
    );
  }

  // ===== GIFTS SECTION =====
  if (activeCat === 'gifts') {
    if (activeSub) {
      const products = getGiftProducts(activeSub);
      const _giftSub = giftSubCategories.find(s=>s.id===activeSub); void _giftSub;
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1 overflow-x-auto pb-1">{giftSubCategories.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-2.5 py-1.5 rounded text-[9px] font-bold ${activeSub===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.shortName}</button>)}</div>
          <div className="px-4 pt-2 flex justify-between items-center"><button onClick={()=>setActiveSub(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>
          {products[0]&&<SectionDetailsBox detailText={products[0].details[L]}/>}
        </div>
      );
    }
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {giftSubCategories.map(sub=>(
            <div key={sub.id} onClick={()=>setActiveSub(sub.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:`1px solid ${sub.color}15`}}>
              <div className="relative h-20 md:h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px]" style={{background:sub.color}}/><img src={sub.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-lg">{sub.icon}</span><span className="absolute bottom-2 right-2 text-[9px] text-gray-400">{getGiftProducts(sub.id).length}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-1">{sub.name}</h4><div className="h-[2px] w-full rounded mb-2" style={{background:`${sub.color}30`}}/><button className="w-full py-1.5 rounded text-[9px] font-bold" style={{background:`${sub.color}08`,color:sub.color,border:`1px solid ${sub.color}20`}}>{t('enter')} →</button></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ===== TOPUP SECTION =====
  if (activeCat === 'topup') {
    const warnText = topupWarning[L];
    const curSec = activeSub;

    // Visual section - show packages
    if (curSec === 'visual') {
      const apps = ['TikTok', 'Jaco'];
      const pkgs = visualPackages.filter(p => p.app === selVisualApp);

      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1.5">{topupSections.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-[10px] font-bold ${curSec===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.icon} {s.name[L].slice(0,15)}</button>)}</div>
          <div className="px-4 pt-2"><button onClick={()=>{setActiveSub(null);setActiveCat(null);}} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
          {/* App tabs */}
          <div className="px-4 pt-2 flex gap-2">{apps.map(a=><button key={a} onClick={()=>setSelVisualApp(a)} className={`px-4 py-2 rounded-lg text-xs font-bold ${selVisualApp===a?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{a==='TikTok'?'🎵':'🟣'} {a}</button>)}</div>
          {/* Packages grid */}
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
            {pkgs.map(pkg=>(
              <div key={pkg.id} className="rounded-xl bg-dark-card overflow-hidden card-hover group" style={{border:'1px solid #00d4ff12'}}>
                <div className="relative"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-blue z-10"/><div className="aspect-[3/2] overflow-hidden"><img src={pkg.image} alt="" className="w-full h-full object-cover"/></div><div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/></div>
                <div className="p-2.5">
                  <h4 className="text-[11px] font-black text-white mb-0.5">{pkg.app} {pkg.amount}</h4>
                  <p className="text-[9px] text-gray-500 mb-1">{rtl?'شحن فوري':'Instant top-up'}</p>
                  <p className="text-neon-green font-black text-sm mb-2">${pkg.price}</p>
                  <div className="flex gap-1">
                    <button onClick={()=>setShowTopupWarn(true)} className="flex-1 py-1.5 text-[9px] font-bold bg-gray-800 text-gray-300 rounded">ℹ️</button>
                    <button onClick={()=>{const msg=`⚡ ${lang==='ru'?'Заказ пополнения':lang==='en'?'Top-up Order':'طلب شحن'}\n📱 ${pkg.app}\n📦 ${pkg.amount}\n💵 ${pkg.price}$`;showBuyModal(lang,msg);}} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-green/10 border border-neon-green/20 text-neon-green rounded">⚡ {rtl?'اشحن':'Charge'}</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* Warning modal */}
          {showTopupWarn&&<div className="fixed inset-0 z-[600] bg-black/80 flex items-center justify-center p-4" onClick={()=>setShowTopupWarn(false)}><div className="max-w-md bg-dark-card rounded-xl p-5 border border-neon-red/20" onClick={e=>e.stopPropagation()}><h3 className="text-xs font-black text-neon-red mb-3">⚠️ {rtl?'تنبيه أمني':'Security Warning'}</h3><p className="text-[11px] text-gray-400 leading-[1.7] whitespace-pre-line">{warnText}</p><button onClick={()=>setShowTopupWarn(false)} className="w-full mt-4 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold">{t('close')}</button></div></div>}
          {/* Visual charging tool */}
          <div className="px-4 mt-4">
            {true&&(
              <div className="mt-3 rounded-xl bg-dark-card p-4 fade-in" style={{border:'1px solid #00d4ff15'}}>
                <select value={topupApp} onChange={e=>setTopupApp(e.target.value)} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر التطبيق':'Select App'}</option>{apps.map(a=><option key={a} value={a}>{a}</option>)}</select>
                {topupApp&&<select value={topupPkg} onChange={e=>setTopupPkg(e.target.value)} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر الباقة':'Select Package'}</option>{visualPackages.filter(p=>p.app===topupApp).map(p=><option key={p.id} value={`${p.amount}|${p.price}`}>{p.amount} — ${p.price}</option>)}</select>}
                <input value={topupUser} onChange={e=>setTopupUser(e.target.value)} placeholder={rtl?'يوزر الحساب':'Account Username'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                <input type="password" value={topupPass} onChange={e=>setTopupPass(e.target.value)} placeholder={rtl?'كلمة المرور':'Password'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                {topupPkg&&<p className="text-neon-green text-xs font-bold mb-2">{rtl?'السعر:':'Price:'} ${topupPkg.split('|')[1]}</p>}
                <p className="text-[9px] text-neon-red mb-2">{rtl?'⚠️ يرجى اختيار الباقة من القائمة فقط':'⚠️ Please select package from list only'}</p>
                <button disabled={!topupApp||!topupPkg||!topupUser||!topupPass} onClick={()=>{const msg=`⚡ ${lang==='ru'?'Заказ пополнения':lang==='en'?'Top-up Order':'طلب شحن'}\n📱 ${topupApp}\n📦 ${topupPkg.split('|')[0]}\n💵 $${topupPkg.split('|')[1]}\n👤 ${topupUser}\n🔑 ${topupPass}`;showBuyModal(lang,msg);setTopupUser('');setTopupPass('');setTopupPkg('');}} className="w-full py-2.5 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg text-xs disabled:opacity-40">🚀 {rtl?'إكمال الشحن':'Complete Charge'}</button>
              </div>
            )}
          </div>
          {/* Charging tips */}
          <div className="px-4 mt-3">
            <div className="rounded-xl bg-black border border-neon-red/15 overflow-hidden">
              <div className="h-[2px] bg-neon-red/40"/>
              <div className="p-3 space-y-1.5">
                <h4 className="text-[10px] font-black text-neon-red">⚠️ {rtl?'تنبيهات مهمة للشحن:':'Important Charging Tips:'}</h4>
                {(rtl?['يُفضل استخدام حساب جديد للشحن لتجنب حظر حسابك الأساسي','لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات','بادر باستهلاك الرصيد فوراً بعد الشحن','أي بلاغ على البطاقة يؤدي لاسترداد الشحن وحظر الحساب نهائياً']:['Use a new account for top-up to avoid banning your main account','Don\'t leave balance in account for more than 3 hours','Use the balance immediately after charging','Any card report leads to chargeback and permanent account ban']).map((tip,i)=><div key={i} className="flex items-start gap-2 text-[9px] text-gray-400 p-1"><span className="text-neon-red">⚠</span>{tip}</div>)}
              </div>
            </div>
          </div>
          <div className="px-4 mt-2 p-3 rounded-lg bg-dark-card border border-gray-800/50 text-[10px] text-gray-500">{rtl?'💡 طلب مخصص: إذا لم تجد التطبيق المطلوب، راسل المسؤول فوراً وسيتم شحن التطبيق المطلوب':'💡 Custom order: Contact manager if your app is not listed and it will be charged'}</div>
        </div>
      );
    }

    // Audio section
    if (curSec === 'audio') {
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1.5">{topupSections.map(s=><button key={s.id} onClick={()=>setActiveSub(s.id)} className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-[10px] font-bold ${curSec===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.icon} {s.name[L].slice(0,15)}</button>)}</div>
          <div className="px-4 pt-2"><button onClick={()=>{setActiveSub(null);setActiveCat(null);}} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
          {/* Audio apps - first package each */}
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
            {audioApps.map(app=>(
              <div key={app.id} className="rounded-xl bg-dark-card overflow-hidden card-hover group" style={{border:'1px solid #00d4ff12'}}>
                <div className="relative"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-blue z-10"/><div className="aspect-[3/2] overflow-hidden"><img src={app.image} alt="" className="w-full h-full object-cover"/></div><div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/></div>
                <div className="p-2.5">
                  <h4 className="text-[11px] font-black text-white mb-0.5">{app.icon} {app.name}</h4>
                  <p className="text-[9px] text-gray-500 mb-0.5">{app.baseQty.toLocaleString()} {app.currency}</p>
                  <p className="text-neon-green font-black text-sm mb-2">${app.basePrice}</p>
                  <div className="flex gap-1">
                    <button onClick={()=>setShowTopupWarn(true)} className="flex-1 py-1.5 text-[9px] font-bold bg-gray-800 text-gray-300 rounded">ℹ️</button>
                    <button onClick={()=>{const msg=`⚡ ${lang==='ru'?'Заказ пополнения':lang==='en'?'Top-up Order':'طلب شحن'}\n📱 ${app.name}\n📦 ${app.baseQty.toLocaleString()} ${app.currency}\n💵 ${app.basePrice}$`;showBuyModal(lang,msg);}} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-green/10 border border-neon-green/20 text-neon-green rounded">⚡</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* Warning modal */}
          {showTopupWarn&&<div className="fixed inset-0 z-[600] bg-black/80 flex items-center justify-center p-4" onClick={()=>setShowTopupWarn(false)}><div className="max-w-md bg-dark-card rounded-xl p-5 border border-neon-red/20" onClick={e=>e.stopPropagation()}><h3 className="text-xs font-black text-neon-red mb-3">⚠️ {rtl?'تنبيه أمني':'Security Warning'}</h3><p className="text-[11px] text-gray-400 leading-[1.7] whitespace-pre-line">{warnText}</p><button onClick={()=>setShowTopupWarn(false)} className="w-full mt-4 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold">{t('close')}</button></div></div>}
          {/* Audio custom charging tool */}
          <div className="px-4 mt-4">
            {true&&(
              <div className="mt-3 rounded-xl bg-dark-card p-4 fade-in" style={{border:'1px solid #00d4ff15'}}>
                <p className="text-[9px] text-neon-gold mb-3">{rtl?'⚠️ أدخل كمية أكبر من الباقة الأساسية. السعر يُحسب تلقائياً.':'⚠️ Enter quantity larger than base package. Price calculated automatically.'}</p>
                <select value={topupApp} onChange={e=>{setTopupApp(e.target.value);setTopupCustomQty('');}} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"><option value="">{rtl?'اختر التطبيق':'Select App'}</option>{audioApps.map(a=><option key={a.id} value={a.id}>{a.icon} {a.name} ({a.baseQty.toLocaleString()} {a.currency} = ${a.basePrice})</option>)}</select>
                <input type="number" value={topupCustomQty} onChange={e=>setTopupCustomQty(e.target.value)} placeholder={rtl?'الكمية المطلوبة':'Required quantity'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                {topupApp&&topupCustomQty&&(()=>{const selAp=audioApps.find(a=>a.id===topupApp);if(!selAp)return null;const q=Number(topupCustomQty);const unitPrice=selAp.basePrice/selAp.baseQty;const total=Math.round(q*unitPrice);if(q<=selAp.baseQty)return<p className="text-neon-red text-[10px] mb-2">{rtl?`⚠️ يجب أن تكون أكبر من ${selAp.baseQty.toLocaleString()}`:`⚠️ Must be > ${selAp.baseQty.toLocaleString()}`}</p>;return<p className="text-neon-green text-xs font-bold mb-2">{rtl?'السعر:':'Price:'} ${total}</p>;})()}
                <input value={topupId} onChange={e=>setTopupId(e.target.value)} placeholder={rtl?'الـ ID':'App ID'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                <input value={topupUser} onChange={e=>setTopupUser(e.target.value)} placeholder={rtl?'اليوزر / الباسورد':'Username / Password'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white outline-none"/>
                <button disabled={!topupApp||!topupCustomQty||!topupId} onClick={()=>{const selAp=audioApps.find(a=>a.id===topupApp);if(!selAp)return;const q=Number(topupCustomQty);const total=Math.round(q*(selAp.basePrice/selAp.baseQty));const msg=`⚡ ${lang==='ru'?'Заказ пополнения':lang==='en'?'Custom Top-up':'طلب شحن مخصص'}\n📱 ${selAp.name}\n📦 ${q.toLocaleString()}\n💵 $${total}\n🆔 ${topupId}\n👤 ${topupUser}`;showBuyModal(lang,msg);setTopupCustomQty('');setTopupId('');setTopupUser('');}} className="w-full py-2.5 bg-gradient-to-r from-neon-blue to-neon-green text-black font-black rounded-lg text-xs disabled:opacity-40">🚀 {rtl?'إكمال الشحن':'Complete Charge'}</button>
              </div>
            )}
          </div>
          {/* Charging tips */}
          <div className="px-4 mt-3">
            <div className="rounded-xl bg-black border border-neon-red/15 overflow-hidden">
              <div className="h-[2px] bg-neon-red/40"/>
              <div className="p-3 space-y-1.5">
                <h4 className="text-[10px] font-black text-neon-red">⚠️ {rtl?'تنبيهات مهمة للشحن:':'Important Charging Tips:'}</h4>
                {(rtl?['يُفضل استخدام حساب جديد للشحن لتجنب حظر حسابك الأساسي','لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات','بادر باستهلاك الرصيد فوراً بعد الشحن','أي بلاغ على البطاقة يؤدي لاسترداد الشحن وحظر الحساب نهائياً']:['Use a new account for top-up to avoid banning your main account','Don\'t leave balance more than 3 hours','Use balance immediately after charging','Any card report leads to chargeback and permanent ban']).map((tip,i)=><div key={i} className="flex items-start gap-2 text-[9px] text-gray-400 p-1"><span className="text-neon-red">⚠</span>{tip}</div>)}
              </div>
            </div>
          </div>
          <div className="px-4 mt-2 p-3 rounded-lg bg-dark-card border border-gray-800/50 text-[10px] text-gray-500">{rtl?'💡 طلب مخصص: إذا لم تجد التطبيق المطلوب، راسل المسؤول فوراً وسيتم شحن التطبيق المطلوب':'💡 Custom order: Contact manager if your app is not listed and it will be charged'}</div>
        </div>
      );
    }

    // Topup main - 2 sections
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
        <div className="px-4 mt-3 grid grid-cols-2 gap-3">
          {topupSections.map(sec=>(
            <div key={sec.id} onClick={()=>setActiveSub(sec.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:'1px solid #00d4ff15'}}>
              <div className="relative h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-blue z-10"/><img src={sec.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-lg">{sec.icon}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-1">{sec.name[L]}</h4><div className="h-[2px] w-full bg-neon-blue/20 rounded mb-2"/><button className="w-full py-1.5 rounded text-[9px] font-bold bg-neon-blue/8 text-neon-blue border border-neon-blue/20">{t('enter')} →</button></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ===== CARDS SECTION =====
  if (activeCat === 'cards') {
    if (activeSub) {
      const allProducts = getCardProducts(activeSub);
      const products = productFilter==='bundle' ? allProducts.filter(p=>p.isBundle) : productFilter==='big' ? allProducts.filter(p=>!p.isBundle&&p.price>=200) : allProducts;
      return (
        <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
          <div className="px-4 pt-3 flex gap-1.5">{(['all','injected','pulled'] as const).map(f=><button key={f} onClick={()=>{setCardsFilter(f);setActiveSub(null);setProductFilter('all');}} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold ${cardsFilter===f?'bg-neon-blue text-black':'bg-dark-surface text-gray-600 border border-gray-800'}`}>{t(`filter_${f}`)}</button>)}</div>
          <div className="px-4 pt-2 flex gap-1 overflow-x-auto pb-1">{cardSubCategories.filter(s=>cardsFilter==='all'||s.type===cardsFilter).map(s=><button key={s.id} onClick={()=>{setActiveSub(s.id);setProductFilter('all');}} className={`flex-shrink-0 px-2 py-1 rounded text-[9px] font-bold ${activeSub===s.id?'bg-neon-blue text-black':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{s.shortName}</button>)}</div>
          <div className="px-4 pt-2 flex justify-between items-center"><button onClick={()=>setActiveSub(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button><button onClick={()=>setPaymentModalOpen(true)} className="px-3 py-1 bg-neon-gold/8 border border-neon-gold/20 rounded text-neon-gold text-[9px] font-bold">💠 {rtl?'طرق الدفع':'Payments'}</button></div>
          {/* Product Filter Widget */}
          <div className="px-4 pt-2 flex gap-1.5">
            <button onClick={()=>setProductFilter('all')} className={`flex-1 py-2 rounded-lg text-[9px] font-bold ${productFilter==='all'?'bg-neon-green/15 text-neon-green border border-neon-green/30':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{rtl?'كل العروض':'All Offers'}</button>
            <button onClick={()=>setProductFilter('big')} className={`flex-1 py-2 rounded-lg text-[9px] font-bold ${productFilter==='big'?'bg-neon-gold/15 text-neon-gold border border-neon-gold/30':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{rtl?'المنتجات الكبيرة':'Big Products'}</button>
            <button onClick={()=>setProductFilter('bundle')} className={`flex-1 py-2 rounded-lg text-[9px] font-bold ${productFilter==='bundle'?'bg-[#aa44ff]/15 text-[#aa44ff] border border-[#aa44ff]/30':'bg-dark-surface text-gray-500 border border-gray-800'}`}>{rtl?'البكجات':'Bundles'}</button>
          </div>
          <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>
          {products[0]&&<SectionDetailsBox detailText={products[0].details[L]}/>}
        </div>
      );
    }
    // Cards sub-categories
    const filtered = cardSubCategories.filter(s=>cardsFilter==='all'||s.type===cardsFilter);
    return (
      <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
        <div className="px-4 pt-3"><button onClick={()=>setActiveCat(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>
        {/* Filter tabs */}
        <div className="px-4 mt-2 flex gap-1.5">{(['all','injected','pulled'] as const).map(f=><button key={f} onClick={()=>setCardsFilter(f)} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold ${cardsFilter===f?'bg-neon-blue text-black':'bg-dark-surface text-gray-600 border border-gray-800'}`}>{t(`filter_${f}`)}</button>)}</div>
        {/* Sub-categories */}
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {filtered.map(sub=>(
            <div key={sub.id} onClick={()=>setActiveSub(sub.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{border:`1px solid ${sub.color}15`}}>
              <div className="relative h-20 md:h-24 overflow-hidden"><div className="absolute top-0 left-0 right-0 h-[3px]" style={{background:sub.color}}/><img src={sub.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"/><span className="absolute bottom-2 left-2 text-[10px] text-gray-300 font-bold">{getCardProducts(sub.id).length}</span><span className={`absolute top-2.5 right-2 text-[8px] px-1.5 py-0.5 rounded-full font-bold ${sub.type==='injected'?'bg-neon-green/15 text-neon-green':'bg-neon-red/15 text-neon-red'}`}>{sub.type==='injected'?(rtl?'محقونة':'Injected'):(rtl?'مسحوبة':'Pulled')}</span></div>
              <div className="p-2.5"><h4 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-1.5">{sub.name}</h4><div className="h-[2px] w-full rounded mb-2" style={{background:`${sub.color}30`}}/><button className="w-full py-1.5 rounded text-[9px] font-bold" style={{background:`${sub.color}08`,color:sub.color,border:`1px solid ${sub.color}20`}}>{t('enter')} →</button></div>
            </div>
          ))}
        </div>

        {/* ===== DIFF EXPLANATION - BELOW SECTIONS ===== */}
        <div className="px-4 mt-4">
          <div className="rounded-xl bg-black border border-neon-blue/20 overflow-hidden">
            <div className="h-[3px] bg-neon-blue" />
            <div className="p-3">
              <p className="text-xs text-neon-blue font-black mb-2">{rtl ? 'الفرق بين البطاقات المحقونة والبطاقات المسحوبة' : 'Difference Between Injected & Pulled Cards'}</p>
              <button onClick={() => setShowCardsDiff(!showCardsDiff)} className="w-full py-2 bg-neon-blue/10 border border-neon-blue/15 rounded-lg text-neon-blue text-[10px] font-bold">
                {showCardsDiff ? (rtl ? '✕ إغلاق الشرح' : '✕ Close') : (rtl ? '📖 عرض الشرح' : '📖 Show Guide')}
              </button>
            </div>

            {showCardsDiff && (
              <div className="px-3 pb-4 space-y-3 fade-in">
                {/* Injected Section */}
                <div className="rounded-xl bg-dark-card p-3.5" style={{border:'1px solid #00ff8815'}}>
                  <h4 className="text-xs font-black text-neon-green mb-2">🟢 {rtl ? 'أولاً: بطاقات NOVBV CC / المحقونة (Injected/Synthetic)' : 'First: NOVBV CC / Injected Cards (Injected/Synthetic)'}</h4>
                  <div className="space-y-2">
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl ? '(1) طريقة الاستخراج والحقن:' : '(1) Extraction & Injection Method:'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'نقوم ببرمجة متاجر إلكترونية وبوابات دفع (Payment Gateways) وهمية خاصة بنا، مجهزة بأدوات (Proxy) لتجاوز أنظمة الملاحظة الأمنية.' : 'We program fake e-commerce stores and payment gateways equipped with proxy tools to bypass security monitoring systems.'}</p>
                    </div>
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl ? '(2) التفريغ المشفر:' : '(2) Encrypted Extraction:'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'نقوم بـ "تفريغ" الأموال من البطاقات المسحوبة إلى متاجرنا الوهمية عبر عمليات شراء تبدو نظامية تماماً أمام أنظمة كشف الاحتيال. بدلاً من سحب الأموال مباشرة، نقوم بعملية استرداد (Refund) لهذه الأموال داخل بيانات بطاقات (NOVBV) أنشأناها يدوياً ببيانات وهمية.' : 'We drain funds from pulled cards to our fake stores through purchases that appear completely legitimate to fraud detection systems, then refund into manually created NOVBV cards.'}</p>
                    </div>
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl ? '(3) لماذا هي الأفضل؟' : '(3) Why are they the best?'}</p>
                      <div className="space-y-1">
                        <p className="text-[10px] text-gray-400 leading-[1.7]">• {rtl ? 'انعدام البلاغ: البطاقة NOVBV لا يملكها أحد، لذا لا توجد جهة أو شخص سيقوم بالبلاغ عنها.' : 'No reports: No one owns the NOVBV card, so no entity will report it.'}</p>
                        <p className="text-[10px] text-gray-400 leading-[1.7]">• {rtl ? 'الاستقرار: الحسابات المرتبطة بها تظل مفتوحة لأطول فترة ممكنة لأنها "نظيفة" ولا تثير نظام الحماية (Flagging).' : 'Stability: Linked accounts remain open longest as they are "clean" and don\'t trigger flagging.'}</p>
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-blue font-bold mb-1">{rtl ? '(4) المميزات والخدمات:' : '(4) Features & Services:'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'نقدم حزمة كاملة تتضمن بيانات البطاقة، وبيانات الهوية (Fullz) التي تم فتح الحساب باسمها. الميزة التنافسية: هذه البطاقات تدعم الدفع المباشر (Direct Payment) في أي موقع أو متجر عالمي دون الحاجة إلى تحقق (OTP).' : 'Complete package including card data and Fullz identity data. These cards support Direct Payment at any global site without OTP verification.'}</p>
                    </div>
                  </div>
                </div>

                {/* Pulled Section */}
                <div className="rounded-xl bg-dark-card p-3.5" style={{border:'1px solid #ff004015'}}>
                  <h4 className="text-xs font-black text-neon-red mb-2">🔴 {rtl ? 'ثانياً: البطاقات المسحوبة (Skimmed/Phished)' : 'Second: Pulled Cards (Skimmed/Phished)'}</h4>
                  <p className="text-[10px] text-gray-500 mb-2">{rtl ? 'طريقة الاستخراج: هي بطاقات حقيقية يتم الحصول على بياناتها من أجهزة قراءة البيانات أو صفحات التصيد.' : 'Extraction: Real cards whose data is obtained from skimming devices or phishing pages.'}</p>
                  <div className="space-y-2">
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-red font-bold mb-1">{rtl ? '(1) نظام الكريدت (Credit - السهل):' : '(1) Credit System (Easy):'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'تعتمد على "مديونية" بسقف يصل إلى 50,000$. الصرف لا يظهر في كشف الحساب البنكي اللحظي، بل يتم إضافته لمديونية صاحب البطاقة نهاية الشهر. ميزتها أنها مقبولة عالمياً بالمواقع وبوابات الدفع وشبكات NFC.' : 'Based on debt with ceiling up to $50,000. Charges don\'t appear in real-time bank statements. Accepted globally at websites, payment gateways, and NFC networks.'}</p>
                      <p className="text-[9px] text-gray-500 mt-1 italic">{rtl ? 'المرفقات: بيانات البطاقة الكاملة + بيانات المالك + كورس حقن المعلومات وربط البطاقة وتشفير الهوية الرقمية وبصمة الهاتف.' : 'Attachments: Complete card data + owner info + injection course, gateway linking, digital identity encryption, phone fingerprint.'}</p>
                    </div>
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-red font-bold mb-1">{rtl ? '(2) نظام الديبيت (Debit - المتوسط):' : '(2) Debit System (Medium):'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'بطاقات مرتبطة بالحساب البنكي مباشرة. أي حركة صرف تظهر فوراً في تطبيق البنك لدى صاحبها. خصم مباشر من الرصيد البنكي؛ غالباً ما يتم كشفها بعد العملية الثانية أو الثالثة.' : 'Cards linked directly to bank accounts. Any transaction appears instantly in the bank app. Direct debit; usually detected after 2nd or 3rd transaction.'}</p>
                    </div>
                    <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                      <p className="text-[10px] text-neon-red font-bold mb-1">{rtl ? '(3) الفئات القوية (كلاسيك وبلاتنيوم):' : '(3) Premium Tiers (Classic & Platinum):'}</p>
                      <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'هذه البطاقات محمولة ببروتوكولات حماية عالية (3D Secure) ومخصصة للعمليات الضخمة. البنوك تراقب هذه الفئات بدقة متناهية.' : 'These cards carry high protection protocols (3D Secure) for large operations. Banks monitor these tiers with extreme precision.'}</p>
                    </div>
                  </div>
                </div>

                {/* PayPal/AMEX */}
                <div className="rounded-xl bg-dark-card p-3.5" style={{border:'1px solid #00d4ff15'}}>
                  <h4 className="text-xs font-black text-neon-blue mb-2">🔵 {rtl ? 'حسابات (PayPal / American Express 10.1):' : 'PayPal / American Express 10.1 Accounts:'}</h4>
                  <p className="text-[10px] text-gray-400 leading-[1.7]">{rtl ? 'لا نقدم مجرد حساب، بل نقدم "نظام وصول". تستلم بيانات الدخول الكاملة للتطبيق (App Credentials)، مضافة إليها بيانات البطاقة المربوطة، لضمان إدارة كاملة للحساب.' : 'We don\'t just provide an account, we provide an "access system". You receive full app credentials plus linked card data for complete account management.'}</p>
                </div>

                {/* Protocol */}
                <div className="rounded-xl bg-dark-card p-3.5" style={{border:'1px solid #ffd70015'}}>
                  <h4 className="text-xs font-black text-neon-gold mb-2">🔒 {rtl ? 'بروتوكول التشغيل والحماية' : 'Operation & Protection Protocol'}</h4>
                  <p className="text-[10px] text-gray-500 mb-2">{rtl ? 'يتم إرسال "حزمة إرشادية" مع كل خدمة تتضمن:' : 'An instructional package is sent with each service:'}</p>
                  <div className="space-y-1">
                    {(rtl ? [
                      'طرق التشفير: تأمين العمليات بأحدث أساليب التخفي',
                      'الربط والحقن: شرح آليات الربط عبر كافة بوابات الدفع العالمية (Apple Pay / Google Pay)',
                      'تجاوز الأنظمة: طرق تخطي الحماية والحقن المباشر لضمان نجاح العملية',
                      'التهيئة الفنية: كورس حقن المعلومات، وتشفير الهوية الرقمية، وتغيير بصمة الهاتف',
                    ] : [
                      'Encryption methods: Securing operations with latest stealth techniques',
                      'Linking & injection: Via all global payment gateways (Apple Pay / Google Pay)',
                      'System bypass: Methods to bypass protection and direct injection',
                      'Technical setup: Info injection course, digital identity encryption, phone fingerprint change',
                    ]).map((item, i) => (
                      <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-dark-surface border border-gray-800/20">
                        <span className="text-neon-gold text-[10px]">✓</span>
                        <span className="text-[10px] text-gray-400 leading-[1.6]">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Close button */}
                <button onClick={() => setShowCardsDiff(false)} className="w-full py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-[10px] font-bold">
                  ✕ {rtl ? 'إغلاق الشرح' : 'Close Guide'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Slideshow data with real images
  const slides = [
    { img: 'https://images.pexels.com/photos/13810195/pexels-photo-13810195.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=250&w=600', title: 'VISA & NOVBV', accent: '#f7b924' },
    { img: 'https://images.pexels.com/photos/164501/pexels-photo-164501.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=250&w=600', title: 'MASTERCARD', accent: '#f79e1b' },
    { img: 'https://i.postimg.cc/26js7NgP/images-(32).jpg', title: 'PayPal', accent: '#009cde' },
    { img: 'https://images.pexels.com/photos/20534452/pexels-photo-20534452.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=250&w=600', title: 'CRYPTO & GIFT CARDS', accent: '#f0b90b' },
    { img: 'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', title: 'TikTok', accent: '#25f4ee' },
    { img: 'https://images.pexels.com/photos/5380603/pexels-photo-5380603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=250&w=600', title: 'PROXY & ENCRYPTION', accent: '#00ff88' },
  ];


  // ===== MAIN STORE (6 categories) =====
  return (
    <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
      {/* Site name with color change */}
      <div className="px-4 pt-4 text-center">
        <h1 className="text-xl font-black tracking-wider transition-colors duration-1000" style={{ fontFamily: 'Orbitron, sans-serif', color: nameGlow ? '#00d4ff' : '#ffffff' }}>
          BLACK MART
        </h1>
      </div>

      {/* Interactive slideshow - programmatic design */}
      <div className="px-4 mt-2">
        <div className="rounded-xl overflow-hidden relative" style={{ border: '2px solid #00d4ff25' }}>
          <div className="h-32 md:h-40 relative">
            {slides.map((s, i) => (
              <div key={i} className={`absolute inset-0 transition-opacity duration-1000 ${i === slideIdx ? 'opacity-100' : 'opacity-0'}`}>
                <img src={s.img} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-3 left-4">
                  <h3 className="text-base md:text-lg font-black tracking-wider" style={{ fontFamily: 'Orbitron, sans-serif', color: s.accent }}>{s.title}</h3>
                </div>
              </div>
            ))}
          </div>
          {/* Dots */}
          <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1.5">
            {slides.map((_, i) => (
              <button key={i} onClick={() => setSlideIdx(i)} className={`w-1.5 h-1.5 rounded-full transition-all ${i === slideIdx ? 'bg-neon-blue scale-125' : 'bg-gray-600'}`} />
            ))}
          </div>
        </div>
      </div>

      {/* Categories grid */}
      <div className="px-4 mt-4 grid grid-cols-2 md:grid-cols-3 gap-3">
        {storeCategories.map(cat=>(
          <div key={cat.id} onClick={()=>setActiveCat(cat.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group relative" style={{border:`1px solid ${cat.color}15`}}>
            <div className="h-24 md:h-28 overflow-hidden relative">{cat.image?<img src={cat.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>:<div className="w-full h-full" style={{background:`linear-gradient(135deg,${cat.color}06,black)`}}/>}<div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/5"/></div>
            <div className="p-3"><h3 className="text-[13px] font-black text-white group-hover:text-neon-blue transition-colors mb-1">{t(cat.nameKey)}</h3><div className="h-[2px] w-full rounded-full mb-2" style={{background:`${cat.color}35`}}/><button className="w-full py-2 rounded-lg text-xs font-bold" style={{background:`${cat.color}08`,color:cat.color,border:`1px solid ${cat.color}20`}}>{t('enter')} →</button></div>
          </div>
        ))}
      </div>
      <div className="px-4 mt-4"><button onClick={()=>setShowExplanation(!showExplanation)} className="w-full py-2.5 rounded-lg bg-dark-card border border-neon-blue/12 text-xs font-bold text-neon-blue">📖 {showExplanation?t('close_explanation'):t('show_explanation')}</button></div>
      {showExplanation&&<div className="px-4 mt-3 fade-in"><div className="rounded-xl bg-dark-card/80 p-4" style={{border:'1px solid #00d4ff15'}}><h3 className="text-sm font-black text-white mb-1">{t('store_explanation_title')}</h3><p className="text-neon-blue text-xs font-bold mb-3">{t('store_explanation_subtitle')}</p><div className="space-y-1.5">{[1,2,3,4,5,6].map(i=><div key={i} className="flex items-start gap-2 text-xs text-gray-400 p-2 rounded-lg bg-dark-surface border border-gray-800/30"><span className="text-neon-blue">▸</span><span className="leading-[1.7]">{t(`store_exp_${i}`)}</span></div>)}</div><div className="mt-3 p-3 rounded-lg bg-neon-red/5 border border-neon-red/15"><p className="text-[11px] text-neon-red leading-[1.7]">{t('store_warning')}</p></div></div></div>}
    </div>
  );
};

export default StorePage;
