import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const TG_SUPPORT = 'https://t.me/Visacardnovbv?direct';

type Tab = 'support' | 'refund' | 'replace';

const AdminReportsPage: React.FC = () => {
  const { rtl, setCurrentPage } = useApp();
  const [activeTab, setActiveTab] = useState<Tab>('support');

  // Support chat state
  const [supportMsg, setSupportMsg] = useState('');
  const [chatMessages, setChatMessages] = useState<{role:'user'|'system';text:string}[]>([]);

  // Refund state
  const [refProduct, setRefProduct] = useState('');
  const [refOrder, setRefOrder] = useState('');
  const [refProblem, setRefProblem] = useState('');
  const [refNetwork, setRefNetwork] = useState('');
  const [refWallet, setRefWallet] = useState('');
  const [refSent, setRefSent] = useState(false);

  // Replace state
  const [repProduct, setRepProduct] = useState('');
  const [repProblem, setRepProblem] = useState('');
  const [repNewProduct, setRepNewProduct] = useState('');
  const [repSent, setRepSent] = useState(false);

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'support', label: rtl ? 'خدمة العملاء' : 'Support', icon: '🎧' },
    { id: 'refund', label: rtl ? 'استرجاع' : 'Refund', icon: '💰' },
    { id: 'replace', label: rtl ? 'استبدال' : 'Replace', icon: '🔄' },
  ];

  const handleSupportSend = () => {
    if (!supportMsg.trim()) return;
    const userMsg = supportMsg.trim();
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setSupportMsg('');
    // Auto reply after 1 second
    setTimeout(() => {
      setChatMessages(prev => [...prev, {
        role: 'system',
        text: rtl
          ? '✅ تم استلام طلبك.\n\nإذا كان لديك أي استفسار طارئ، توجه لخدمة العملاء 👇'
          : '✅ Your request has been received.\n\nFor any urgent inquiry, contact Customer Support 👇'
      }]);
    }, 1000);
  };

  const handleRefundSend = () => {
    if (!refProduct || !refOrder || !refProblem) return;
    setRefSent(true);
    setRefProduct(''); setRefOrder(''); setRefProblem(''); setRefNetwork(''); setRefWallet('');
  };

  const handleReplaceSend = () => {
    if (!repProduct || !repProblem || !repNewProduct) return;
    setRepSent(true);
    setRepProduct(''); setRepProblem(''); setRepNewProduct('');
  };

  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Close button */}
      <div className="px-4 pt-4 flex justify-between items-center">
        <h2 className="text-sm font-black text-neon-red">🛡️ {rtl ? 'الإدارة والبلاغات' : 'Admin & Reports'}</h2>
        <button onClick={() => setCurrentPage('home')} className="w-8 h-8 rounded-lg bg-neon-red/10 border border-neon-red/20 text-neon-red flex items-center justify-center text-sm">✕</button>
      </div>

      {/* Tabs */}
      <div className="px-4 mt-3 flex gap-1.5">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => { setActiveTab(tab.id); setRefSent(false); setRepSent(false); }}
            className={`flex-1 py-2.5 rounded-xl text-[10px] font-bold transition-all ${activeTab === tab.id ? 'bg-neon-red/15 text-neon-red border border-neon-red/30' : 'bg-dark-card text-gray-500 border border-gray-800'}`}>
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* ===== TAB 1: SUPPORT (Chat System) ===== */}
      {activeTab === 'support' && (
        <div className="px-4 mt-4 space-y-3">
          <div className="rounded-xl bg-dark-card border border-gray-800/50 overflow-hidden">
            {/* Chat header */}
            <div className="p-3 border-b border-gray-800/50 flex items-center gap-2">
              <span className="text-lg">🎧</span>
              <span className="text-xs font-bold text-neon-blue">{rtl ? 'خدمة العملاء' : 'Customer Support'}</span>
              <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse ml-auto" />
            </div>

            {/* Chat messages */}
            <div className="h-52 overflow-y-auto p-3 space-y-2.5">
              {chatMessages.length === 0 && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] px-3 py-2 rounded-lg bg-dark-surface text-gray-400 border border-gray-800/50 text-[11px] leading-[1.6]">
                    {rtl ? '🎧 مرحباً بك في خدمة العملاء. أرسل رسالتك وسيتم الرد عليك.' : '🎧 Welcome to Customer Support. Send your message and you will be replied to.'}
                  </div>
                </div>
              )}
              {chatMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] px-3 py-2 rounded-lg text-[11px] leading-[1.6] whitespace-pre-line ${
                    msg.role === 'user'
                      ? 'bg-neon-blue/15 text-white'
                      : 'bg-dark-surface text-gray-300 border border-gray-800/50'
                  }`}>
                    {msg.text}
                    {msg.role === 'system' && (
                      <a href={TG_SUPPORT} target="_blank" rel="noopener noreferrer" className="block mt-2 py-1.5 bg-neon-red/10 border border-neon-red/20 rounded-lg text-center text-neon-red font-bold text-[10px]">
                        🎧 {rtl ? 'خدمة العملاء' : 'Customer Support'}
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Chat input */}
            <div className="p-3 border-t border-gray-800/50 flex gap-2">
              <input value={supportMsg} onChange={e => setSupportMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSupportSend()} placeholder={rtl ? 'اكتب رسالتك...' : 'Type your message...'} className="flex-1 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
              <button onClick={handleSupportSend} disabled={!supportMsg.trim()} className="px-4 py-2 bg-neon-blue/15 border border-neon-blue/30 rounded-lg text-neon-blue font-bold text-sm disabled:opacity-40">📤</button>
            </div>
          </div>

          {/* Direct contact button always visible */}
          <a href={TG_SUPPORT} target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/10 border border-neon-red/20 rounded-xl text-center text-neon-red font-bold text-sm">
            🎧 {rtl ? 'خدمة العملاء — تواصل مباشر' : 'Customer Support — Direct Contact'}
          </a>
        </div>
      )}

      {/* ===== TAB 2: REFUND ===== */}
      {activeTab === 'refund' && (
        <div className="px-4 mt-4 space-y-3">
          <div className="rounded-xl bg-dark-card p-4 border border-gray-800/50">
            <h3 className="text-xs font-black text-neon-gold mb-3">💰 {rtl ? 'طلب استرجاع' : 'Refund Request'}</h3>
            <input value={refProduct} onChange={e => setRefProduct(e.target.value)} placeholder={rtl ? 'اسم المنتج' : 'Product Name'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={refOrder} onChange={e => setRefOrder(e.target.value)} placeholder={rtl ? 'رقم الطلب' : 'Order Number'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <textarea value={refProblem} onChange={e => setRefProblem(e.target.value)} rows={3} placeholder={rtl ? 'شرح المشكلة' : 'Describe the problem'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40 resize-none" />
            <input value={refNetwork} onChange={e => setRefNetwork(e.target.value)} placeholder={rtl ? 'الشبكة (اختياري)' : 'Network (optional)'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <input value={refWallet} onChange={e => setRefWallet(e.target.value)} placeholder={rtl ? 'عنوان محفظتك' : 'Your wallet address'} className="w-full mb-3 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <button onClick={handleRefundSend} disabled={!refProduct || !refOrder || !refProblem} className="w-full py-2.5 bg-neon-gold/15 border border-neon-gold/30 rounded-xl text-neon-gold text-xs font-bold disabled:opacity-40">
              📤 {rtl ? 'إرسال طلب الاسترجاع' : 'Submit Refund Request'}
            </button>
          </div>

          {refSent && (
            <div className="rounded-xl bg-neon-green/5 border border-neon-green/15 p-4">
              <p className="text-[11px] text-neon-green font-bold mb-1">✅ {rtl ? 'تم استلام بلاغك، سيتم فحص الطلب والرد عليك في أقرب وقت.' : 'Your report has been received. The request will be reviewed and you will be replied to shortly.'}</p>
              <p className="text-[9px] text-gray-500 mt-1">{rtl ? 'ملاحظة: في حال أردت التحدث مع مسؤول بشكل مباشر، توجه لخدمة العملاء.' : 'Note: For direct manager contact, go to Customer Support.'}</p>
            </div>
          )}

          <a href={TG_SUPPORT} target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/10 border border-neon-red/20 rounded-xl text-center text-neon-red font-bold text-sm">
            🎧 {rtl ? 'خدمة العملاء' : 'Customer Support'}
          </a>
        </div>
      )}

      {/* ===== TAB 3: REPLACE ===== */}
      {activeTab === 'replace' && (
        <div className="px-4 mt-4 space-y-3">
          <div className="rounded-xl bg-dark-card p-4 border border-gray-800/50">
            <h3 className="text-xs font-black text-neon-blue mb-3">🔄 {rtl ? 'طلب استبدال' : 'Replacement Request'}</h3>
            <input value={repProduct} onChange={e => setRepProduct(e.target.value)} placeholder={rtl ? 'اسم المنتج الحالي' : 'Current Product Name'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <textarea value={repProblem} onChange={e => setRepProblem(e.target.value)} rows={3} placeholder={rtl ? 'شرح المشكلة' : 'Describe the problem'} className="w-full mb-2 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40 resize-none" />
            <input value={repNewProduct} onChange={e => setRepNewProduct(e.target.value)} placeholder={rtl ? 'اسم المنتج البديل المطلوب' : 'Desired Replacement Product'} className="w-full mb-3 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-neon-blue/40" />
            <button onClick={handleReplaceSend} disabled={!repProduct || !repProblem || !repNewProduct} className="w-full py-2.5 bg-neon-blue/15 border border-neon-blue/30 rounded-xl text-neon-blue text-xs font-bold disabled:opacity-40">
              📤 {rtl ? 'إرسال طلب الاستبدال' : 'Submit Replacement Request'}
            </button>
          </div>

          {repSent && (
            <div className="rounded-xl bg-neon-green/5 border border-neon-green/15 p-4">
              <p className="text-[11px] text-neon-green font-bold mb-1">✅ {rtl ? 'تم استلام بلاغك، سيتم فحص الطلب والرد عليك في أقرب وقت.' : 'Your report has been received. The request will be reviewed shortly.'}</p>
              <p className="text-[9px] text-gray-500 mt-1">{rtl ? 'ملاحظة: في حال أردت التحدث مع مسؤول بشكل مباشر، توجه لخدمة العملاء.' : 'Note: For direct manager contact, go to Customer Support.'}</p>
            </div>
          )}

          <a href={TG_SUPPORT} target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/10 border border-neon-red/20 rounded-xl text-center text-neon-red font-bold text-sm">
            🎧 {rtl ? 'خدمة العملاء' : 'Customer Support'}
          </a>
        </div>
      )}
    </div>
  );
};

export default AdminReportsPage;
