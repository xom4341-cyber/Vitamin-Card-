import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import { showCartToast } from '../utils/cartToast';

interface LP { ar:string; en:string; ru:string; }
interface EliteTool { id:string; name:LP; price:number; oldPrice:number; desc:LP; details:LP; image:string; }

const tools: EliteTool[] = [
  { id:'et1', name:{ar:'أداة برنامج الفلاش',en:'Flash Tool (USDT & BTC)',ru:'Инструмент Flash (USDT & BTC)'}, price:250, oldPrice:500, image:'https://i.postimg.cc/v8LqKkfG/1783705854279.png',
    desc:{ar:'برنامج الفلاش Flash USDT & Bitcoin — سرعة معالجة هائلة، تخطي قيود الشبكة، وتوافق مع مختلف المحافظ',en:'Flash USDT & Bitcoin Tool — massive processing speed, network bypass, compatible with all wallets',ru:'Flash USDT & Bitcoin — высокая скорость, обход сетевых ограничений, совместимость с кошельками'},
    details:{ar:'الجيل الجديد من أدوات تعدين العملات الرقمية بتقنية الفلاش. أداة احترافية تمكنك من صناعة عملات USDT و BTC فلاش بمواصفات تقنية عالية.\n\nميزة إضافية: نوفر مع الأداة كورس تعليمي شامل يوضح لك كيفية التعامل معها، ضبط إعداداتها، وأسرار الاحتراف.',en:'New generation crypto mining tool with Flash technology. Professional tool for creating Flash USDT & BTC with high specifications.\n\nBonus: Includes comprehensive training course on setup and professional secrets.',ru:'Новое поколение инструментов для майнинга крипто с технологией Flash. Профессиональный инструмент для создания Flash USDT и BTC.\n\nБонус: Включает полный обучающий курс.'} },
  { id:'et2', name:{ar:'أداة تصيد بطاقات الهدايا',en:'Gift Cards Phishing Tool',ru:'Инструмент фишинга подарочных карт'}, price:150, oldPrice:300, image:'https://i.postimg.cc/dtZ73P6J/1783705897332.png',
    desc:{ar:'نظام ذكي يعتمد على خوارزميات الاستخراج المباشر، ضمان عدم التكرار، وتحديثات يومية',en:'Smart system with direct extraction algorithms, no duplicates, daily database updates',ru:'Умная система с алгоритмами прямого извлечения, без дубликатов, ежедневные обновления'},
    details:{ar:'أقوى نظام تقني لاستخراج وتوليد بيانات بطاقات الهدايا العالمية. تشمل بطاقات باينانس، آيتونز، أمازون، وجميع البطاقات الرقمية بدقة عالية.\n\nميزة إضافية: كورس تعليمي لاستغلال البطاقات والتعامل معها بأمان.',en:'Most powerful system for extracting global gift card data. Includes Binance, iTunes, Amazon and all digital cards.\n\nBonus: Training course for safe card exploitation.',ru:'Мощнейшая система для извлечения данных подарочных карт. Binance, iTunes, Amazon и все цифровые карты.\n\nБонус: Обучающий курс по безопасному использованию.'} },
  { id:'et3', name:{ar:'أداة شحن التطبيقات',en:'App Top-up Tool',ru:'Инструмент пополнения приложений'}, price:180, oldPrice:350, image:'https://i.postimg.cc/CLCRkC3C/1783705945892.png',
    desc:{ar:'الحل الأمثل لشحن حساباتك في التطبيقات العالمية — تيك توك، جاكو، وغيرها',en:'Ultimate solution for topping up global apps — TikTok, Jaco, and more',ru:'Лучшее решение для пополнения приложений — TikTok, Jaco и других'},
    details:{ar:'أداة مصممة لربط البطاقات مباشرة وشحن حسابك بعيداً عن الرقابة، وتجاوز قيود OTP. سرعة تنفيذ فائقة وخصوصية كاملة.\n\nميزة إضافية: دليل تعليمي للربط والشحن باحترافية.',en:'Tool designed for direct card linking and charging away from monitoring, bypassing OTP restrictions. Ultra-fast execution and full privacy.\n\nBonus: Professional linking and charging guide.',ru:'Инструмент для прямой привязки карт и пополнения без мониторинга, обход OTP. Сверхбыстрое выполнение.\n\nБонус: Профессиональное руководство.'} },
  { id:'et4', name:{ar:'أداة تصيد البطاقات',en:'Cards Phishing Tool',ru:'Инструмент фишинга карт'}, price:300, oldPrice:600, image:'https://i.postimg.cc/5ynZWRY9/1783705984833.png',
    desc:{ar:'أداة استهداف تقنية للمتاجر الإلكترونية — سحب بيانات البطاقات بذكاء',en:'Technical targeting tool for e-commerce — smart card data extraction',ru:'Инструмент для интернет-магазинов — умное извлечение данных карт'},
    details:{ar:'تعتمد على تقنيات التمويه المتقدمة لجمع بيانات البطاقات من المنصات المستهدفة وتوفيرها بتنسيق منظم.\n\nميزة إضافية: كورس تدريبي للعمل بالأداة وتأمين حساباتك.',en:'Uses advanced camouflage techniques to collect card data from targeted platforms in organized format.\n\nBonus: Training course for tool operation and account security.',ru:'Использует продвинутые техники маскировки для сбора данных карт с целевых платформ.\n\nБонус: Обучающий курс по работе и безопасности.'} },
  { id:'et5', name:{ar:'أداة فحص البطاقات',en:'Cards Checker Tool',ru:'Инструмент проверки карт'}, price:100, oldPrice:200, image:'https://i.postimg.cc/QMJmzWKY/Screenshot-20260710-205352-Google.jpg',
    desc:{ar:'الفاحص الأكثر دقة — فحص وتحليل البطاقات بدقة متناهية',en:'Most accurate checker — card verification and analysis with extreme precision',ru:'Самый точный чекер — проверка и анализ карт с высокой точностью'},
    details:{ar:'تكشف حالة البطاقة (فعالة/غير فعالة)، مصدرها (البنك)، دولتها، نوعها، وتقدير رصيدها.\n\nميزة إضافية: كورس تعليمي لقراءة تقارير الفحص وتحديد البطاقات الأعلى جودة.',en:'Reveals card status (live/dead), source bank, country, type, and balance estimate.\n\nBonus: Course on reading check reports and identifying highest quality cards.',ru:'Показывает статус карты, банк, страну, тип и оценку баланса.\n\nБонус: Курс по чтению отчётов и выбору лучших карт.'} },
  { id:'et6', name:{ar:'Shadow RDP — سيرفر التحكم الخفي',en:'Shadow RDP — Stealth Control Server',ru:'Shadow RDP — Скрытый сервер управления'}, price:80, oldPrice:150, image:'https://i.postimg.cc/j2LhCggG/1783706068291.png',
    desc:{ar:'سرعة خيالية — مثالي لتشغيل أدوات الفحص والتصيد بسرعة استجابة عالية',en:'Incredible speed — ideal for running check and phishing tools with high response',ru:'Невероятная скорость — идеален для инструментов проверки и фишинга'},
    details:{ar:'جهاز كمبيوتر خارجي بمواصفات خارقة وسرعة إنترنت 1 جيجابت/ثانية.\n\n• خصوصية مطلقة: اعمل من سيرفرات أمريكا أو أوروبا\n• استمرارية 24/7: يعمل حتى لو انطفأ هاتفك\n• نظام ويندوز كامل بتحكم عن بُعد',en:'External computer with extreme specs and 1 Gbps internet.\n\n• Absolute privacy: Work from US or EU servers\n• 24/7 uptime: Runs even if your phone is off\n• Full Windows system with remote control',ru:'Внешний компьютер с экстремальными характеристиками и 1 Гбит/с.\n\n• Абсолютная конфиденциальность: Работа с серверов США/ЕС\n• 24/7 доступность\n• Полная Windows с удалённым управлением'} },
];

const EliteOpsPage: React.FC = () => {
  const { lang, rtl, setCurrentPage, addToCart, cartCount } = useApp();
  const [expandedId, setExpandedId] = useState<string|null>(null);
  const [buyingId, setBuyingId] = useState<string|null>(null);
  const L = (lang==='ar'?'ar':lang==='ru'?'ru':'en') as keyof LP;

  const payI = L==='ar'?`\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع.`:L==='ru'?`\n📝 Оплата:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nПосле оплаты отправьте подтверждение.`:`\n📝 Payment:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nAfter payment send proof.`;

  const handleBuy = (t2: EliteTool) => {
    setBuyingId(t2.id);
    const ol = L==='ar'?'طلب جديد':L==='ru'?'Новый заказ':'New Order';
    const msg = `[🚨 ${ol} - BLACK MART]\n--------------------------------------\n🛠️ ${t2.name[L]}\n💰 ${t2.price}$\n--------------------------------------${payI}\n--------------------------------------\n[SYSTEM_ID: AUTO]`;
    setBuyingId(null);
    showBuyModal(L, msg);
  };

  const handleAddCart = (t2: EliteTool) => {
    addToCart({id:t2.id, name:t2.name[L], price:t2.price, oldPrice:t2.oldPrice, balance:'Tool', image:t2.image, category:'elite-ops'});
    showCartToast(L, cartCount+1);
  };

  return (
    <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
      <div className="px-4 pt-4 flex justify-between items-center">
        <h2 className="text-sm font-black text-neon-gold">⚡ {L==='ar'?'عمليات النخبة':L==='ru'?'Элитные операции':'Elite Operations'}</h2>
        <button onClick={()=>setCurrentPage('home')} className="w-8 h-8 rounded-lg bg-neon-red/10 border border-neon-red/20 text-neon-red flex items-center justify-center text-sm">✕</button>
      </div>

      {/* Go to tools */}
      <div className="px-4 mt-3"><button onClick={()=>setCurrentPage('tools')} className="w-full py-2 bg-neon-blue/8 border border-neon-blue/15 rounded-xl text-neon-blue text-xs font-bold">🛠️ {L==='ar'?'عرض باقي الأدوات':L==='ru'?'Все инструменты':'View All Tools'}</button></div>

      {/* Tools grid */}
      <div className="px-4 mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {tools.map(t2=>(
          <div key={t2.id} className="rounded-xl bg-dark-card overflow-hidden card-hover group" style={{border:'1px solid #ffd70012'}}>
            <div className="relative"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-gold z-10"/><div className="aspect-[3/2] overflow-hidden"><img src={t2.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/></div><div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/></div>
            <div className="p-3">
              <h4 className="text-[12px] font-black text-white mb-1 group-hover:text-neon-gold transition-colors">{t2.name[L]}</h4>
              <p className="text-[9px] text-gray-500 mb-1.5 line-clamp-2">{t2.desc[L]}</p>
              <div className="flex items-center gap-2 mb-2.5"><span className="text-[10px] text-neon-red line-through">${t2.oldPrice}</span><span className="text-base text-neon-green font-black">${t2.price}</span></div>
              <div className="flex gap-1.5">
                <button onClick={()=>setExpandedId(expandedId===t2.id?null:t2.id)} className="flex-1 py-2 text-[9px] font-bold bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700">{expandedId===t2.id?'✕':'ℹ️'} {L==='ar'?'تفاصيل':L==='ru'?'Детали':'Details'}</button>
                <button onClick={()=>handleAddCart(t2)} className="flex-1 py-2 text-[9px] font-bold bg-neon-blue/10 border border-neon-blue/20 text-neon-blue rounded-lg">🛒</button>
                <button onClick={()=>handleBuy(t2)} className="flex-1 py-2 text-[9px] font-bold bg-neon-red/10 border border-neon-red/20 text-neon-red rounded-lg">{buyingId===t2.id?'⏳':L==='ar'?'شراء':L==='ru'?'Купить':'Buy'}</button>
              </div>
              {expandedId===t2.id&&(
                <div className="mt-2 rounded-lg bg-dark-surface border border-neon-gold/10 p-2.5">
                  <div className="space-y-1 max-h-48 overflow-y-auto">{(t2.details[L]||'').replace(/\\n/g,'\n').split('\n').map((l,i)=>{if(!l.trim())return<div key={i} className="h-1.5"/>;const tr=l.trim();const isBullet=/^[•\-▸]/.test(tr);if(isBullet)return<div key={i} className="flex items-start gap-1.5 text-[9px] text-gray-400 leading-[1.6]"><span className="text-neon-gold text-[8px]">▸</span><span>{tr.replace(/^[•\-▸]\s*/,'')}</span></div>;return<p key={i} className="text-[9px] text-gray-400 leading-[1.6]">{tr}</p>;})}</div>
                  <button onClick={()=>setExpandedId(null)} className="w-full mt-2 py-1.5 bg-gray-800 rounded text-gray-500 text-[8px] font-bold">✕ {L==='ar'?'إغلاق':L==='ru'?'Закрыть':'Close'}</button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EliteOpsPage;
