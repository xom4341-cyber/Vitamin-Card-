import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import { showCartToast } from '../utils/cartToast';
import { showSectionBanner } from '../utils/sectionBanner';
import { toolSections, type ToolSection, type ToolProduct } from '../data/tools';

const ToolsPage: React.FC = () => {
  const { t, lang, rtl, setCurrentPage, addToCart, cartCount } = useApp();
  const [selectedSection, setSelectedSection] = useState<ToolSection | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  useEffect(()=>{showSectionBanner(lang);},[]);
  const [buyingId, setBuyingId] = useState<string | null>(null);
  const [expandedTool, setExpandedTool] = useState<string | null>(null);

  const L = lang === 'ar' ? 'ar' : 'en';
  void 0; // TG_LINK removed - using showBuyModal

  const payInfo = `\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.`;

  const handleBuy = (product: ToolProduct) => {
    setBuyingId(product.id);
    const msg = `[🚨 طلب شراء جديد - BLACK MART]\n--------------------------------------\n🛠️ أداة تفريغ\nالأداة: ${product.name}\nالسعر: ${product.price}$\n--------------------------------------${payInfo}\n--------------------------------------\n[SYSTEM_ID: AUTO]`;
    setBuyingId(null);
    showBuyModal(lang, msg);
  };

  const handleAddToCart = (product: ToolProduct) => {
    addToCart({ id: product.id, name: product.name, price: product.price, oldPrice: Math.round(product.price * 1.5), balance: '-', image: product.image, category: 'tools' });
    showCartToast(lang, cartCount + 1);
  };


  // ===== SECTION PRODUCTS =====
  if (selectedSection) {
    return (
      <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
        {/* Section header with image */}
        <div className="relative h-28 overflow-hidden">
          <img src={selectedSection.image} alt="" className="w-full h-full object-cover" /><div className="absolute inset-0 bg-black/60" />
          <div className="absolute bottom-3 left-4 right-4 z-10 flex items-center gap-2">
            <span className="text-2xl">{selectedSection.icon}</span>
            <div><p className="text-sm font-black text-white">{selectedSection.name}</p><p className="text-[10px] text-gray-300">{selectedSection.desc[L]}</p></div>
          </div>
        </div>

        {/* Quick nav - section names */}
        <div className="px-4 pt-3 flex gap-1.5 overflow-x-auto pb-1">
          {toolSections.map(s => (
            <button key={s.id} onClick={() => setSelectedSection(s)} className={`flex-shrink-0 px-2.5 py-1 rounded text-[9px] font-bold transition-all ${selectedSection.id === s.id ? 'bg-neon-blue text-black' : 'bg-dark-surface text-gray-600 border border-gray-800'}`}>{s.name.slice(0, 12)}</button>
          ))}
        </div>

        {/* Back */}
        <div className="px-4 mt-2"><button onClick={() => setSelectedSection(null)} className="text-neon-blue font-bold text-xs">{t('back')}</button></div>

        {/* Products grid */}
        <div className="px-4 mt-3 grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {selectedSection.products.map(product => (
            <div key={product.id} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{ border: `1px solid ${selectedSection.color}15` }}>
              <div className="aspect-[3/2] overflow-hidden relative">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <span className="absolute top-2 left-2 text-lg">{product.icon}</span>
              </div>
              <div className="p-2.5">
                <h4 className="text-[11px] font-bold text-white group-hover:text-neon-blue transition-colors mb-0.5 truncate">{product.name}</h4>
                <p className="text-[9px] text-gray-500 mb-1.5 line-clamp-2 leading-[1.5]">{product.desc[L]}</p>
                <p className="text-neon-red font-black text-sm mb-2">${product.price}</p>
                <div className="flex gap-1">
                  <button onClick={()=>setExpandedTool(expandedTool===product.id?null:product.id)} className="flex-1 py-1.5 text-[9px] font-bold bg-gray-800 text-gray-300 rounded hover:bg-gray-700">{expandedTool===product.id?'✕':'ℹ️'}</button>
                  <button onClick={() => handleAddToCart(product)} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-blue/10 border border-neon-blue/20 text-neon-blue rounded">🛒</button>
                  <button onClick={() => handleBuy(product)} className="flex-1 py-1.5 text-[9px] font-bold bg-neon-red/10 border border-neon-red/20 text-neon-red rounded">{buyingId === product.id ? '⏳' : rtl?'شراء':'Buy'}</button>
                </div>
                {expandedTool===product.id&&(<div className="mt-2 rounded-lg bg-dark-surface border border-neon-blue/10 p-2.5"><p className="text-[10px] text-gray-400 leading-[1.7]">{product.details[L]}</p><button onClick={()=>setExpandedTool(null)} className="w-full mt-2 py-1.5 bg-gray-800 rounded text-gray-500 text-[8px] font-bold">✕ {rtl?'إغلاق':'Close'}</button></div>)}
              </div>
            </div>
          ))}
        </div>
        {/* Section details */}
        <div className="px-4 mt-4">
          <button onClick={()=>setShowExplanation(!showExplanation)} className="w-full py-2.5 rounded-xl bg-dark-card border border-neon-blue/15 text-neon-blue text-xs font-bold">
            {showExplanation?(rtl?'✕ إغلاق التفاصيل':'✕ Close Details'):(rtl?'📋 عرض تفاصيل الأدوات':'📋 Show Tool Details')}
          </button>
          {showExplanation&&(
            <div className="mt-3 space-y-2">
              {selectedSection.products.map((p,i)=>(
                <div key={i} className="rounded-xl bg-dark-card p-3 border border-gray-800/30">
                  <h4 className="text-[11px] font-black text-neon-blue mb-1">{p.icon} {p.name}</h4>
                  <p className="text-[11px] text-gray-300 leading-[1.7]">{p.details[L]}</p>
                  <p className="text-neon-red font-bold text-xs mt-1">${p.price}</p>
                </div>
              ))}
              <button onClick={()=>setShowExplanation(false)} className="w-full py-2 bg-dark-surface border border-gray-800 rounded-xl text-gray-500 text-[10px] font-bold">✕ {rtl?'إغلاق':'Close'}</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ===== MAIN - ALL SECTIONS =====
  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Header */}
      <div className="px-4 pt-4">
        <div className="rounded-xl bg-dark-card overflow-hidden scanline relative" style={{ border: '1px solid #ff004018' }}>
          <div className="h-24 overflow-hidden relative"><img src="https://images.pexels.com/photos/5380603/pexels-photo-5380603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=800" alt="" className="w-full h-full object-cover" /><div className="absolute inset-0 bg-black/65" /></div>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-neon-red/5 border-b border-neon-red/10">
            <div className="flex gap-1"><div className="w-2 h-2 rounded-full bg-neon-red/70" /><div className="w-2 h-2 rounded-full bg-neon-gold/70" /><div className="w-2 h-2 rounded-full bg-neon-green/70" /></div>
            <span className="text-[9px] text-neon-red font-bold" style={{ fontFamily: 'Share Tech Mono,monospace' }}>██ {t('exploit_title')} ██</span>
          </div>
          <div className="p-3"><p className="text-[11px] text-gray-300" style={{ fontFamily: 'Share Tech Mono,monospace' }}>&gt; 10 {rtl ? 'أقسام • 60+ أداة احترافية' : 'sections • 60+ professional tools'}</p></div>
        </div>
      </div>

      {/* Sections grid - 2x2 mobile, 3x3 desktop */}
      <div className="px-4 mt-4 grid grid-cols-2 md:grid-cols-3 gap-2.5">
        {toolSections.map(section => (
          <div key={section.id} onClick={() => setSelectedSection(section)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{ border: `1px solid ${section.color}12` }}>
            <div className="h-20 md:h-24 overflow-hidden relative">
              <img src={section.image} alt={section.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20" />
              <span className="absolute top-2 right-2 text-lg">{section.icon}</span>
              <span className="absolute bottom-2 left-2.5 text-[10px] text-gray-300 font-bold">{section.products.length} {rtl ? 'أداة' : 'tools'}</span>
            </div>
            <div className="p-2.5">
              <h3 className="text-[11px] font-black text-white group-hover:text-neon-blue transition-colors mb-0.5">{section.name}</h3>
              {lang==='ar'&&<p className="text-[8px] text-gray-600 mb-0.5">{section.desc.ar}</p>}
              {lang!=='ar'&&<p className="text-[9px] text-gray-500 mb-2 line-clamp-1">{section.desc[L]}</p>}
              <div className="h-[2px] w-full rounded-full mb-2" style={{ background: `${section.color}30` }} />
              <button className="w-full py-1.5 rounded text-[10px] font-bold" style={{ background: `${section.color}08`, color: section.color, border: `1px solid ${section.color}20` }}>{t('enter')} →</button>
            </div>
          </div>
        ))}
      </div>

      {/* Explanation + Proxy buttons */}
      <div className="px-4 mt-4 space-y-2">
        <button onClick={() => setShowExplanation(!showExplanation)} className="w-full py-2.5 rounded-lg bg-dark-card border border-neon-blue/12 text-xs font-bold text-neon-blue">📖 {showExplanation ? t('close_explanation') : t('show_explanation')}</button>
        <button onClick={() => { setCurrentPage('store'); setTimeout(()=>window.dispatchEvent(new CustomEvent('nav-to',{detail:'proxy'})),100); }} className="w-full py-2.5 rounded-lg bg-dark-card border border-neon-green/12 text-xs font-bold text-neon-green">🔒 {t('tools_go_proxy')}</button>
      </div>

      {showExplanation && (
        <div className="px-4 mt-3 fade-in">
          <div className="rounded-xl bg-dark-card/80 p-4 relative overflow-hidden" style={{ border: '1px solid #00d4ff15', backdropFilter: 'blur(10px)' }}>
            <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/3 to-transparent pointer-events-none" />
            <h3 className="text-sm font-black text-white mb-2 relative">{t('tools_explanation_title')}</h3>
            <p className="text-xs text-gray-400 leading-[1.7] relative">{t('tools_explanation_text')}</p>
            <button onClick={() => setShowExplanation(false)} className="w-full mt-3 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold relative">{t('close_explanation')}</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ToolsPage;
