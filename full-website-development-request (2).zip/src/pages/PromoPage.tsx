import React from 'react';
import { useApp } from '../context/AppContext';

const PromoPage: React.FC = () => {
  const { t, rtl, setCurrentPage } = useApp();

  const prizes = [
    t('promo_prize_1'), t('promo_prize_2'), t('promo_prize_3'), t('promo_prize_4'),
  ];
  const whyUs = [t('promo_why_1'), t('promo_why_2'), t('promo_why_3')];
  const steps = [t('promo_step_1'), t('promo_step_2'), t('promo_step_3'), t('promo_step_4')];

  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      <div className="px-4 pt-4">
        <button onClick={() => setCurrentPage('home')} className="text-neon-blue font-bold text-sm hover:text-white transition-colors">{t('back')}</button>
      </div>

      {/* Title */}
      <div className="px-4 mt-4">
        <div className="rounded-xl bg-dark-card p-5 text-center relative overflow-hidden" style={{ border: '1px solid #00d4ff20' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/3 to-transparent pointer-events-none" />
          <span className="text-4xl block mb-3 relative">🚀</span>
          <h1 className="text-base font-black text-neon-blue mb-2 relative">{t('promo_title')}</h1>
          <p className="text-xs text-gray-400 leading-relaxed relative">{t('promo_intro')}</p>
        </div>
      </div>

      {/* How to start */}
      <div className="px-4 mt-4">
        <div className="rounded-xl neon-border bg-dark-card p-4">
          <h3 className="text-sm font-black text-neon-blue mb-2">{t('promo_how_title')}</h3>
          <p className="text-xs text-gray-400 leading-relaxed">{t('promo_how_text')}</p>
        </div>
      </div>

      {/* Mechanism */}
      <div className="px-4 mt-3">
        <div className="rounded-xl neon-border bg-dark-card p-4">
          <h3 className="text-sm font-black text-neon-blue mb-3">{t('promo_mechanism_title')}</h3>
          <div className="space-y-2">
            {steps.map((step, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-gray-400 p-2 rounded-lg bg-dark-surface border border-gray-800/50">
                <span className="text-neon-blue font-bold mt-0.5">{i + 1}.</span>
                <span className="leading-relaxed">{step}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Commissions */}
      <div className="px-4 mt-3">
        <div className="rounded-xl bg-dark-card p-4" style={{ border: '1px solid #00ff8820' }}>
          <h3 className="text-sm font-black text-neon-green mb-2">{t('promo_commission_title')}</h3>
          <p className="text-xs text-gray-400 leading-relaxed whitespace-pre-line">{t('promo_commission_text')}</p>
        </div>
      </div>

      {/* Contest */}
      <div className="px-4 mt-3">
        <div className="rounded-xl bg-dark-card p-4" style={{ border: '1px solid #ffd70020' }}>
          <h3 className="text-sm font-black text-neon-gold mb-2">{t('promo_contest_title')}</h3>
          <p className="text-xs text-gray-400 mb-3">{t('promo_contest_text')}</p>
          <div className="space-y-2">
            {prizes.map((prize, i) => (
              <div key={i} className="flex items-center p-2.5 rounded-lg bg-dark-surface border border-gray-800/50 text-xs text-white font-bold">{prize}</div>
            ))}
          </div>
        </div>
      </div>

      {/* Why us */}
      <div className="px-4 mt-3">
        <div className="rounded-xl neon-border bg-dark-card p-4">
          <h3 className="text-sm font-black text-neon-blue mb-3">{t('promo_why_title')}</h3>
          <div className="space-y-2">
            {whyUs.map((item, i) => (
              <p key={i} className="text-xs text-gray-400 leading-relaxed">{item}</p>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="px-4 mt-4">
        <p className="text-xs text-gray-400 mb-3 whitespace-pre-line leading-relaxed">{t('promo_cta')}</p>
        <div className="space-y-2">
          <a href="http://t.me/carding2t22?direct" target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/20 border border-neon-red/40 rounded-xl text-center text-neon-red font-black text-sm hover:bg-neon-red/30 transition-all">
            {t('promo_channel_1')}
          </a>
          <a href="https://t.me/Visacardnovbv?direct" target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/20 border border-neon-red/40 rounded-xl text-center text-neon-red font-black text-sm hover:bg-neon-red/30 transition-all">
            {t('promo_channel_2')}
          </a>
        </div>
      </div>

      {/* Back */}
      <div className="px-4 mt-4">
        <button onClick={() => setCurrentPage('home')} className="w-full py-2.5 bg-dark-surface border border-gray-800 rounded-xl text-gray-500 font-bold text-sm hover:text-white transition-all">{t('back')}</button>
      </div>
    </div>
  );
};

export default PromoPage;
