import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const wallets = [
  { id: 'usdt-bsc', currency: 'USDT', icon: '💎', networkKey: 'payment_usdt_bsc_network', address: '0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc', noteKey: 'payment_usdt_bsc_note' },
  { id: 'usdt-trc', currency: 'USDT', icon: '💠', networkKey: 'payment_usdt_trc_network', address: 'TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz', noteKey: 'payment_usdt_trc_note' },
  { id: 'btc', currency: 'BTC', icon: '₿', networkKey: 'payment_btc_network', address: '12Asyis7W7UPzeBWG146b2kkNfS54deHro', noteKey: 'payment_btc_note' },
  { id: 'eth', currency: 'ETH', icon: 'Ξ', networkKey: 'payment_eth_network', address: '0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc', noteKey: '' },
];

const PaymentPage: React.FC = () => {
  const { t, rtl, setCurrentPage } = useApp();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (address: string, id: string) => {
    navigator.clipboard.writeText(address);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const currencyColors: Record<string, string> = { 'USDT': '#26a17b', 'BTC': '#f7931a', 'ETH': '#627eea' };

  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Back button */}
      <div className="px-4 pt-4">
        <button onClick={() => setCurrentPage('home')} className="text-neon-blue font-bold text-sm hover:text-white transition-colors">{t('back')}</button>
      </div>

      {/* Title */}
      <div className="px-4 mt-4">
        <div className="rounded-xl neon-border bg-dark-card p-5 text-center">
          <span className="text-4xl block mb-3">💳</span>
          <h1 className="text-lg font-black text-neon-blue mb-2">{t('payment_page_title')}</h1>
          <p className="text-sm text-gray-400">{t('payment_page_desc')}</p>
          <div className="flex justify-center gap-4 mt-3">
            <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: '#26a17b22', color: '#26a17b', border: '1px solid #26a17b44' }}>USDT</span>
            <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: '#f7931a22', color: '#f7931a', border: '1px solid #f7931a44' }}>Bitcoin</span>
            <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: '#627eea22', color: '#627eea', border: '1px solid #627eea44' }}>Ethereum</span>
          </div>
        </div>
      </div>

      {/* Addresses Title */}
      <div className="px-4 mt-5">
        <h2 className="text-base font-black text-neon-blue mb-3">📋 {t('payment_addresses_title')}</h2>
      </div>

      {/* Wallet Cards */}
      <div className="px-4 space-y-3">
        {wallets.map(w => {
          const color = currencyColors[w.currency] || '#00d4ff';
          return (
            <div key={w.id} className="rounded-xl bg-dark-card p-4 relative overflow-hidden" style={{ border: `1px solid ${color}25` }}>
              <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl" style={{ background: color }} />
              {/* Currency badge */}
              <div className="flex items-center gap-2 mb-3 mt-1">
                <span className="text-2xl">{w.icon}</span>
                <span className="text-sm font-black text-white">{rtl ? 'محفظة' : 'Wallet'} {w.currency}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold ml-auto" style={{ background: `${color}20`, color, border: `1px solid ${color}40` }}>{w.currency}</span>
              </div>
              {/* Network */}
              <div className="mb-2 flex items-center gap-2">
                <span className="text-[10px] text-gray-500 font-bold">{t('payment_network')}:</span>
                <span className="text-xs text-gray-300 font-bold">{t(w.networkKey)}</span>
              </div>
              {/* Address */}
              <div className="mb-2">
                <span className="text-[10px] text-gray-500 font-bold block mb-1">{t('payment_address')}:</span>
                <div className="flex items-center gap-2">
                  <code className="wallet-address flex-1 text-[11px] text-gray-300 bg-black/50 px-3 py-2 rounded-lg font-mono break-all border border-gray-800" style={{ userSelect: 'text' }}>{w.address}</code>
                  <button onClick={() => handleCopy(w.address, w.id)} className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex-shrink-0 ${copiedId === w.id ? 'bg-neon-green/20 text-neon-green border border-neon-green/40' : 'text-white border hover:opacity-80'}`} style={copiedId !== w.id ? { background: `${color}15`, borderColor: `${color}40`, color } : {}}>{copiedId === w.id ? t('copied') : t('copy')}</button>
                </div>
              </div>
              {/* Note */}
              {w.noteKey && <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">{t(w.noteKey)}</p>}
            </div>
          );
        })}
      </div>

      {/* Order Instructions */}
      <div className="px-4 mt-5">
        <div className="rounded-xl neon-border bg-dark-card p-4">
          <h3 className="text-sm font-black text-neon-blue mb-2">{t('payment_order_title')}</h3>
          <p className="text-xs text-gray-400 leading-relaxed">{t('payment_order_text')}</p>
        </div>
      </div>

      {/* Features */}
      <div className="px-4 mt-4">
        <div className="rounded-xl bg-dark-card p-4" style={{ border: '1px solid #00ff8820' }}>
          <h3 className="text-sm font-black text-neon-green mb-3">{t('payment_features_title')}</h3>
          <div className="space-y-2">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="flex items-start gap-2 text-xs text-gray-400">
                <span className="text-neon-green mt-0.5">✓</span>
                <span>{t(`payment_feature_${i}`)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Manager Button */}
      <div className="px-4 mt-5">
        <a href="https://t.me/Visacardnovbv?direct" target="_blank" rel="noopener noreferrer" className="block w-full py-3.5 bg-neon-red/20 border border-neon-red/40 rounded-xl text-center text-neon-red font-black text-base hover:bg-neon-red/30 transition-all">
          {t('go_to_manager')}
        </a>
      </div>

      {/* Back button at bottom */}
      <div className="px-4 mt-4">
        <button onClick={() => setCurrentPage('home')} className="w-full py-2.5 bg-dark-surface border border-gray-800 rounded-xl text-gray-500 font-bold text-sm hover:text-white transition-all">{t('back')}</button>
      </div>
    </div>
  );
};

export default PaymentPage;
