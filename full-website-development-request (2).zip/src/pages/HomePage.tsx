import React from 'react';
import { useApp } from '../context/AppContext';
import CommandCenter from '../components/CommandCenter';

const HomePage: React.FC = () => {
  const { t, rtl, setCurrentPage, setPaymentModalOpen } = useApp();

  const mainCards = [
    { id: 'store', nameKey: 'store_services', descKey: 'store_desc', icon: '🏪', color: '#00d4ff', image: 'https://i.postimg.cc/cJj2zbKX/Screenshot-20260624-145157-Chrome.jpg' },
    { id: 'tools', nameKey: 'tools_section', descKey: 'tools_desc', icon: '🛠️', color: '#ff0040', image: 'https://i.postimg.cc/BbZTBqSb/Screenshot-20260624-144955-Chrome.jpg' },
    { id: 'channels', nameKey: 'channels_section', descKey: 'channels_desc', icon: '💳', color: '#ffd700', image: 'https://i.postimg.cc/1zpDxgXT/Screenshot-20260624-144956-Chrome.jpg' },
    { id: 'guides', nameKey: 'guides_section', descKey: 'guides_desc', icon: '📖', color: '#00ff88', image: 'https://i.postimg.cc/7PQGW1X9/Screenshot-20260624-144959-Chrome.jpg' },
  ];

  return (
    <div className="pb-20" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Command Center */}
      <div className="px-4 pt-4"><CommandCenter /></div>

      {/* Empire Statement */}
      <div className="px-4 mt-5">
        <div className="rounded-xl neon-border bg-dark-card p-5 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/3 to-transparent pointer-events-none" />
          <h2 className="text-neon-blue font-black text-sm md:text-base mb-2 relative">📋 {t('empire_statement')}</h2>
          <p className="text-gray-400 text-xs leading-[1.8] relative whitespace-pre-line">{t('empire_text')}</p>
        </div>
      </div>

      {/* Main Store Card */}
      <div className="px-4 mt-5">
        <div onClick={() => setCurrentPage('store')} className="rounded-xl bg-dark-card border border-neon-blue/15 overflow-hidden card-hover cursor-pointer group relative">
          <div className="h-32 md:h-40 bg-cover bg-center flex items-center justify-center relative" style={{ backgroundImage: 'url(https://i.postimg.cc/cJj2zbKX/Screenshot-20260624-145157-Chrome.jpg)' }}>
            <div className="absolute inset-0 bg-black/40" />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
            <div className="absolute bottom-3 left-4 right-4 z-10">
              <h3 className="text-base md:text-lg font-black text-white group-hover:text-neon-blue transition-colors">{t('store_services')}</h3>
              <p className="text-[11px] text-gray-300 mt-0.5">{t('store_desc')}</p>
            </div>
          </div>
          <div className="p-3"><button className="w-full py-2.5 bg-neon-blue/10 border border-neon-blue/30 rounded-lg text-neon-blue font-black text-sm hover:bg-neon-blue/20 transition-all">{t('enter_store')} →</button></div>
        </div>
      </div>

      {/* 3 Section Cards */}
      <div className="px-4 mt-3 grid grid-cols-3 gap-2.5">
        {mainCards.slice(1).map(card => (
          <div key={card.id} onClick={() => setCurrentPage(card.id)} className="rounded-xl bg-dark-card overflow-hidden card-hover cursor-pointer group" style={{ border: `1px solid ${card.color}15` }}>
            <div className="h-16 md:h-20 overflow-hidden relative"><img src={card.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" /><div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-all" /></div>
            <div className="p-2 text-center">
              <h4 className="text-[10px] md:text-xs font-bold text-white truncate group-hover:text-neon-blue transition-colors mb-1">{t(card.nameKey)}</h4>
              <button className="w-full py-1 rounded text-[9px] font-bold" style={{ background: `${card.color}10`, color: card.color, border: `1px solid ${card.color}25` }}>{t('enter')} →</button>
            </div>
          </div>
        ))}
      </div>

      {/* Featured Sections */}
      <div className="px-4 mt-5 grid grid-cols-3 gap-2">
        {/* 0: Elite Operations */}
        <div onClick={() => setCurrentPage('elite-ops')} className="rounded-xl bg-dark-card p-2.5 card-hover cursor-pointer relative overflow-hidden" style={{ border: '1px solid #ffd70015' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-neon-gold/3 to-transparent pointer-events-none" />
          <h4 className="text-[10px] font-bold text-neon-gold mb-0.5 relative">⚡ {rtl ? 'عمليات النخبة' : 'Elite Ops'}</h4>
          <p className="text-[8px] text-gray-500 mb-1.5 relative">{rtl ? 'أدوات احترافية' : 'Pro Tools'}</p>
          <button className="w-full py-1 bg-neon-gold/10 border border-neon-gold/15 rounded text-neon-gold text-[9px] font-bold relative">{rtl ? 'دخول' : 'Enter'} →</button>
        </div>
        {/* 1: Black Ops Level 5 */}
        <div onClick={() => setCurrentPage('doc-services')} className="rounded-xl bg-dark-card p-3 card-hover cursor-pointer relative overflow-hidden" style={{ border: '1px solid #ff004015' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-neon-red/3 to-transparent pointer-events-none" />
          <h4 className="text-xs font-bold text-neon-red mb-1 relative">☠️ {rtl ? 'العمليات السوداء' : 'Black Ops'}</h4>
          <p className="text-[10px] text-gray-500 mb-2 relative">{rtl ? 'المستوى الخامس — وصول مقيد' : 'Level 5 — Restricted Access'}</p>
          <button className="w-full py-1.5 bg-neon-red/10 border border-neon-red/15 rounded text-neon-red text-[10px] font-bold relative">{rtl ? 'دخول' : 'Enter'} →</button>
        </div>
        {/* 2: Admin & Reports */}
        <div onClick={() => setCurrentPage('admin-reports')} className="rounded-xl bg-dark-card p-3 card-hover cursor-pointer relative overflow-hidden" style={{ border: '1px solid #ff884415' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-neon-red/3 to-transparent pointer-events-none" />
          <h4 className="text-xs font-bold text-neon-red mb-1 relative">🛡️ {rtl ? 'الإدارة والبلاغات' : 'Admin & Reports'}</h4>
          <p className="text-[10px] text-gray-500 mb-2 relative">{rtl ? 'خدمة العملاء، الاسترجاع، والاستبدال' : 'Support, Refunds & Replacements'}</p>
          <button className="w-full py-1.5 bg-neon-red/10 border border-neon-red/15 rounded text-neon-red text-[10px] font-bold relative">{rtl ? 'دخول' : 'Enter'} →</button>
        </div>
      </div>

      {/* ===== ABOUT SECTION - Full detailed ===== */}
      <div className="px-4 mt-6">
        <h2 className="text-neon-blue font-black text-base mb-3">{t('about_site')}</h2>

        {/* Block 1: Welcome */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-3">
          <h3 className="text-sm font-black text-white mb-1">{t('about_title_1')}</h3>
          <p className="text-neon-blue text-xs font-bold mb-2">{t('about_subtitle_1')}</p>
          <p className="text-gray-400 text-xs leading-[1.8]">{t('about_text_1')}</p>
        </div>

        {/* Block 2: What we offer */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-3">
          <h3 className="text-sm font-black text-white mb-2">{t('about_title_2')}</h3>
          <p className="text-gray-400 text-xs leading-[1.8] mb-2">{t('about_text_2')}</p>
          <div className="space-y-2">
            <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/50 text-xs text-gray-400 leading-[1.7]"><span className="text-neon-blue">🏪</span> {t('about_store_text')}</div>
            <div className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/50 text-xs text-gray-400 leading-[1.7]"><span className="text-neon-blue">🛠️</span> {t('about_tools_text')}</div>
          </div>
        </div>

        {/* Block 3: Courses */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-3">
          <h3 className="text-sm font-black text-white mb-2">📚 {t('about_courses_title')}</h3>
          <p className="text-gray-400 text-xs mb-2">{t('about_courses_text')}</p>
          <div className="space-y-1.5">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="flex items-start gap-2 text-xs text-gray-400 p-2 rounded-lg bg-dark-surface border border-gray-800/30">
                <span className="text-neon-green mt-0.5">✓</span>
                <span className="leading-[1.7]">{t(`about_course_${i}`)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Block 4: Security */}
        <div className="rounded-xl bg-dark-card p-4 mb-3" style={{ border: '1px solid #00ff8818' }}>
          <h3 className="text-sm font-black text-neon-green mb-2">🔒 {t('about_security_title')}</h3>
          <p className="text-gray-400 text-xs leading-[1.8]">{t('about_security_text')}</p>
        </div>

        {/* Block 5: Support */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-3">
          <h3 className="text-sm font-black text-white mb-2">🎧 {t('about_support_title')}</h3>
          <p className="text-gray-400 text-xs leading-[1.8]">{t('about_support_text')}</p>
        </div>

        {/* Block 6: Payment */}
        <div className="rounded-xl bg-dark-card p-4 mb-3" style={{ border: '1px solid #ffd70018' }}>
          <h3 className="text-sm font-black text-neon-gold mb-2">💳 {t('about_payment_title')}</h3>
          <p className="text-gray-400 text-xs leading-[1.8]">{t('about_payment_text')}</p>
        </div>

        {/* Block 7: Commitment */}
        <div className="rounded-xl neon-border bg-dark-card p-4 mb-4">
          <p className="text-gray-400 text-xs leading-[1.8] whitespace-pre-line">{t('about_commitment')}</p>
        </div>

        {/* Quick links */}
        <div className="grid grid-cols-4 gap-2 mb-3">
          {mainCards.map(card => (
            <button key={card.id} onClick={() => setCurrentPage(card.id)} className="py-2 bg-dark-surface rounded-lg border border-gray-800 text-center hover:border-neon-blue/30 transition-all group">
              <span className="text-lg block mb-0.5">{card.icon}</span>
              <span className="text-[8px] text-gray-500 font-bold group-hover:text-white transition-colors">{t(card.nameKey).replace(/[🏪🛠️💳📖]/g, '').trim().slice(0, 12)}</span>
            </button>
          ))}
        </div>

        {/* 3 Action buttons */}
        <div className="flex gap-2">
          <button onClick={() => setPaymentModalOpen(true)} className="flex-1 py-2.5 bg-neon-gold/10 border border-neon-gold/20 rounded-lg text-neon-gold text-[11px] font-bold hover:bg-neon-gold/20 transition-all">{t('about_btn_payments')}</button>
          <button onClick={() => { setCurrentPage('store'); setTimeout(()=>window.dispatchEvent(new CustomEvent('nav-to',{detail:'cards-novbv'})),100); }} className="flex-1 py-2.5 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-[11px] font-bold hover:bg-neon-blue/20 transition-all">{t('about_btn_novbv')}</button>
          <a href="http://t.me/carding2t22?direct" target="_blank" rel="noopener noreferrer" className="flex-1 py-2.5 bg-neon-red/10 border border-neon-red/20 rounded-lg text-neon-red text-[11px] font-bold hover:bg-neon-red/20 transition-all text-center">{t('about_btn_contact')}</a>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
