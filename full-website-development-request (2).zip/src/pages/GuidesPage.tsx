import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';

type Section = 'none' | 'about' | 'faq' | 'check' | 'bot' | 'promo';

const GuidesPage: React.FC = () => {
  const { t, lang, rtl, setCurrentPage, setPaymentModalOpen } = useApp();
  const [activeSection, setActiveSection] = useState<Section>('none');

  // Listen for open-bot event from sidebar
  useEffect(() => {
    const handler = () => setActiveSection('bot');
    window.addEventListener('open-bot', handler);
    return () => window.removeEventListener('open-bot', handler);
  }, []);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [shareCount] = useState(() => parseInt(localStorage.getItem('bm_shares') || '0'));
  const [botMessages, setBotMessages] = useState<{role:string;text:string;buttons?:{label:string;action:()=>void}[]}[]>([
    { role: 'bot', text: rtl ? 'مرحباً! أنا المساعد الآلي لـ Black Mart 🤖\nكيف يمكنني مساعدتك؟ اختر من الأزرار أدناه أو اكتب استفسارك:' : 'Hello! I\'m the Black Mart Auto Assistant 🤖\nHow can I help? Choose from buttons below or type your query:' }
  ]);
  const [botInput, setBotInput] = useState('');
  const chatRef = useRef<HTMLDivElement>(null);
  const [infoSlideIdx, setInfoSlideIdx] = useState(0);

  const infoSlides = rtl ? [
    'إرشادات Black Mart: خريطة طريقك للاحتراف',
    '📢 نظام الترويج: انضم واحصل على 10% عمولة',
    '❓ الأسئلة الشائعة: كل ما تحتاج معرفته',
    '🤖 المساعد الآلي: دعم فوري على مدار الساعة',
    '🛠️ أدوات الفحص: ترسانة حصرية للمحترفين',
  ] : [
    'Black Mart Guides: Your roadmap to professionalism',
    '📢 Referral System: Join and earn 10% commission',
    '❓ FAQ: Everything you need to know',
    '🤖 Auto Assistant: 24/7 instant support',
    '🛠️ Check Tools: Exclusive professional arsenal',
  ];

  useEffect(() => {
    const t = setInterval(() => setInfoSlideIdx(p => (p + 1) % infoSlides.length), 4000);
    return () => clearInterval(t);
  }, [infoSlides.length]);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [botMessages]);

  // FAQ data
  const faqs = [
    { q: rtl ? 'ما هو البروكسي (Proxy) ولماذا هو أساس العمل؟' : 'What is a Proxy and why is it essential?', a: rtl ? 'هو هويتك الرقمية الجغرافية. بدون بروكسي مطابق لبيانات الحساب، سيكتشف البنك اختلاف الموقع ويقوم بحظر العملية فوراً. نوفر بروكسيات (Residential SOCKS5) سكنية حقيقية تجعل اتصالك يبدو وكأنه من مودم منزلي محلي.' : 'Your geographic digital identity. Without a matching proxy, the bank detects location mismatch and blocks the operation immediately. We provide Residential SOCKS5 proxies.' },
    { q: rtl ? 'ما الفرق بين البطاقات المحقونة والبطاقات المسحوبة؟' : 'Difference between Injected and Pulled cards?', a: rtl ? 'البطاقات المحقونة: تم حقن بياناتها برمجياً عبر (Protocol 10.1) لتجاوز أنظمة الأمان والربط المباشر ببوابات الدفع.\nالبطاقات المسحوبة: تم استخراج بياناتها عبر عمليات (Data Export) من قواعد بيانات مواقع عالمية، وتأتي ببيانات كاملة جاهزة للاستخدام.' : 'Injected: Data programmatically injected via Protocol 10.1 to bypass security.\nPulled: Data extracted via Data Export from global databases, ready to use.' },
    { q: rtl ? 'ماذا يسلّم مع الخدمات؟' : 'What is delivered with services?', a: rtl ? 'كل خدمة تأتي مع "ملف الخبير" المشفّر، ويشمل: بيانات الدخول، شرح مفصل لطرق الحماية والتشفير، خطوات ربط البطاقات ببوابات الدفع (Apple/Google Pay)، وطريقة تجاوز الأنظمة الأمنية.' : 'Every service comes with the encrypted "Expert File" including: login data, encryption tutorials, card linking steps for Apple/Google Pay, and security bypass methods.' },
    { q: rtl ? 'ما هو الكورس الشامل؟' : 'What is the comprehensive course?', a: rtl ? 'دليلك الاحترافي: يتضمن 7 حلقات تعليمية تشرح (SQL Injection، استخراج البيانات، إسقاط سيرفرات الحماية، بناء برامج فحص البطاقات، والعمل الاحترافي بالبروكسي)، مع نسخة ChatGPT خاصة لمساعدتك.' : 'Professional guide: 7 tutorial episodes covering SQL Injection, data extraction, server bypassing, card checker building, and professional proxy work, with a special ChatGPT copy.' },
    { q: rtl ? 'ما هي الحسابات المستعارة؟' : 'What are alias accounts?', a: rtl ? 'حسابات بنكية أو منصات تداول (مثل Binance/Wise) تم توثيقها بهويات حقيقية (KYC Verified)، ومربوطة ببصمة رقمية وأرقام هواتف افتراضية.' : 'Bank accounts or trading platforms (Binance/Wise) verified with real identities (KYC), linked to digital fingerprints and virtual phone numbers.' },
    { q: rtl ? 'ما هو الفلاش (BTC/USDT Flash)؟' : 'What is Flash (BTC/USDT)?', a: rtl ? 'تقنية مالية متقدمة لتوليد عملات رقمية "فلاش".\n• مدة البقاء: 70 يوماً\n• الاستخدام: التحويلات، الشحن، مواقع الرهان\n• القيود: لا يقبل التداول في المنصات، مخصص لمحافظ TRC20' : 'Advanced financial technology for generating "flash" crypto.\n• Duration: 70 days\n• Use: transfers, top-ups, betting sites\n• Limits: No exchange trading, TRC20 wallets only', warning: rtl ? '📦 خدمة شحن TikTok: لا تترك رصيد الشحن أكثر من 3 ساعات. بادر باستهلاك الرصيد فوراً.\n🎁 بطاقات Binance: العملات قد تكون "غير مغسولة". يجب إجراء عملية (Mixing) لتنظيف العملة.' : '📦 TikTok Top-up: Don\'t leave balance for more than 3 hours.\n🎁 Binance Cards: Crypto may be "unwashed". Perform Mixing to clean coins.' },
    { q: rtl ? 'ما هي المنتجات التي يوفرها Black Mart؟' : 'What products does Black Mart offer?', a: rtl ? 'نوفر ترسانة رقمية تشمل: حسابات بنكية موثقة، بطاقات دفع، أدوات حقن، كورس تعليمي، وخدمات شحن رقمي.' : 'A digital arsenal including: verified bank accounts, payment cards, injection tools, training courses, and digital top-up services.', hasBtn: true },
    { q: rtl ? 'أريد المسؤول عن الودر والتفريغ' : 'I need the Orders & Processing manager', a: rtl ? 'متاح مسؤول متخصص بالودر والتفريغ وسداد المخالفات وسداد الفواتير.' : 'A specialized manager for orders, processing, violations and bill payments is available.', linkBtn: { label: rtl ? 'توجه لمسؤول الودر' : 'Contact Orders Manager', href: 'http://t.me/carding2t22?direct' } },
    { q: rtl ? 'أين خدمة العملاء؟' : 'Where is customer support?', a: rtl ? 'خدمة العملاء متوفرة عبر قنوات التليجرام الرسمية.' : 'Customer support is available via official Telegram channels.', linkBtn: { label: rtl ? 'تواصل مع خدمة العملاء' : 'Contact Support', href: 'https://t.me/Visacardnovbv?direct' } },
    { q: rtl ? 'كيف أشتري الخدمة؟' : 'How do I buy a service?', a: rtl ? 'اختر الخدمة > أضفها للسلة > اضغط زر الشراء > توجه للمسؤول عبر التليجرام > أرسل كود الدفع > استلم خدمتك فوراً.' : 'Choose service > Add to cart > Press buy > Go to Telegram manager > Send payment code > Receive instantly.' },
    { q: rtl ? 'لماذا نحتاج البروكسي؟' : 'Why do we need a Proxy?', a: rtl ? 'هو "مفتاح الأمان" الذي يخفي هويتك ويجعل تحركاتك الرقمية غير قابلة للتتبع؛ بدون بروكسي، أنت مكشوف تماماً.' : 'It\'s the "security key" that hides your identity and makes your digital movements untraceable.' },
  ];

  // Bot knowledge base
  const botKB: {keywords: string[]; answer: string}[] = [
    { keywords: ['بروكسي', 'proxy'], answer: faqs[0].a },
    { keywords: ['محقون', 'مسحوب', 'injected', 'pulled', 'فرق', 'difference'], answer: faqs[1].a },
    { keywords: ['يسلم', 'deliver', 'ملف'], answer: faqs[2].a },
    { keywords: ['كورس', 'course', 'تعليم'], answer: faqs[3].a },
    { keywords: ['مستعار', 'alias', 'حساب بنكي'], answer: faqs[4].a },
    { keywords: ['فلاش', 'flash'], answer: faqs[5].a },
    { keywords: ['منتج', 'product', 'يوفر'], answer: faqs[6].a },
    { keywords: ['شراء', 'buy', 'اشتري', 'كيف'], answer: faqs[9].a },
    { keywords: ['سعر', 'price', 'دفع', 'pay'], answer: rtl ? 'نقبل الدفع بـ USDT, BTC, ETH. اضغط على طرق الدفع لعرض العناوين 💳' : 'We accept USDT, BTC, ETH. Click payment methods to view addresses 💳' },
  ];

  const handleBotSend = () => {
    if (!botInput.trim()) return;
    setBotMessages(p => [...p, { role: 'user', text: botInput }]);
    const q = botInput.toLowerCase();
    setBotInput('');
    setTimeout(() => {
      const match = botKB.find(kb => kb.keywords.some(k => q.includes(k)));
      if (match) {
        setBotMessages(p => [...p, { role: 'bot', text: match.answer }]);
      } else {
        setBotMessages(p => [...p, { role: 'bot', text: rtl ? 'شكراً لاستفسارك! هذا السؤال يحتاج لمسؤول متخصص.' : 'Thanks for your query! This needs a specialized manager.', buttons: [{ label: rtl ? '🎧 مراسلة المسؤول فوراً' : '🎧 Contact Manager Now', action: () => window.open('http://t.me/carding2t22?direct', '_blank') }] }]);
      }
    }, 800);
  };

  // Bot quick buttons
  const botQuickBtns = [
    { label: '💳 ' + (rtl ? 'متجر البطاقات' : 'Card Store'), action: () => setCurrentPage('store') },
    { label: '🛠️ ' + (rtl ? 'أدوات التفريغ' : 'Tools'), action: () => setCurrentPage('tools') },
    { label: '💎 ' + (rtl ? 'فلاش USDT' : 'Flash USDT'), action: () => setCurrentPage('store') },
    { label: '👤 ' + (rtl ? 'حسابات مستعارة' : 'Alias Accounts'), action: () => setCurrentPage('store') },
    { label: '🎁 ' + (rtl ? 'بطاقات الهدايا' : 'Gift Cards'), action: () => setCurrentPage('store') },
    { label: '🌐 ' + (rtl ? 'البروكسي' : 'Proxy'), action: () => setCurrentPage('store') },
    { label: '💳 ' + (rtl ? 'كيف أدفع؟' : 'How to pay?'), action: () => setCurrentPage('channels') },
    { label: '📢 ' + (rtl ? 'قنوات الموقع' : 'Channels'), action: () => setCurrentPage('channels') },
    { label: '🎧 ' + (rtl ? 'خدمة العملاء' : 'Support'), action: () => window.open('https://t.me/Visacardnovbv?direct', '_blank') },
    { label: '🚀 ' + (rtl ? 'كيف أعمل مع Black Mart' : 'Work with us'), action: () => setActiveSection('promo') },
  ];

  const sections = [
    { id: 'about' as Section, icon: '📖', label: rtl ? 'نبذة عن الموقع' : 'About the Site' },
    { id: 'faq' as Section, icon: '❓', label: rtl ? 'الأسئلة الشائعة' : 'FAQ' },
    { id: 'check' as Section, icon: '🛠️', label: rtl ? 'أدوات الفحص' : 'Check Tools' },
    { id: 'bot' as Section, icon: '🤖', label: rtl ? 'الرد الآلي' : 'Auto Reply' },
    { id: 'promo' as Section, icon: '📢', label: rtl ? 'آلية الترويج' : 'Referral' },
  ];

  const closeSection = () => setActiveSection('none');

  // ===== SECTION CONTENT =====
  if (activeSection !== 'none') {
    return (
      <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
        <div className="px-4 pt-4 flex items-center justify-between">
          <button onClick={closeSection} className="text-neon-blue font-bold text-sm">{t('back')}</button>
          <button onClick={closeSection} className="w-7 h-7 rounded bg-neon-red/10 border border-neon-red/20 text-neon-red text-sm flex items-center justify-center">✕</button>
        </div>

        {/* ===== ABOUT ===== */}
        {activeSection === 'about' && (
          <div className="px-4 mt-3 space-y-3">
            <div className="rounded-xl neon-border bg-dark-card p-4"><h3 className="text-sm font-[800] text-white mb-1" style={{lineHeight:'1.6'}}>{rtl ? 'مرحباً بك في Black Mart' : 'Welcome to Black Mart'}</h3><p className="text-neon-blue text-xs font-bold mb-2">{rtl ? 'إمبراطورية التشفير والحقن' : 'Empire of Encryption & Injection'}</p><p className="text-gray-400 text-[13px] font-[700] leading-[1.6]">{rtl ? 'أنت الآن لست مجرد زائر، بل دخلت نطاق الترسانة الرقمية الأكثر حماية وغموضاً. في Black Mart، لا نقدم مجرد خدمات، بل نوفر لك هوية رقمية شبحية تتحرك بثقة بعيداً عن أي رادار.' : 'You are no longer just a visitor — you have entered the most protected digital arsenal.'}</p></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h3 className="text-sm font-[800] text-white mb-2">{rtl ? 'ماذا نقدم؟ منظومة تقنية متكاملة' : 'What do we offer?'}</h3><div className="space-y-2">{[
              { i: '🏪', t: rtl ? 'متجر الخدمات: البطاقات المحقونة، الحسابات المستعارة، بطاقات الهدايا، شحن التطبيقات، بروكسيات الحماية.' : 'Service Store: Injected cards, alias accounts, gift cards, app top-ups, proxies.' },
              { i: '🛠️', t: rtl ? 'أدوات التفريغ والفحص: ترسانة تقنية (Validator Suite, EMV & Logic, Hardware Tools).' : 'Extraction tools: Validator Suite, EMV & Logic, Hardware Tools.' },
            ].map((x,j)=><div key={j} className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30 text-[13px] text-gray-400 font-[700] leading-[1.6]"><span className="text-neon-blue">{x.i}</span> {x.t}</div>)}</div></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h3 className="text-sm font-[800] text-white mb-2">📚 {rtl ? 'الكورسات والشروحات الحصرية:' : 'Exclusive Courses:'}</h3>{[rtl?'تنظيف البيئة الرقمية والبصمات':'Digital environment cleanup',rtl?'إدارة المتصفحات المخفية وتغيير الهوية':'Hidden browser management',rtl?'تقنيات حقن المعلومات والتشفير الشامل':'Info injection & encryption',rtl?'حلول ربط البطاقات بـ Apple Pay و Google Pay':'Card linking to Apple/Google Pay'].map((c,i)=><div key={i} className="flex items-start gap-2 text-[12px] text-gray-400 font-[700] leading-[1.6] p-1.5"><span className="text-neon-green">✓</span>{c}</div>)}</div>
            <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #00ff8815'}}><h3 className="text-sm font-[800] text-neon-green mb-2">🔒 {rtl?'حصانة التشفير وتأكيد الأمان':'Encryption Immunity'}</h3><p className="text-[13px] text-gray-400 font-[700] leading-[1.6]">{rtl?'تلتزم إدارة Black Mart بأقصى معايير الأمن السيبراني؛ حيث يتم تشفير كافة البيانات من طرف إلى طرف ببروتوكولات عسكرية.':'Black Mart management commits to the highest cybersecurity standards with military-grade end-to-end encryption.'}</p></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h3 className="text-sm font-[800] text-white mb-2">🎧 {rtl?'مركز الدعم والاتصال':'Support Center'}</h3><p className="text-[13px] text-gray-400 font-[700] leading-[1.6]">{rtl?'فريقنا متواجد على مدار الساعة خطوة بخطوة.':'Our team is available 24/7 step by step.'}</p></div>
            <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #ffd70015'}}><h3 className="text-sm font-[800] text-neon-gold mb-2">💳 {rtl?'طرق الدفع':'Payment Methods'}</h3><p className="text-[13px] text-gray-400 font-[700] leading-[1.6]">{rtl?'نقبل USDT, Bitcoin, Ethereum عبر TRC20/BSC.':'We accept USDT, Bitcoin, Ethereum via TRC20/BSC.'}</p></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><p className="text-[13px] text-gray-400 font-[700] leading-[1.6]">{rtl?'💡 التزامنا معك: بمجرد اختيار خدمتك، سترافقك شروحاتنا المجانية.':'💡 Our commitment: Free tutorials accompany every service.'}</p></div>
            <div className="flex gap-2">
              <button onClick={()=>setPaymentModalOpen(true)} className="flex-1 py-2.5 bg-neon-gold/10 border border-neon-gold/20 rounded-lg text-neon-gold text-[11px] font-bold">{rtl?'عرض طرق الدفع':'View Payments'}</button>
              <button onClick={()=>{closeSection();setCurrentPage('store');}} className="flex-1 py-2.5 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-[11px] font-bold">{rtl?'البطاقات المحقونة':'Injected Cards'}</button>
              <a href="http://t.me/carding2t22?direct" target="_blank" rel="noopener noreferrer" className="flex-1 py-2.5 bg-neon-red/10 border border-neon-red/20 rounded-lg text-neon-red text-[11px] font-bold text-center">{rtl?'مراسلة المسؤول':'Contact Manager'}</a>
            </div>
          </div>
        )}

        {/* ===== FAQ ===== */}
        {activeSection === 'faq' && (
          <div className="px-4 mt-3 space-y-2">
            {faqs.map((faq, i) => (
              <div key={i} className="rounded-xl bg-dark-card overflow-hidden" style={{border: expandedFaq===i?'1px solid #00d4ff25':'1px solid #1a1a2e'}}>
                <button onClick={()=>setExpandedFaq(expandedFaq===i?null:i)} className="w-full flex items-center justify-between p-3.5 text-start">
                  <span className="text-xs font-bold text-white flex-1">{faq.q}</span>
                  <span className={`text-neon-blue ml-2 transition-transform ${expandedFaq===i?'rotate-45':''}`}>{expandedFaq===i?'−':'+'}</span>
                </button>
                {expandedFaq===i&&(
                  <div className="px-3.5 pb-3.5 fade-in border-t border-gray-800/50 pt-3 space-y-2">
                    <p className="text-[11px] text-gray-400 leading-[1.7] whitespace-pre-line">{faq.a}</p>
                    {(faq as any).warning && <div className="p-2.5 rounded-lg bg-neon-gold/5 border border-neon-gold/20 text-[10px] text-neon-gold leading-[1.7] whitespace-pre-line">{(faq as any).warning}</div>}
                    {(faq as any).hasBtn && <button onClick={()=>{closeSection();setCurrentPage('store');}} className="w-full py-2 bg-neon-red/10 border border-neon-red/20 rounded-lg text-neon-red text-xs font-bold">{rtl?'عرض الأقسام':'View Sections'}</button>}
                    {(faq as any).linkBtn && <a href={(faq as any).linkBtn.href} target="_blank" rel="noopener noreferrer" className="block w-full py-2 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-xs font-bold text-center">{(faq as any).linkBtn.label}</a>}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ===== CHECK TOOLS ===== */}
        {activeSection === 'check' && (
          <div className="px-4 mt-3">
            <div className="rounded-xl bg-dark-card p-5 text-center" style={{border:'1px solid #ff004020'}}>
              <span className="text-5xl block mb-3">🛠️</span>
              <h3 className="text-sm font-black text-white mb-3">{rtl?'أدوات الفحص الحصرية':'Exclusive Check Tools'}</h3>
              {[{en:'Card Checker',ar:'فحص البطاقات'},{en:'Address Checker',ar:'فحص العناوين'},{en:'Data Validator',ar:'فحص البيانات'}].map((tool,i)=>(
                <div key={i} className="mb-3 rounded-lg bg-dark-surface border border-gray-800/50 p-3">
                  <p className="text-xs font-bold text-neon-red mb-0.5">{['🔍','📍','📋'][i]} {tool.en}</p>
                  {lang==='ar'&&<p className="text-[8px] text-gray-500 mb-1">{tool.ar}</p>}
                  <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden mb-2"><div className="h-full bg-gradient-to-r from-neon-red to-neon-red/50 rounded-full" style={{width:`${Math.min(shareCount*5,100)}%`}}/></div>
                  <p className="text-[10px] text-gray-500">{shareCount}/20 {rtl?'زائر':'visitors'}</p>
                </div>
              ))}
              <div className="mt-3 p-3 rounded-lg bg-neon-red/5 border border-neon-red/15">
                <p className="text-[11px] text-neon-red leading-[1.7]">{rtl?'🔒 للوصول إلى ترسانة الفحص، يجب عليك نشر الرابط الخاص بك ودعوة 20 زائراً فريداً.':'🔒 To access the check tools, share your link and invite 20 unique visitors.'}</p>
              </div>
              <button onClick={()=>{if(navigator.share)navigator.share({title:'Black Mart',url:window.location.href});localStorage.setItem('bm_shares',String(shareCount+1));}} className="w-full mt-3 py-2.5 bg-neon-blue/10 border border-neon-blue/20 rounded-lg text-neon-blue text-xs font-bold">📤 {rtl?'مشاركة الرابط الآن':'Share Link Now'}</button>
            </div>
          </div>
        )}

        {/* ===== BOT ===== */}
        {activeSection === 'bot' && (
          <div className="px-4 mt-3">
            <div className="rounded-xl bg-dark-card overflow-hidden" style={{border:'1px solid #00d4ff15'}}>
              <div className="p-3 border-b border-gray-800/50 flex items-center gap-2"><span>🤖</span><span className="text-xs font-bold text-neon-blue">{rtl?'المساعد الآلي':'Auto Assistant'}</span><div className="w-2 h-2 rounded-full bg-neon-green animate-pulse ml-auto"/></div>
              {/* Quick buttons */}
              <div className="p-2 border-b border-gray-800/30 flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
                {botQuickBtns.map((b,i)=><button key={i} onClick={b.action} className="px-2 py-1 bg-neon-blue/5 border border-neon-blue/10 rounded text-[9px] text-neon-blue font-bold hover:bg-neon-blue/10 transition-all">{b.label}</button>)}
              </div>
              {/* Messages */}
              <div ref={chatRef} className="h-52 overflow-y-auto p-3 space-y-2.5">
                {botMessages.map((msg,i)=>(
                  <div key={i} className={`flex ${msg.role==='user'?'justify-end':'justify-start'}`}>
                    <div className={`max-w-[85%] px-3 py-2 rounded-lg text-[11px] leading-[1.6] ${msg.role==='user'?'bg-neon-blue/15 text-white':'bg-dark-surface text-gray-300 border border-gray-800/50'}`}>
                      <span className="whitespace-pre-line">{msg.text}</span>
                      {msg.buttons&&<div className="mt-2 space-y-1">{msg.buttons.map((b,j)=><button key={j} onClick={b.action} className="w-full py-1.5 bg-neon-red/10 border border-neon-red/20 rounded text-neon-red text-[10px] font-bold">{b.label}</button>)}</div>}
                    </div>
                  </div>
                ))}
              </div>
              {/* Input */}
              <div className="p-2.5 border-t border-gray-800/50 flex gap-2">
                <input value={botInput} onChange={e=>setBotInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&handleBotSend()} placeholder={rtl?'اكتب استفسارك...':'Type your query...'} className="flex-1 bg-dark-surface border border-gray-700 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 outline-none focus:border-neon-blue/40"/>
                <button onClick={handleBotSend} className="px-3 py-2 bg-neon-blue/15 border border-neon-blue/30 rounded-lg text-neon-blue font-bold text-sm">📤</button>
              </div>
            </div>
          </div>
        )}

        {/* ===== PROMO ===== */}
        {activeSection === 'promo' && (
          <div className="px-4 mt-3 space-y-3">
            <div className="rounded-xl neon-border bg-dark-card p-4"><h3 className="text-sm font-[800] text-neon-blue mb-2">🚀 {rtl?'انضم إلى فريق نخبة المروجين في BLACK MART 💰':'Join the Elite Promoters Team 💰'}</h3><p className="text-[12px] text-gray-400 font-[700] leading-[1.6]">{rtl?'الآن بإمكان الجميع البدء في جني الأرباح.. سواء كنت مبتدئاً أو محترفاً.':'Everyone can now start earning profits!'}</p></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h4 className="text-xs font-[800] text-neon-blue mb-2">🛠️ {rtl?'كيف تبدأ رحلتك؟':'How to start?'}</h4><p className="text-[11px] text-gray-400 leading-[1.6]">{rtl?'راسل مسؤول القناة واطلب تسجيلك كـ "مروج معتمد".':'Contact the channel manager for registration.'}</p></div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h4 className="text-xs font-[800] text-neon-blue mb-2">🔄 {rtl?'آلية العمل:':'How it works:'}</h4>{[rtl?'1. رابط الهوية: رابط خاص باسمك':'1. Identity Link: Personal link',rtl?'2. مهمتك: نشر في تيك توك، فيسبوك، انستقرام':'2. Your mission: Share on social media',rtl?'3. الربح المباشر: عمولة فورية':'3. Direct profit: Instant commission',rtl?'4. كشف كل 5 أيام':'4. Report every 5 days'].map((s,i)=><div key={i} className="p-2 rounded bg-dark-surface border border-gray-800/30 text-[11px] text-gray-400 leading-[1.6] mb-1.5">{s}</div>)}</div>
            <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #00ff8815'}}><h4 className="text-xs font-[800] text-neon-green mb-2">💸 {rtl?'نظام العمولات:':'Commission System:'}</h4><p className="text-[11px] text-gray-400 leading-[1.6]">{rtl?'عمولة 10% من كل عملية بيع عبر رابطك.':'10% commission on every sale via your link.'}</p></div>
            <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #ffd70015'}}><h4 className="text-xs font-[800] text-neon-gold mb-2">🏆 {rtl?'المنافسة الشهرية:':'Monthly Competition:'}</h4>{[rtl?'🥇 المركز الأول: $500':'🥇 1st: $500',rtl?'🥈 الثاني: $250':'🥈 2nd: $250',rtl?'🥉 الثالث: $100':'🥉 3rd: $100',rtl?'🏅 الرابع والخامس: بطاقة $75':'🏅 4th-5th: $75 card'].map((p,i)=><div key={i} className="p-2 rounded bg-dark-surface text-[11px] text-white font-bold mb-1">{p}</div>)}</div>
            <div className="rounded-xl neon-border bg-dark-card p-4"><h4 className="text-xs font-[800] text-neon-blue mb-2">🛡️ {rtl?'لماذا تعمل معنا؟':'Why work with us?'}</h4>{[rtl?'✅ حقوقك محفوظة':'✅ Rights protected',rtl?'✅ لا سقف للأرباح':'✅ No profit ceiling',rtl?'✅ بدء فوري':'✅ Instant start'].map((w,i)=><p key={i} className="text-[11px] text-gray-400 leading-[1.6] mb-1">{w}</p>)}</div>
            <div className="space-y-2">
              <a href="http://t.me/carding2t22?direct" target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/15 border border-neon-red/30 rounded-xl text-center text-neon-red font-black text-sm">{rtl?'مراسلة القناة 1':'Contact Channel 1'}</a>
              <a href="https://t.me/Visacardnovbv?direct" target="_blank" rel="noopener noreferrer" className="block w-full py-3 bg-neon-red/15 border border-neon-red/30 rounded-xl text-center text-neon-red font-black text-sm">{rtl?'مراسلة القناة 2':'Contact Channel 2'}</a>
            </div>
          </div>
        )}

        {/* Commitment + CTA at bottom */}
        <div className="px-4 mt-5">
          <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #ff004020'}}>
            <p className="text-[12px] text-gray-400 font-[700] leading-[1.6]">{rtl?'💡 التزامنا معك: بمجرد اختيار خدمتك، سنوفر لك شروحات مجانية كاملة. وفي حال واجهت أي مشكلة، فريقنا متواجد لمساعدتك خطوة بخطوة.':'💡 Our commitment: Free tutorials with every service. Our team is available step by step.'}</p>
          </div>
          <button onClick={()=>{closeSection();setCurrentPage('store');}} className="w-full mt-3 py-3 bg-neon-red/15 border border-neon-red/30 rounded-xl text-neon-red font-black text-sm neon-pulse-red">{rtl?'التوجه إلى متجر الخدمات':'Go to Service Store'}</button>
        </div>
      </div>
    );
  }

  // ===== MAIN GUIDES PAGE =====
  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Interactive Info Screen */}
      <div className="px-4 pt-4">
        <div className="rounded-xl bg-dark-card overflow-hidden scanline relative" style={{border:'1px solid #00d4ff15'}}>
          <div className="flex items-center gap-2 px-3 py-2 bg-neon-blue/5 border-b border-neon-blue/10">
            <div className="flex gap-1"><div className="w-2 h-2 rounded-full bg-neon-red/70"/><div className="w-2 h-2 rounded-full bg-neon-gold/70"/><div className="w-2 h-2 rounded-full bg-neon-green/70"/></div>
            <span className="text-[9px] text-neon-blue font-bold" style={{fontFamily:'Share Tech Mono,monospace'}}>GUIDE CENTER</span>
          </div>
          <div className="p-4 min-h-[50px] flex items-center">
            <p className="text-xs text-gray-300 font-bold" style={{fontFamily:'Share Tech Mono,monospace'}}>&gt; {infoSlides[infoSlideIdx]}<span className="typewriter-cursor inline-block w-2 ml-1"/></p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-4 mt-4">
        <div className="relative">
          <input placeholder={rtl?'🔍 بحث في الموقع...':'🔍 Search the site...'} className="w-full bg-dark-card border border-gray-800 rounded-xl px-4 py-3 text-xs text-white placeholder-gray-600 outline-none focus:border-neon-blue/30" onFocus={()=>setActiveSection('bot')}/>
        </div>
      </div>

      {/* Section Grid */}
      <div className="px-4 mt-4 grid grid-cols-2 md:grid-cols-3 gap-2.5">
        {sections.map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)} className="rounded-xl bg-dark-card p-4 text-center card-hover group" style={{border:'1px solid #1a1a2e'}}>
            <span className="text-3xl block mb-2">{s.icon}</span>
            <p className="text-[11px] font-bold text-white group-hover:text-neon-blue transition-colors mb-2">{s.label}</p>
            <span className="inline-block px-3 py-1 bg-neon-red/10 border border-neon-red/20 rounded text-neon-red text-[9px] font-bold">{rtl?'فتح':'Open'}</span>
          </button>
        ))}
      </div>

      {/* Commitment */}
      <div className="px-4 mt-5">
        <div className="rounded-xl bg-dark-card p-4" style={{border:'1px solid #ff004018'}}>
          <p className="text-xs text-gray-400 font-bold leading-[1.6]">{rtl?'💡 التزامنا معك: بمجرد اختيار خدمتك، سنوفر لك شروحات مجانية كاملة.':'💡 Our commitment: Free tutorials with every service.'}</p>
        </div>
        <button onClick={()=>setCurrentPage('store')} className="w-full mt-3 py-3 bg-neon-red/15 border border-neon-red/30 rounded-xl text-neon-red font-black text-sm">{rtl?'التوجه إلى متجر الخدمات':'Go to Service Store'}</button>
      </div>
    </div>
  );
};

export default GuidesPage;
