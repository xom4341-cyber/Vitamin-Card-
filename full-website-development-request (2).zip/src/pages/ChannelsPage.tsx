import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

type Tab = 'none' | 'channels' | 'reps' | 'payment';

const ChannelsPage: React.FC = () => {
  const { t, rtl } = useApp();
  const [activeTab, setActiveTab] = useState<Tab>('none');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (address: string, id: string) => {
    navigator.clipboard.writeText(address);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const channels = [
    { name: 'قناة المعاملات', nameEn: 'Transactions Channel', icon: '📊', link: 'https://t.me/+MF3KPF9PHdZlMWQ0', desc: rtl ? 'توثيق عمليات التسليم' : 'Order delivery documentation' },
    { name: 'مجموعة التجارب والشروحات', nameEn: 'Trials & Tutorials', icon: '🧪', link: 'https://t.me/QrRrut7Ejug0Mzg0', desc: rtl ? 'تجارب العملاء الحية' : 'Live customer experiences' },
    { name: 'قناة الحسابات', nameEn: 'Accounts Channel', icon: '👤', link: 'https://t.me/+XWfDb1uDybY2YTdk', desc: rtl ? 'حسابات وبيانات' : 'Accounts & data' },
    { name: 'قناة فلاش', nameEn: 'Flash Channel', icon: '⚡', link: 'https://t.me/carding2t22', desc: rtl ? 'شروحات السيولة والتحويلات' : 'Liquidity & transfers' },
    { name: 'القناة الاحتياطية', nameEn: 'Backup Channel', icon: '🔄', link: 'https://t.me/+QU1EojtTBQ5jMDI0', desc: rtl ? 'قناة بديلة رسمية' : 'Official backup channel' },
    { name: 'قناة المسابقات', nameEn: 'Contests Channel', icon: '🏆', link: 'https://t.me/Visacardnovbv', desc: rtl ? 'عروض ومكافآت شهرية' : 'Monthly rewards & offers' },
  ];

  const reps = [
    { name: rtl ? 'مسؤول الموقع' : 'Website Manager', icon: '👑', link: 'https://t.me/Track2_1', action: rtl ? '💬 مراسلة' : '💬 Message', role: rtl ? 'الإشراف العام، إدارة الصفقات الكبرى (VIP)، اعتماد المقابلات الشخصية، حل النزاعات، وتلقي الاستفسارات الإدارية العليا.' : 'General supervision, VIP deals, dispute resolution, and administrative inquiries.' },
    { name: rtl ? 'الودر والتفريغ' : 'Orders & Processing', icon: '🛠', link: 'https://t.me/Caesar12R', action: rtl ? '💬 مراسلة' : '💬 Message', role: rtl ? 'خبير العمليات التقنية، تقديم الدعم الفني المتقدم في البرمجيات، إدارة عمليات الحقن (Injection)، شرح أدوات التفريغ، ومساعدة المحترفين في تنفيذ مهامهم البرمجية.' : 'Technical operations expert, advanced software support, injection operations management.' },
    { name: rtl ? 'قناة المراسلة 1' : 'Messaging Channel 1', icon: '💬', link: 'http://t.me/carding2t22?direct', action: rtl ? '💬 مراسلة' : '💬 Message', role: rtl ? 'استقبال الطلبات اليومية، متابعة التحويلات المالية، إرسال بيانات الطلبات بعد الدفع.' : 'Daily order reception, financial transfer follow-up, order data delivery.' },
    { name: rtl ? 'قناة المراسلة 2' : 'Messaging Channel 2', icon: '💬', link: 'https://t.me/Visacardnovbv?direct', action: rtl ? '💬 مراسلة' : '💬 Message', role: rtl ? 'التنسيق السريع لضمان تسليم الخدمة في وقتها.' : 'Quick coordination for timely service delivery.' },
    { name: rtl ? 'البوت' : 'Service Bot', icon: '🤖', link: 'http://t.me/my_trade_data_bot', action: rtl ? '🤖 تشغيل البوت' : '🤖 Launch Bot', role: rtl ? 'تنفيذ الطلبات المؤتمتة، الاستعلام عن توفر المنتجات، الحصول على شروحات فورية.' : 'Automated order execution, product availability queries, instant tutorials.' },
  ];

  const wallets = [
    { id: 'usdt-bsc', currency: 'USDT', icon: '💎', network: 'BSC (BNB Smart Chain (BEP20))', address: '0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc', note: rtl ? 'رسوم تحويل منخفضة' : 'Low transfer fees', color: '#26a17b' },
    { id: 'usdt-trc', currency: 'USDT', icon: '💠', network: 'Tron (TRC20)', address: 'TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz', note: rtl ? '⚠️ تأكد من اختيار الشبكة الصحيحة عند التحويل' : '⚠️ Make sure to select the correct network', color: '#26a17b' },
    { id: 'btc', currency: 'BTC', icon: '₿', network: 'Bitcoin (BTC)', address: '12Asyis7W7UPzeBWG146b2kkNfS54deHro', note: rtl ? '💡 يتم قبول الإيداع من جميع عناوين BTC التي تبدأ بـ "1" و "3" و "bc1p" و "bc1q"' : '💡 Deposits accepted from all BTC addresses starting with "1", "3", "bc1p" and "bc1q"', color: '#f7931a' },
    { id: 'eth', currency: 'ETH', icon: 'Ξ', network: 'Ethereum (ERC20)', address: '0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc', note: '', color: '#627eea' },
  ];

  const tabItems = [
    { id: 'channels' as Tab, label: rtl ? '📡 القنوات الرسمية' : '📡 Official Channels', sub: rtl ? 'استكشف قنواتنا' : 'Explore our channels' },
    { id: 'reps' as Tab, label: rtl ? '🎧 مسؤولو الدعم' : '🎧 Support Team', sub: rtl ? 'تواصل مع المسؤول' : 'Contact Manager' },
    { id: 'payment' as Tab, label: rtl ? '💎 طرق الدفع' : '💎 Payment Methods', sub: rtl ? 'عرض طرق الدفع' : 'View Payment Methods' },
  ];

  return (
    <div className="pb-20 fade-in" style={{ direction: rtl ? 'rtl' : 'ltr' }}>
      {/* Status */}
      <div className="px-4 pt-4 flex items-center gap-2">
        <div className="w-2.5 h-2.5 rounded-full bg-neon-green animate-pulse" />
        <span className="text-xs text-neon-green font-bold">Active / Online</span>
      </div>

      {/* Tab buttons - always visible */}
      <div className="px-4 mt-3 space-y-2.5">
        {tabItems.map(tab => {
          const tabImg = tab.id === 'channels' ? 'https://images.pexels.com/photos/7787446/pexels-photo-7787446.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=600' : tab.id === 'reps' ? 'https://images.pexels.com/photos/7709176/pexels-photo-7709176.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=600' : 'https://images.pexels.com/photos/29968366/pexels-photo-29968366.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=600';
          return (
          <button key={tab.id} onClick={() => setActiveTab(activeTab === tab.id ? 'none' : tab.id)}
            className={`w-full rounded-xl text-start transition-all group overflow-hidden ${activeTab === tab.id ? 'border-neon-blue/30 shadow-[0_0_15px_#00d4ff11]' : 'border-gray-800/50 hover:border-neon-blue/20'}`}
            style={{ border: '1px solid', borderColor: activeTab === tab.id ? '#00d4ff33' : '#222' }}>
            <div className="relative h-16 overflow-hidden">
              <img src={tabImg} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-all" />
              <div className="absolute inset-0 flex items-center justify-between px-4">
                <div>
                  <p className={`text-sm font-black ${activeTab === tab.id ? 'text-neon-blue' : 'text-white'}`}>{tab.label}</p>
                  <p className="text-[10px] text-gray-300 mt-0.5">{tab.sub}</p>
                </div>
                <span className={`px-3 py-1.5 rounded-lg text-[10px] font-bold ${activeTab === tab.id ? 'bg-neon-blue/20 text-neon-blue border border-neon-blue/30' : 'bg-white/10 text-white border border-white/20'}`}>{rtl ? 'دخول' : 'Enter'} →</span>
              </div>
            </div>
          </button>
          );
        })}
      </div>

      {/* ===== CHANNELS CONTENT ===== */}
      {activeTab === 'channels' && (
        <div className="px-4 mt-4 fade-in">
          {/* Channel list */}
          <div className="space-y-2.5">
            {channels.map((ch, i) => (
              <div key={i} className="rounded-xl bg-dark-card border border-gray-800/50 p-3 flex items-center gap-3 group hover:border-neon-blue/20 transition-all">
                <div className="w-10 h-10 rounded-lg bg-neon-blue/5 border border-neon-blue/10 flex items-center justify-center text-xl flex-shrink-0">{ch.icon}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-white">{rtl ? ch.name : ch.nameEn}</p>
                  <p className="text-[10px] text-gray-600 mt-0.5">{ch.desc}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
                  <a href={ch.link} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 bg-neon-blue/10 border border-neon-blue/25 rounded-lg text-neon-blue text-[10px] font-bold hover:bg-neon-blue/20 transition-all">
                    🔗 {rtl ? 'دخول' : 'Enter'}
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Channel explanations */}
          <div className="mt-5 rounded-xl neon-border bg-dark-card p-4">
            <h3 className="text-sm font-black text-neon-blue mb-3">📡 {rtl ? 'قنوات Black Mart الرسمية' : 'Black Mart Official Channels'}</h3>
            <p className="text-[11px] text-gray-500 mb-3">{rtl ? 'بوابتك الموثوقة لمتابعة كافة العمليات والنتائج' : 'Your trusted gateway for tracking all operations'}</p>
            <div className="space-y-2">
              {[
                { icon: '🧪', title: rtl ? 'قناة تجارب العملاء:' : 'Customer Trials Channel:', text: rtl ? 'مخصصة لعرض التوثيقات الحية لتجارب عملائنا في استخدام الخدمات عبر مختلف المتاجر العالمية وبوابات الدفع الدولية.' : 'Dedicated to showcasing live documentation of customer experiences across global stores and payment gateways.' },
                { icon: '✅', title: rtl ? 'قناة المعاملات وتسليم الطلبات:' : 'Transactions & Delivery Channel:', text: rtl ? 'المركز الرئيسي لتوثيق عمليات تسليم الطلبات للعملاء أولاً بأول؛ هنا تتابع صدق ومصداقية التعامل.' : 'Main center for documenting order deliveries to customers in real-time.' },
                { icon: '💸', title: rtl ? 'قناة التحويلات المالية:' : 'Financial Transfers Channel:', text: rtl ? 'مخصصة لشروحات السيولة، آليات التحويل، وتغطية شاملة لكل ما يخص العمليات المالية والمحافظ.' : 'Dedicated to liquidity explanations, transfer mechanisms, and comprehensive financial coverage.' },
                { icon: '🎁', title: rtl ? 'قناة المسابقات والترويج:' : 'Contests & Promotions Channel:', text: rtl ? 'تابع فيها أحدث العروض، المكافآت الشهرية، والمنافسات التي تتيح لك ربح جوائز نقدية وخدمات مجانية.' : 'Follow the latest offers, monthly rewards, and competitions for cash prizes.' },
              ].map((item, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-dark-surface border border-gray-800/30">
                  <p className="text-[11px] text-gray-300 leading-[1.7]"><span className="text-neon-blue font-bold">{item.icon} {item.title}</span> {item.text}</p>
                </div>
              ))}
            </div>
            {/* Security warning */}
            <div className="mt-3 p-3 rounded-lg bg-neon-red/5 border border-neon-red/15">
              <p className="text-[11px] text-neon-red leading-[1.7] font-bold">⚠️ {rtl ? 'تنبيه أمني هام: لا نملك سوى هذه القنوات، وأي حساب يراسلك خارج هذه الروابط هو حساب انتحالي لا علاقة لنا به. دائماً استخدم "بوتات التواصل" المربوطة بكل قناة لضمان حقوقك.' : 'Security Alert: We only own these channels. Any account contacting you outside these links is fraudulent. Always use the bots linked to each channel.'}</p>
            </div>
          </div>

          <button onClick={() => setActiveTab('none')} className="w-full mt-3 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold">{t('back')}</button>
        </div>
      )}

      {/* ===== REPS CONTENT ===== */}
      {activeTab === 'reps' && (
        <div className="px-4 mt-4 fade-in">
          <div className="space-y-2.5">
            {reps.map((rep, i) => (
              <div key={i} className="rounded-xl bg-dark-card border border-gray-800/50 p-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-neon-green/5 border border-neon-green/10 flex items-center justify-center text-xl flex-shrink-0">{rep.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white">{rep.name}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
                    <a href={rep.link} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 bg-neon-green/10 border border-neon-green/25 rounded-lg text-neon-green text-[10px] font-bold hover:bg-neon-green/20 transition-all whitespace-nowrap">{rep.action}</a>
                  </div>
                </div>
                <p className="text-[10px] text-gray-500 leading-[1.6] px-1">{rep.role}</p>
              </div>
            ))}
          </div>

          {/* Role guide */}
          <div className="mt-4 rounded-xl neon-border bg-dark-card p-4">
            <h3 className="text-sm font-black text-neon-blue mb-2">🛡️ {rtl ? 'دليل المهام والواجبات' : 'Role & Responsibility Guide'}</h3>
            <p className="text-[11px] text-gray-500 leading-[1.7]">{rtl ? 'لضمان سرعة خدمتك، يرجى مراسلة المسؤول المختص حسب نوع طلبك.' : 'For fastest service, please contact the appropriate manager for your request type.'}</p>
          </div>

          <button onClick={() => setActiveTab('none')} className="w-full mt-3 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold">{t('back')}</button>
        </div>
      )}

      {/* ===== PAYMENT CONTENT ===== */}
      {activeTab === 'payment' && (
        <div className="px-4 mt-4 fade-in">
          {/* Header */}
          <div className="rounded-xl neon-border bg-dark-card p-4 text-center mb-4">
            <h3 className="text-sm font-black text-neon-gold mb-1">{rtl ? '💳 طرق الدفع المعتمدة للشراء' : '💳 Accepted Payment Methods'}</h3>
            <p className="text-[11px] text-gray-400 mb-2">{rtl ? 'يمكنك الدفع باستخدام العملات الرقمية التالية:' : 'Pay with the following cryptocurrencies:'}</p>
            <div className="flex justify-center gap-3">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: '#26a17b18', color: '#26a17b', border: '1px solid #26a17b33' }}>USDT</span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: '#f7931a18', color: '#f7931a', border: '1px solid #f7931a33' }}>Bitcoin</span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: '#627eea18', color: '#627eea', border: '1px solid #627eea33' }}>Ethereum</span>
            </div>
          </div>

          {/* Wallets */}
          <h4 className="text-xs font-black text-neon-blue mb-2">📋 {rtl ? 'لوحة عناوين الدفع' : 'Payment Address Panel'}</h4>
          <div className="space-y-3">
            {wallets.map(w => (
              <div key={w.id} className="rounded-xl bg-dark-card p-3.5 relative overflow-hidden" style={{ border: `1px solid ${w.color}20`, backdropFilter: 'blur(10px)' }}>
                <div className="absolute top-0 left-0 right-0 h-[2px]" style={{ background: w.color }} />
                <div className="flex items-center gap-2 mb-2 mt-1">
                  <span className="text-xl">{w.icon}</span>
                  <span className="text-xs font-black text-white">{rtl ? 'محفظة' : 'Wallet'} {w.currency}</span>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold ml-auto" style={{ background: `${w.color}15`, color: w.color, border: `1px solid ${w.color}30` }}>{w.currency}</span>
                </div>
                <div className="text-[10px] text-gray-500 mb-1"><span className="font-bold">{rtl ? 'الشبكة:' : 'Network:'}</span> {w.network}</div>
                <div className="text-[10px] text-gray-500 mb-1.5"><span className="font-bold">{rtl ? 'عنوان الإيداع:' : 'Deposit Address:'}</span></div>
                <div className="flex items-center gap-2">
                  <code className="wallet-address flex-1 text-[10px] text-gray-300 bg-black/50 px-2.5 py-2 rounded-lg font-mono break-all border border-gray-800/50" style={{ userSelect: 'text' }}>{w.address}</code>
                  <button onClick={() => handleCopy(w.address, w.id)} className={`px-2.5 py-2 rounded-lg text-[10px] font-bold transition-all flex-shrink-0 ${copiedId === w.id ? 'bg-neon-green/20 text-neon-green border border-neon-green/30' : 'bg-gray-800 text-gray-400 border border-gray-700 hover:text-white'}`}>{copiedId === w.id ? '✓' : '📋'}</button>
                </div>
                {w.note && <p className="text-[9px] text-gray-600 mt-2 leading-relaxed">{w.note}</p>}
              </div>
            ))}
          </div>

          {/* Instructions */}
          <div className="mt-4 rounded-xl neon-border bg-dark-card p-4">
            <h4 className="text-xs font-black text-neon-blue mb-2">📝 {rtl ? 'تعليمات إتمام الطلب' : 'Order Completion Instructions'}</h4>
            <p className="text-[11px] text-gray-400 leading-[1.7]">{rtl ? 'بعد الدفع، قم بإرسال دليل الدفع لأحد مسؤولي الموقع أو عبر مراسلة القنوات الرسمية، وسيتم إرسال الطلب إليك تلقائياً' : 'After payment, send proof to a site manager or via official channels.'}</p>
          </div>

          {/* Features */}
          <div className="mt-3 rounded-xl bg-dark-card p-4" style={{ border: '1px solid #00ff8815' }}>
            <h4 className="text-xs font-black text-neon-green mb-2">🛡️ {rtl ? 'المميزات المرفقة مع الخدمة' : 'Service Features'}</h4>
            <div className="space-y-1.5">
              {(rtl ? [
                'طرق الحماية والتشفير المتقدمة: تأمين العمليات والبيانات بأحدث أساليب التشفير',
                'ربط البطاقات والحقن: شرح آليات ربط البطاقات وحقن المعلومات عبر جميع بوابات الدفع العالمية',
                'بوابات الدفع الذكية: شروحات احترافية خاصة بـ Apple Pay و Google Play',
                'تجاوز الأنظمة: طرق تخطي الحماية والحقن المباشر لمعلومات البطاقة لضمان نجاح العملية',
              ] : [
                'Advanced encryption methods for securing operations and data',
                'Card linking & injection via all global payment gateways',
                'Smart payment gateway tutorials for Apple Pay & Google Play',
                'System bypass methods for direct card info injection',
              ]).map((f, i) => (
                <div key={i} className="flex items-start gap-2 text-[11px] text-gray-400 p-2 rounded bg-dark-surface"><span className="text-neon-green">✓</span><span className="leading-[1.6]">{f}</span></div>
              ))}
            </div>
          </div>

          {/* Contact Manager */}
          <a href="https://t.me/Visacardnovbv?direct" target="_blank" rel="noopener noreferrer" className="block w-full mt-4 py-3 bg-neon-red/15 border border-neon-red/30 rounded-xl text-center text-neon-red font-black text-sm hover:bg-neon-red/25 transition-all">
            🚀 {rtl ? 'توجه للمسؤول لإتمام الطلب' : 'Contact Manager to Complete Order'}
          </a>

          <button onClick={() => setActiveTab('none')} className="w-full mt-3 py-2 bg-dark-surface border border-gray-800 rounded-lg text-gray-500 text-xs font-bold">{t('back')}</button>
        </div>
      )}
    </div>
  );
};

export default ChannelsPage;
