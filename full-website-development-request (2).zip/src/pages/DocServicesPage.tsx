import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { showBuyModal } from '../utils/buyModal';
import { showCartToast } from '../utils/cartToast';

// TG moved to buyModal.ts

interface LP { ar:string; en:string; ru:string; }
interface BlackProduct { id:string; name:LP; balance:string; price:number; oldPrice:number; desc:LP; image:string; details:LP; msgType:LP; }

const payI = (L:string) => L==='ar'
  ? `\n📝 الدفع عبر:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nبعد الدفع أرسل دليل الدفع وسيتم التسليم تلقائياً.`
  : L==='ru'
  ? `\n📝 Оплата:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nПосле оплаты отправьте подтверждение.`
  : `\n📝 Payment via:\nUSDT(BSC): 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nUSDT(TRC20): TKVQo16sxRrcGtGbwd8GMz1ULPoHyH8WAz\nBTC: 12Asyis7W7UPzeBWG146b2kkNfS54deHro\nETH: 0xe9601dcc092587a4ea4e4ac3c1df3a31995d0bfc\nAfter payment, send proof and your order will be delivered.`;

const t3 = (ar:string,en:string,ru:string):LP => ({ar,en,ru});

const products: BlackProduct[] = [
  { id:'bp1', name:t3('بطاقة NON-VBV CC محقونة','Injected NON-VBV CC Card','Инъектированная карта NON-VBV CC'), balance:'$10,000', price:499, oldPrice:580, image:'https://i.postimg.cc/7Z5bm7Kp/Screenshot-20260706-001605-Gallery.jpg', msgType:t3('💳 بطاقة محقونة','💳 Injected Card','💳 Инъектированная карта'),
    desc:t3('بطاقات Visa/MasterCard محقونة لتجاوز OTP والسحب المباشر مع بيانات كاملة Fullz','Visa/MasterCard injected cards bypassing OTP for direct withdrawal with complete Fullz data','Инъектированные карты Visa/MasterCard для обхода OTP с полными данными Fullz'),
    details:t3('بطاقات Visa & MasterCard بنظام NOVBV\\n• النوع: بدون تحقق ثنائي\\n• المصدر: يتم فتحها يدوياً\\n• الرصيد: محقونة بأرصدة حقيقية\\n• الأمان: آمنة من البلاغات\\n• التسليم: بكامل البيانات مع شروحات\\n\\n[ 👤 البيانات الشخصية ]\\n• الاسم: J*** S****\\n• SSN: ***-**-1234\\n• البريد: j***@*****.com\\n\\n[ 💳 بيانات البطاقة ]\\n• الرقم: **** **** **** 4567\\n• CVV: *** | النوع: Credit Platinum\\n\\n[ 📍 العنوان ]\\n• الدولة: United States','Visa & MasterCard NOVBV System\\n• Type: No 3D Secure/OTP\\n• Source: Manually opened\\n• Balance: Injected with real funds\\n• Security: Safe from chargebacks\\n• Delivery: Complete Fullz with tutorials\\n\\n[ 👤 Personal Data ]\\n• Name: J*** S****\\n• SSN: ***-**-1234\\n\\n[ 💳 Card Data ]\\n• Number: **** **** **** 4567\\n• CVV: *** | Type: Credit Platinum\\n\\n[ 📍 Address ]\\n• Country: United States','Система NOVBV Visa & MasterCard\\n• Тип: Без 3D Secure/OTP\\n• Баланс: Реальные средства\\n• Безопасность: Защита от возвратов\\n• Доставка: Полные данные Fullz') },
  { id:'bp2', name:t3('بطاقة American Express 10.1 محقونة','Injected AMEX 10.1 Card','Инъектированная карта AMEX 10.1'), balance:'$7,000', price:599, oldPrice:900, image:'https://i.postimg.cc/yY23MQNy/images-(31).jpg', msgType:t3('💳 بطاقة AMEX محقونة','💳 Injected AMEX Card','💳 Инъектированная карта AMEX'),
    desc:t3('بطاقات AMEX محقونة بروتوكول 10.1 مع بيانات تطبيق كاملة','AMEX Protocol 10.1 injected cards with full app credentials','Инъектированные карты AMEX протокол 10.1 с данными приложения'),
    details:t3('بطاقات AMEX بروتوكول 10.1\\n• تقنية NFC\\n• بيانات الإصدار: USA-840\\n• بيانات البطاقة مشوشة\\n• بيانات الدخول للتطبيق\\n• كورس تهيئة + دليل ربط + Cashout','AMEX Protocol 10.1\\n• NFC Technology\\n• Issuer: USA-840\\n• Blurred card data\\n• App login credentials\\n• Setup course + linking guide + Cashout','AMEX Протокол 10.1\\n• Технология NFC\\n• Эмитент: USA-840\\n• Данные карты + приложения\\n• Курс настройки + Cashout') },
  { id:'bp3', name:t3('حساب PayPal محقون','Injected PayPal Account','Инъектированный аккаунт PayPal'), balance:'$5,000', price:600, oldPrice:750, image:'https://i.postimg.cc/26js7NgP/images-(32).jpg', msgType:t3('💰 حساب PayPal','💰 PayPal Account','💰 Аккаунт PayPal'),
    desc:t3('حسابات PayPal محقونة مع كامل البيانات تم فتحها يدوياً','Injected PayPal accounts with complete data, manually opened','Инъектированные аккаунты PayPal с полными данными'),
    details:t3('[ 👤 بيانات الحساب ]\\n• البريد: u****@email.com\\n• الحالة: Verified\\n• البطاقة: Visa **** 4242\\n\\n📦 ملحقات:\\n• دليل الدخول الآمن\\n• إدارة الحساب\\n• تشفير الحماية','[ 👤 Account Data ]\\n• Email: u****@email.com\\n• Status: Verified\\n• Card: Visa **** 4242\\n\\n📦 Attachments:\\n• Safe login guide\\n• Account management\\n• Protection encryption','[ 👤 Данные ]\\n• Почта: u****@email.com\\n• Статус: Verified\\n• Карта: Visa **** 4242\\n\\n📦 Приложения:\\n• Безопасный вход\\n• Управление аккаунтом') },
  { id:'bp4', name:t3('تحويل بنكي SWIFT','Bank Wire SWIFT','Банковский перевод SWIFT'), balance:'$5,000', price:1000, oldPrice:1200, image:'https://i.postimg.cc/7YgMNJDW/Screenshot-20260624-040807-Chrome.jpg', msgType:t3('💸 تحويل بنكي','💸 Bank Wire','💸 Банковский перевод'),
    desc:t3('تحويلات بنكية دولية SWIFT/SEPA حوالة نظيفة','International SWIFT/SEPA bank wire clean transfer','Международный SWIFT/SEPA перевод'),
    details:t3('بروتوكول التحويل البنكي\\n• التغطية: كافة البنوك\\n• السرية: طبقات متعددة\\n• الضمان: حوالة بديلة فورية','Bank wire protocol\\n• Coverage: All banks\\n• Secrecy: Multi-layer\\n• Guarantee: Instant alternative','Протокол перевода\\n• Покрытие: Все банки\\n• Секретность: Многоуровневая\\n• Гарантия: Мгновенная замена') },
  { id:'bp5', name:t3('Flash USDT','Flash USDT','Flash USDT'), balance:'5,000 USDT', price:250, oldPrice:500, image:'https://i.postimg.cc/W3kJbx18/231013-Blog-What-Is-Tether-USDT.webp', msgType:t3('⚡ Flash USDT','⚡ Flash USDT','⚡ Flash USDT'),
    desc:t3('شحن USDT فوري للمحفظة أو منصة التداول','Instant USDT top-up to wallet or exchange','Мгновенное пополнение USDT'),
    details:t3('• شبكات: TRC20/BEP20\\n• صلاحية: 70 يوماً\\n• غير قابل للتداول في CEX/P2P','• Networks: TRC20/BEP20\\n• Validity: 70 days\\n• Not tradable on CEX/P2P','• Сети: TRC20/BEP20\\n• Срок: 70 дней\\n• Не торгуется на CEX/P2P') },
  { id:'bp6', name:t3('حساب Shopify Store','Shopify Store Account','Аккаунт Shopify Store'), balance:'Active', price:250, oldPrice:400, image:'https://i.postimg.cc/hPs3MmPG/images-(36).jpg', msgType:t3('🏪 حساب Shopify','🏪 Shopify Account','🏪 Аккаунт Shopify'),
    desc:t3('متجر Shopify مفعل مع بوابات دفع مدمجة','Active Shopify store with integrated payment gateways','Активный магазин Shopify с платёжными шлюзами'),
    details:t3('• توثيق كامل KYC\\n• نشاط مسبق\\n• دليل تغيير الإعدادات','• Full KYC verification\\n• Previous activity\\n• Settings change guide','• Полная верификация KYC\\n• Предыдущая активность\\n• Руководство по настройке') },
  { id:'bp7', name:t3('بطاقات Binance','Binance Gift Cards','Карты Binance'), balance:'$500', price:170, oldPrice:500, image:'https://i.postimg.cc/d0G4gZmk/images.png', msgType:t3('🎁 بطاقة Binance','🎁 Binance Card','🎁 Карта Binance'),
    desc:t3('أكواد بطاقات هدايا Binance مضمونة 100%','Binance gift card codes 100% guaranteed','Коды подарочных карт Binance 100% гарантия'),
    details:t3('بروتوكول الخلاط الرقمي:\\n• سحب الكود\\n• تبديل USDT→BTC\\n• نقل لـ Trust Wallet\\n• تحويل BTC→USDT\\n• بيع P2P','Digital mixer protocol:\\n• Redeem code\\n• Swap USDT→BTC\\n• Transfer to Trust Wallet\\n• Convert BTC→USDT\\n• P2P sell','Протокол микшера:\\n• Активация кода\\n• Обмен USDT→BTC\\n• Перевод в Trust Wallet\\n• Конвертация BTC→USDT\\n• Продажа P2P') },
  { id:'bp8', name:t3('بطاقات Apple/iTunes','Apple/iTunes Cards','Карты Apple/iTunes'), balance:'$500', price:280, oldPrice:500, image:'https://i.postimg.cc/Wz59XR6R/e9cdd1eb980a9c3a090a94008f4bdf360cf988a86158c35fae8b2d505c09e82c.jpg', msgType:t3('🎁 بطاقة Apple','🎁 Apple Card','🎁 Карта Apple'),
    desc:t3('أكواد Apple/iTunes مضمونة 100%','Apple/iTunes codes 100% guaranteed','Коды Apple/iTunes 100% гарантия'),
    details:t3('• اشحن فوراً\\n• لا تترك الكود أكثر من 24 ساعة\\n• صالح للمتجر الأمريكي/الدولي','• Redeem immediately\\n• Don\'t leave code more than 24h\\n• Valid for US/International store','• Активируйте сразу\\n• Не оставляйте код более 24ч\\n• Действителен для US/международного магазина') },
  { id:'bp9', name:t3('بطاقات Amazon','Amazon Cards','Карты Amazon'), balance:'$300', price:170, oldPrice:300, image:'https://i.postimg.cc/FH76CKBq/images-(1).png', msgType:t3('🎁 بطاقة Amazon','🎁 Amazon Card','🎁 Карта Amazon'),
    desc:t3('أكواد Amazon مضمونة 100%','Amazon codes 100% guaranteed','Коды Amazon 100% гарантия'),
    details:t3('• للاستخدام المباشر فقط\\n• يُمنع شراء بطاقات أخرى\\n• اشحن خلال 24 ساعة','• Direct use only\\n• Don\'t buy other cards\\n• Redeem within 24h','• Только прямое использование\\n• Не покупайте другие карты\\n• Активируйте в течение 24ч') },
  { id:'bp10', name:t3('شحن TikTok 500K','TikTok 500K Top-up','Пополнение TikTok 500K'), balance:'500K', price:499, oldPrice:800, image:'https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg', msgType:t3('🎵 شحن TikTok','🎵 TikTok Top-up','🎵 Пополнение TikTok'),
    desc:t3('شحن التطبيقات عبر البطاقات المحقونة','App top-up via injected cards','Пополнение через инъектированные карты'),
    details:t3('⚠️ تنبيه أمني:\\n• استخدم حساب جديد\\n• لا تترك الرصيد أكثر من 3 ساعات\\n• أي بلاغ = حظر نهائي','⚠️ Security notice:\\n• Use a new account\\n• Don\'t leave balance more than 3h\\n• Any report = permanent ban','⚠️ Предупреждение:\\n• Используйте новый аккаунт\\n• Не оставляйте баланс более 3ч\\n• Любая жалоба = вечный бан') },
  { id:'bp11', name:t3('شحن Jaco 500K','Jaco 500K Top-up','Пополнение Jaco 500K'), balance:'500K', price:699, oldPrice:900, image:'https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg', msgType:t3('🟣 شحن Jaco','🟣 Jaco Top-up','🟣 Пополнение Jaco'),
    desc:t3('شحن التطبيقات عبر البطاقات المحقونة','App top-up via injected cards','Пополнение через инъектированные карты'),
    details:t3('⚠️ تنبيه أمني:\\n• استخدم حساب جديد\\n• لا تترك الرصيد أكثر من 3 ساعات\\n• أي بلاغ = حظر نهائي','⚠️ Security notice:\\n• Use a new account\\n• Don\'t leave balance more than 3h\\n• Any report = permanent ban','⚠️ Предупреждение:\\n• Используйте новый аккаунт\\n• Не оставляйте более 3ч') },
  { id:'bp12', name:t3('بروكسي PROXY 30 يوم','PROXY 30 Days','PROXY 30 дней'), balance:'30d', price:150, oldPrice:250, image:'https://i.postimg.cc/QB2M27Bq/image.png', msgType:t3('🔒 بروكسي','🔒 Proxy','🔒 Прокси'),
    desc:t3('بروكسي سكني مشفر لتجاوز أنظمة الحماية','Encrypted residential proxy for bypassing security','Зашифрованный резидентный прокси'),
    details:t3('ما هو البروكسي؟\\n• كسر جدار الحماية\\n• تطابق سكني حقيقي\\n• منع تسريب البصمة\\n⚠️ بدون بروكسي النظام سيغلق العملية','What is Proxy?\\n• Bypass geo-lock\\n• Real residential matching\\n• Prevent fingerprint leaks\\n⚠️ Without proxy the system will block the operation','Что такое Прокси?\\n• Обход гео-блокировки\\n• Резидентное совпадение\\n• Защита отпечатков\\n⚠️ Без прокси система заблокирует операцию') },
  { id:'bp13', name:t3('كورس التفريغ الشامل','Comprehensive Extraction Course','Полный курс извлечения'), balance:'Course', price:100, oldPrice:250, image:'https://i.postimg.cc/N9x5RMM4/image.png', msgType:t3('🎓 كورس تفريغ','🎓 Extraction Course','🎓 Курс извлечения'),
    desc:t3('مسار تقني متقدم: اختراق + تجاوز + أتمتة','Advanced technical path: hacking + bypass + automation','Продвинутый путь: взлом + обход + автоматизация'),
    details:t3('• حقن قواعد البيانات SQL\\n• استخراج البيانات\\n• تعطيل OTP\\n• برامج تجربة الكروت\\n• ربط البروكسي\\n• حزمة أدوات كاملة\\n• ChatGPT غير مقيد','• SQL Injection\\n• Data extraction\\n• OTP disable\\n• Card testing programs\\n• Proxy setup\\n• Complete toolkit\\n• Unrestricted ChatGPT','• SQL Инъекции\\n• Извлечение данных\\n• Отключение OTP\\n• Программы тестирования карт\\n• Настройка прокси\\n• Полный набор инструментов\\n• ChatGPT без ограничений') },
  { id:'bp14', name:t3('هويات مستعارة','Fake Identities','Поддельные документы'), balance:'Custom', price:99, oldPrice:200, image:'https://i.postimg.cc/90QnyWcL/Screenshot-20260706-000530-Gallery.jpg', msgType:t3('📄 هوية مستعارة','📄 Fake Identity','📄 Поддельный документ'),
    desc:t3('هويات جوازات رخص مستندات مستعارة للتوثيق','IDs passports licenses for verification operations','Документы паспорта лицензии для верификации'),
    details:t3('تقنيات تزييف عالية الدقة:\\n• العلامات المائية MRZ\\n• جودة لا يمكن كشفها\\n• هويات وطنية، رخص، جوازات','High-precision forgery:\\n• MRZ watermarks\\n• Undetectable quality\\n• National IDs, licenses, passports','Высокоточная подделка:\\n• Водяные знаки MRZ\\n• Необнаруживаемое качество\\n• Удостоверения, лицензии, паспорта') },
];

const DocServicesPage: React.FC = () => {
  const { lang, rtl, setCurrentPage, addToCart, cartCount, setPaymentModalOpen } = useApp();
  const [expandedId, setExpandedId] = useState<string|null>(null);
  const [buyingId, setBuyingId] = useState<string|null>(null);
  const L = (lang==='ar'?'ar':lang==='ru'?'ru':'en') as keyof LP;

  const orderLabel = L==='ar'?'طلب شراء جديد':L==='ru'?'Новый заказ':'New Purchase Order';
  const serviceLabel = L==='ar'?'الخدمة':L==='ru'?'Услуга':'Service';
  const balLabel = L==='ar'?'الرصيد':L==='ru'?'Баланс':'Balance';
  const priceLabel = L==='ar'?'السعر':L==='ru'?'Цена':'Price';

  const handleBuy = (p: BlackProduct) => {
    setBuyingId(p.id);
    const msg = `[🚨 ${orderLabel} - BLACK MART]\n--------------------------------------\n${p.msgType[L]}\n${serviceLabel}: ${p.name[L]}\n${balLabel}: ${p.balance}\n${priceLabel}: ${p.price}$\n--------------------------------------${payI(L)}\n--------------------------------------\n[SYSTEM_ID: AUTO]`;
    setBuyingId(null);
    showBuyModal(L, msg);
  };

  const handleAddCart = (p: BlackProduct) => {
    addToCart({id:p.id,name:p.name[L],price:p.price,oldPrice:p.oldPrice,balance:p.balance,image:p.image,category:'blackops'});
    showCartToast(L, cartCount + 1);
  };

  return (
    <div className="pb-20 fade-in" style={{direction:rtl?'rtl':'ltr'}}>
      <div className="px-4 pt-4 flex justify-between items-center">
        <h2 className="text-sm font-black text-neon-red">☠️ {L==='ar'?'العمليات السوداء':L==='ru'?'Чёрные операции':'Black Ops'}</h2>
        <button onClick={()=>setCurrentPage('home')} className="w-8 h-8 rounded-lg bg-neon-red/10 border border-neon-red/20 text-neon-red flex items-center justify-center text-sm">✕</button>
      </div>
      <div className="px-4 mt-3"><button onClick={()=>setCurrentPage('store')} className="w-full py-2 bg-neon-blue/8 border border-neon-blue/15 rounded-xl text-neon-blue text-xs font-bold">🏪 {L==='ar'?'عرض كل الخدمات':L==='ru'?'Все услуги':'View All Services'}</button></div>
      <div className="px-4 mt-2"><button onClick={()=>setPaymentModalOpen(true)} className="w-full py-2 bg-neon-gold/8 border border-neon-gold/15 rounded-xl text-neon-gold text-xs font-bold">💠 {L==='ar'?'طرق الدفع المعتمدة':L==='ru'?'Способы оплаты':'Payment Methods'}</button></div>

      <div className="px-4 mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {products.map(p=>(
          <div key={p.id} className="rounded-xl bg-dark-card overflow-hidden card-hover group" style={{border:'1px solid #ff004012'}}>
            <div className="relative"><div className="absolute top-0 left-0 right-0 h-[3px] bg-neon-red z-10"/><div className="aspect-[3/2] overflow-hidden"><img src={p.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/></div><div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/></div>
            <div className="p-3">
              <h4 className="text-[12px] font-black text-white mb-1 group-hover:text-neon-red transition-colors">{p.name[L]}</h4>
              <p className="text-[9px] text-gray-500 mb-1.5 line-clamp-2">{p.desc[L]}</p>
              <p className="text-[10px] text-neon-green font-bold mb-0.5">🟢 {p.balance}</p>
              <div className="flex items-center gap-2 mb-2.5"><span className="text-[10px] text-neon-red line-through">${p.oldPrice}</span><span className="text-base text-neon-green font-black">${p.price}</span></div>
              <div className="flex gap-1.5">
                <button onClick={()=>setExpandedId(expandedId===p.id?null:p.id)} className="flex-1 py-2 text-[9px] font-bold bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700">{expandedId===p.id?'✕':'ℹ️'} {L==='ar'?'تفاصيل':L==='ru'?'Детали':'Details'}</button>
                <button onClick={()=>handleAddCart(p)} className="flex-1 py-2 text-[9px] font-bold bg-neon-blue/10 border border-neon-blue/20 text-neon-blue rounded-lg">🛒</button>
                <button onClick={()=>handleBuy(p)} className="flex-1 py-2 text-[9px] font-bold bg-neon-red/10 border border-neon-red/20 text-neon-red rounded-lg">{buyingId===p.id?'⏳':L==='ar'?'شراء':L==='ru'?'Купить':'Buy'}</button>
              </div>
              {expandedId===p.id&&(
                <div className="mt-2 rounded-lg bg-dark-surface border border-neon-red/10 p-2.5">
                  <div className="space-y-1 max-h-48 overflow-y-auto">{(p.details[L]||'').replace(/\\n/g,'\n').split('\n').map((l,i)=>{if(!l.trim())return<div key={i} className="h-1.5"/>;const tr=l.trim();const isBullet=/^[•\-▸]/.test(tr);const isHead=/^\[|^🔹|^🔒|^💳|^👤|^📍|^🖥|^📦|^⚠/.test(tr);const blur=/\*{3,}/.test(tr);if(isHead)return<h4 key={i} className="text-[9px] font-black text-neon-blue mt-1.5 pt-1 border-t border-gray-800/30">{tr}</h4>;if(isBullet)return<div key={i} className="flex items-start gap-1.5 text-[9px] text-gray-400 leading-[1.6]"><span className="text-neon-blue text-[8px]">▸</span><span className={blur?'blur-[2px] select-none':''}>{tr.replace(/^[•\-▸]\s*/,'')}</span></div>;return<p key={i} className={`text-[9px] leading-[1.6] ${blur?'text-gray-600 blur-[2px]':'text-gray-400'}`}>{tr}</p>;})}</div>
                  <button onClick={()=>setExpandedId(null)} className="w-full mt-2 py-1.5 bg-gray-800 rounded text-gray-500 text-[8px] font-bold">✕ {L==='ar'?'إغلاق':L==='ru'?'Закрыть':'Close'}</button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DocServicesPage;
