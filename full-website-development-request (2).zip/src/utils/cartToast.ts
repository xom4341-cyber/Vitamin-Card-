export function showCartToast(lang: string, count: number) {
  const old = document.getElementById('bm-cart-toast');
  if (old) old.remove();

  const msg = lang==='ar' ? `✅ تم إضافة المنتج للسلة (${count})` 
    : lang==='ru' ? `✅ Товар добавлен в корзину (${count})`
    : `✅ Product added to cart (${count})`;

  const div = document.createElement('div');
  div.id = 'bm-cart-toast';
  div.style.cssText = 'position:fixed;bottom:70px;left:50%;transform:translateX(-50%);z-index:99999;background:#0a0a14;border:1px solid #00d4ff30;border-radius:12px;padding:10px 20px;text-align:center;box-shadow:0 0 20px rgba(0,212,255,0.15)';
  div.innerHTML = `<p style="color:#00d4ff;font-size:12px;font-weight:700;white-space:nowrap">${msg}</p>`;
  document.body.appendChild(div);

  setTimeout(() => {
    div.style.transition = 'opacity 0.5s';
    div.style.opacity = '0';
    setTimeout(() => { const el = document.getElementById('bm-cart-toast'); if (el) el.remove(); }, 500);
  }, 2000);
}
