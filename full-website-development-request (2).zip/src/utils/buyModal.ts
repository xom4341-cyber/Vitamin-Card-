const TG = 'https://t.me/k22zzo';

export function showBuyModal(_lang: string, msg?: string) {
  const text = msg || '';
  try { navigator.clipboard.writeText(text); } catch(e) {
    try { const ta = document.createElement('textarea'); ta.value = text; ta.style.position='fixed'; ta.style.left='-9999px'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); } catch(e2) {}
  }
  if (text) {
    window.open(`${TG}?text=${encodeURIComponent(text)}`, '_blank');
  } else {
    window.open(TG, '_blank');
  }
}
