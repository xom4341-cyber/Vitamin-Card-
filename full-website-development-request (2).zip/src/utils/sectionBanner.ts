export function showSectionBanner(lang: string) {
  if (sessionStorage.getItem('bm-banner-shown')) return;
  sessionStorage.setItem('bm-banner-shown', '1');

  const msg = lang === 'ar'
    ? 'لا تقلق من تعقيدات العمل! نحن معك خطوة بخطوة عبر حسابات المسؤولين.\nمع كل خدمة ستحصل على كورس تعليمي خاص يجعلك محترفاً من الصفر.'
    : lang === 'ru'
    ? 'Не переживайте! Мы с вами на каждом шагу через аккаунты менеджеров.\nС каждой услугой вы получите обучающий курс.'
    : "Don't worry about complexity! We're with you step by step via our managers.\nWith every service you'll get a training course to make you a pro from scratch.";

  const close = lang==='ar'?'إغلاق':lang==='ru'?'Закрыть':'Close';

  const div = document.createElement('div');
  div.id = 'bm-section-banner';
  div.style.cssText = 'position:fixed;top:120px;left:50%;transform:translateX(-50%);z-index:9998;max-width:340px;width:calc(100% - 32px)';
  div.innerHTML = `<div style="background:#060610;border:1px solid #00d4ff25;border-radius:12px;padding:14px;text-align:center;box-shadow:0 0 30px rgba(0,212,255,0.1)">
    <p style="color:#00d4ff;font-size:11px;line-height:1.7;font-weight:700;white-space:pre-line">${msg}</p>
    <button id="bm-banner-close" style="margin-top:8px;padding:4px 16px;background:none;border:1px solid #333;border-radius:8px;color:#666;font-size:9px;cursor:pointer">${close}</button>
  </div>`;
  document.body.appendChild(div);

  const rm = () => { const el = document.getElementById('bm-section-banner'); if (el) { el.style.transition='opacity 0.5s'; el.style.opacity='0'; setTimeout(()=>{if(el.parentNode)el.remove();},500); } };
  document.getElementById('bm-banner-close')!.onclick = rm;
  setTimeout(rm, 5000);
}
