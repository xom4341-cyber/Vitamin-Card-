import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// Global error handler - prevents white screen
window.addEventListener('error', function(e) {
  console.error('Global error:', e.error);
});

window.addEventListener('unhandledrejection', function(e) {
  console.error('Unhandled rejection:', e.reason);
  e.preventDefault();
});

const root = document.getElementById("root");
if (root) {
  try {
    createRoot(root).render(
      <StrictMode>
        <App />
      </StrictMode>
    );
  } catch (e) {
    console.error('Render error:', e);
    root.innerHTML = '<div style="background:#000;color:#00d4ff;text-align:center;padding:40px;font-family:sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column"><h1 style="font-size:48px;margin-bottom:16px">☠️</h1><h2 style="margin-bottom:8px">BLACK MART</h2><p style="color:#666;font-size:14px">يرجى تحديث المتصفح أو استخدام Chrome/Safari</p><p style="color:#666;font-size:12px">Please update your browser or use Chrome/Safari</p></div>';
  }
}
